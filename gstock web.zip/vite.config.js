// vite.config.js
import { defineConfig } from "vite";
import react            from "@vitejs/plugin-react";
import { VitePWA }      from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType:  "autoUpdate",
      includeAssets: ["icon-192.png", "icon-512.png", "apple-touch-icon.png"],
      manifest: {
        name:             "G Stock — 現場在庫管理",
        short_name:       "G Stock",
        description:      "シーリング職人向け 在庫・工程・出面 管理アプリ",
        theme_color:      "#0A0A0A",
        background_color: "#0A0A0A",
        display:          "standalone",
        orientation:      "portrait",
        start_url:        "/",
        scope:            "/",
        lang:             "ja",
        icons: [
          {
            src:     "/icon-192.png",
            sizes:   "192x192",
            type:    "image/png",
            purpose: "any maskable",
          },
          {
            src:     "/icon-512.png",
            sizes:   "512x512",
            type:    "image/png",
            purpose: "any maskable",
          },
        ],
        shortcuts: [
          {
            name:       "在庫を確認",
            short_name: "在庫",
            url:        "/",
            icons: [{ src: "/icon-192.png", sizes: "192x192" }],
          },
        ],
        categories: ["business", "productivity", "utilities"],
      },
      workbox: {
        // オフライン対応: 全アセットをキャッシュ
        globPatterns:    ["**/*.{js,css,html,ico,png,svg,woff2}"],
        runtimeCaching: [
          {
            // QR 画像 API のキャッシュ（オフライン時に既生成 QR を表示）
            urlPattern: /^https:\/\/api\.qrserver\.com\//,
            handler:    "CacheFirst",
            options: {
              cacheName:        "qr-images",
              expiration:       { maxEntries: 200, maxAgeSeconds: 60 * 60 * 24 * 30 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
          {
            // jsQR CDN キャッシュ
            urlPattern: /^https:\/\/cdnjs\.cloudflare\.com\//,
            handler:    "CacheFirst",
            options: {
              cacheName:        "cdn-scripts",
              expiration:       { maxEntries: 10, maxAgeSeconds: 60 * 60 * 24 * 90 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
        ],
      },
    }),
  ],
  build: {
    outDir:         "dist",
    sourcemap:      false,
    rollupOptions: {
      output: {
        // ベンダーコードを分割（初回ロード最適化）
        manualChunks: {
          react:   ["react", "react-dom"],
          lucide:  ["lucide-react"],
        },
      },
    },
  },
});
