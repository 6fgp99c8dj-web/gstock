// src/hooks/useAIHistory.js
// ============================================================
// AI 会話履歴の永続化フック
// 責務: localStorage への読み書きのみ
// AI への送信は useAI.js → aiService.js が担当
// ============================================================
import { useState, useCallback, useEffect } from "react";

const STORAGE_KEY  = "ai_history";
const MAX_MESSAGES = 20; // 直近20件を保存

/**
 * AI 履歴フック
 *
 * messages の各要素:
 *   { id: string, role: "user"|"ai", text: string, createdAt: number }
 *
 * @returns {{
 *   messages:    object[],
 *   addMessage:  (role: string, text: string) => void,
 *   clearHistory:() => void,
 * }}
 */
export function useAIHistory() {
  const [messages, setMessages] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // 変更のたびに localStorage へ自動保存（最新 MAX_MESSAGES 件）
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(messages.slice(-MAX_MESSAGES))
      );
    } catch {
      // ストレージ容量超過は無視
    }
  }, [messages]);

  /** メッセージを1件追加する */
  const addMessage = useCallback((role, text) => {
    setMessages((prev) => [
      ...prev,
      {
        id:        Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        role,
        text,
        createdAt: Date.now(),
      },
    ]);
  }, []);

  /** 履歴を全件削除する */
  const clearHistory = useCallback(() => {
    setMessages([]);
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
  }, []);

  return { messages, addMessage, clearHistory };
}
