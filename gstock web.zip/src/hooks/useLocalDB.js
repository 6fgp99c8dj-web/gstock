// src/hooks/useLocalDB.js
// ドメインごとの Custom Hooks（責務分離 / 再利用可能）
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useDB } from "../context/DBContext.jsx";
import { uid, todayStr } from "../utils/storage.js";

// ================================================================
// useInventory — 在庫 / カテゴリ CRUD
// ================================================================
export function useInventory() {
  const { db, update } = useDB();

  const addProduct = useCallback(
    (product) =>
      update((prev) => ({
        products: [
          ...prev.products,
          { ...product, id: uid(), favorite: false, createdAt: Date.now() },
        ],
      })),
    [update]
  );

  const editProduct = useCallback(
    (id, patch) =>
      update((prev) => ({
        products: prev.products.map((p) =>
          p.id === id ? { ...p, ...patch } : p
        ),
      })),
    [update]
  );

  const deleteProduct = useCallback(
    (id) =>
      update((prev) => ({
        products: prev.products.filter((p) => p.id !== id),
      })),
    [update]
  );

  // +/- 調整（長押し連続入力にも使用）
  const adjustStock = useCallback(
    (product, delta) =>
      update((prev) => ({
        products: prev.products.map((p) =>
          p.id === product.id
            ? { ...p, arrival: Math.max(p.used, p.arrival + delta) }
            : p
        ),
      })),
    [update]
  );

  // テンキーで直接指定
  const setStockDirect = useCallback(
    (productId, stock) =>
      update((prev) => ({
        products: prev.products.map((p) =>
          p.id === productId
            ? { ...p, arrival: stock + p.used }
            : p
        ),
      })),
    [update]
  );

  const toggleFavorite = useCallback(
    (id) =>
      update((prev) => ({
        products: prev.products.map((p) =>
          p.id === id ? { ...p, favorite: !p.favorite } : p
        ),
      })),
    [update]
  );

  const addCategory = useCallback(
    (name) =>
      update((prev) => ({
        categories: [
          ...prev.categories,
          { id: uid(), name: name.trim(), createdAt: Date.now() },
        ],
      })),
    [update]
  );

  const editCategory = useCallback(
    (id, name) =>
      update((prev) => ({
        categories: prev.categories.map((c) =>
          c.id === id ? { ...c, name: name.trim() } : c
        ),
      })),
    [update]
  );

  const deleteCategory = useCallback(
    (id) =>
      update((prev) => ({
        categories: prev.categories.filter((c) => c.id !== id),
        products:   prev.products.filter((p) => p.categoryId !== id),
      })),
    [update]
  );

  return {
    categories:    db.categories,
    products:      db.products,
    addProduct,
    editProduct,
    deleteProduct,
    adjustStock,
    setStockDirect,
    toggleFavorite,
    addCategory,
    editCategory,
    deleteCategory,
  };
}

// ================================================================
// useSites — 現場 CRUD
// ================================================================
export function useSites() {
  const { db, update } = useDB();

  const addSite = useCallback(
    (site) =>
      update((prev) => ({
        sites: [...prev.sites, { ...site, id: uid(), createdAt: Date.now() }],
      })),
    [update]
  );

  const editSite = useCallback(
    (id, patch) =>
      update((prev) => ({
        sites: prev.sites.map((s) => (s.id === id ? { ...s, ...patch } : s)),
      })),
    [update]
  );

  const deleteSite = useCallback(
    (id) =>
      update((prev) => ({
        sites: prev.sites.filter((s) => s.id !== id),
      })),
    [update]
  );

  return { sites: db.sites, addSite, editSite, deleteSite };
}

// ================================================================
// useAttendance — 出面（21日〜20日締め）
// ================================================================

/** 日付文字列 → 期間キー "YYYY-MM" */
export function periodKeyFor(dateStr) {
  const d   = new Date(dateStr);
  const day = d.getDate();
  let y     = d.getFullYear();
  let m     = d.getMonth(); // 0-indexed
  if (day <= 20) {
    m -= 1;
    if (m < 0) { m = 11; y -= 1; }
  }
  return `${y}-${String(m + 1).padStart(2, "0")}`;
}

/** 期間キー → 表示ラベル */
export function periodLabel(key) {
  const [y, m] = key.split("-").map(Number);
  const prev   = m === 1 ? 12 : m - 1;
  return `${y}年${m}月度（${prev}/21〜${m}/20）`;
}

export function useAttendance() {
  const { db, update } = useDB();

  const addEntry = useCallback(
    (entry) =>
      update((prev) => ({
        attendance: [{ ...entry, id: uid() }, ...prev.attendance],
      })),
    [update]
  );

  const deleteEntry = useCallback(
    (id) =>
      update((prev) => ({
        attendance: prev.attendance.filter((a) => a.id !== id),
      })),
    [update]
  );

  return { attendance: db.attendance, addEntry, deleteEntry };
}

// ================================================================
// usePhotos — 写真 CRUD
// ================================================================
export function usePhotos() {
  const { db, update } = useDB();

  const addPhoto = useCallback(
    (photo) =>
      update((prev) => ({
        photos: [
          { ...photo, id: uid(), createdAt: Date.now() },
          ...prev.photos,
        ],
      })),
    [update]
  );

  const deletePhoto = useCallback(
    (id) =>
      update((prev) => ({
        photos: prev.photos.filter((p) => p.id !== id),
      })),
    [update]
  );

  return { photos: db.photos, addPhoto, deletePhoto };
}

// ================================================================
// useQRHistory — QR 操作履歴
// ================================================================
export function useQRHistory() {
  const { db, update } = useDB();

  const addQRHistory = useCallback(
    (entry) =>
      update((prev) => ({
        qrHistory: [
          { ...entry, id: uid(), createdAt: Date.now() },
          ...prev.qrHistory,
        ].slice(0, 200),
      })),
    [update]
  );

  return { qrHistory: db.qrHistory, addQRHistory };
}

// ================================================================
// useSchedules — 工程スケジュール CRUD
// ================================================================
export function useSchedules() {
  const { db, update } = useDB();

  const addSchedules = useCallback(
    (items) =>
      update((prev) => ({
        schedules: [
          ...(prev.schedules || []),
          ...items.map((s) => ({ ...s, id: uid(), createdAt: Date.now() })),
        ],
      })),
    [update]
  );

  const deleteSchedule = useCallback(
    (id) =>
      update((prev) => ({
        schedules: (prev.schedules || []).filter((s) => s.id !== id),
      })),
    [update]
  );

  const addOcrHistory = useCallback(
    (entry) =>
      update((prev) => ({
        ocrHistory: [
          { ...entry, id: uid(), createdAt: Date.now() },
          ...(prev.ocrHistory || []),
        ].slice(0, 100),
      })),
    [update]
  );

  const addOcrLearning = useCallback(
    (field, original, corrected) => {
      if (original === corrected) return;
      update((prev) => ({
        ocrLearning: [
          ...(prev.ocrLearning || []),
          { id: uid(), field, original, corrected, createdAt: Date.now() },
        ].slice(-50),
      }));
    },
    [update]
  );

  return {
    schedules:     db.schedules    || [],
    ocrHistory:    db.ocrHistory   || [],
    ocrLearning:   db.ocrLearning  || [],
    addSchedules,
    deleteSchedule,
    addOcrHistory,
    addOcrLearning,
  };
}

// ================================================================
// useSearch — 汎用検索フィルタ
// ================================================================
export function useSearch(items, searchFields) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return items;
    const q = query.toLowerCase();
    return items.filter((item) =>
      searchFields.some((f) =>
        String(item[f] ?? "").toLowerCase().includes(q)
      )
    );
  }, [items, query, searchFields]);

  return { query, setQuery, filtered };
}

// ================================================================
// useLongPress — 長押し連続入力（在庫 +/- ボタン）
// ================================================================
export function useLongPress(callback, delay = 400, interval = 90) {
  const timerRef    = useRef(null);
  const intervalRef = useRef(null);

  const start = useCallback(() => {
    callback();
    timerRef.current = setTimeout(() => {
      intervalRef.current = setInterval(callback, interval);
    }, delay);
  }, [callback, delay, interval]);

  const stop = useCallback(() => {
    clearTimeout(timerRef.current);
    clearInterval(intervalRef.current);
  }, []);

  // アンマウント時にタイマーをクリア
  useEffect(() => () => stop(), [stop]);

  return {
    onTouchStart: start,
    onTouchEnd:   stop,
    onMouseDown:  start,
    onMouseUp:    stop,
    onMouseLeave: stop,
  };
}
