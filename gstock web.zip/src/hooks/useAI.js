// src/hooks/useAI.js
// ============================================================
// AI チャット状態管理フック
// Phase 8: suggestions 対応 / buildAIContext を db から自動構築
//
// 【責務】
//   - 送信・受信・ローディング・エラー・suggestions の状態管理
//   - aiService.sendMessage() に委譲（プロバイダ実装に依存しない）
//   - 履歴の永続化は useAIHistory に委譲
//   - DB → context 変換は aiPrompt.buildAIContext に委譲
// ============================================================
import { useState, useCallback, useMemo } from "react";
import { useAIHistory }    from "./useAIHistory.js";
import { sendMessage }     from "../services/aiService.js";
import { buildAIContext }  from "../utils/aiPrompt.js";

// 初回表示する挨拶メッセージ
const GREETING_ID = "__greeting__";
const GREETING = {
  id:          GREETING_ID,
  role:        "ai",
  text:        "こんにちは！\n今日は何をお手伝いしましょう？\n\n在庫・工程・材料・施工手順など現場のことなら何でも聞いてください。",
  createdAt:   0,
  suggestions: [],
};

/**
 * AI チャットフック
 *
 * @param {object} db  DBContext の db オブジェクト（context は内部で自動構築）
 * @returns {{
 *   messages:     object[],    各 { id, role, text, createdAt, suggestions? }
 *   isLoading:    boolean,
 *   typing:       boolean,
 *   error:        string|null,
 *   suggestions:  string[],    最新 AI 返答の候補ボタン
 *   send:         (text: string) => Promise<void>,
 *   clear:        () => void,
 *   retry:        () => Promise<void>,
 * }}
 */
export function useAI(db) {
  const { messages: stored, addMessage, clearHistory } = useAIHistory();
  const [isLoading,    setIsLoading]    = useState(false);
  const [typing,       setTyping]       = useState(false);
  const [error,        setError]        = useState(null);
  const [lastText,     setLastText]     = useState("");
  const [suggestions,  setSuggestions]  = useState([]);

  // 挨拶を先頭に追加した表示用リスト
  const messages = useMemo(
    () => [GREETING, ...stored],
    [stored]
  );

  // ── 送信処理 ────────────────────────────────────────────────
  const _doSend = useCallback(async (text) => {
    if (!text || isLoading) return;

    setError(null);
    setSuggestions([]);
    setIsLoading(true);
    setLastText(text);

    // ユーザーメッセージを即座に追加（楽観的 UI）
    addMessage("user", text);

    // typing インジケーター（少し遅延）
    const typingTimer = setTimeout(() => setTyping(true), 120);

    try {
      // DB から context を自動構築して aiService に渡す
      const context      = buildAIContext(db);
      const msgSnapshot  = [GREETING, ...stored, { id: "tmp", role: "user", text }];
      const result       = await sendMessage(msgSnapshot, context);

      // 戻り値 { reply, suggestions, status } を処理
      const reply       = typeof result === "string" ? result : (result?.reply ?? "");
      const newSuggests = Array.isArray(result?.suggestions) ? result.suggestions : [];

      if (reply) {
        addMessage("ai", reply);
      }
      setSuggestions(newSuggests);
    } catch (err) {
      const errText = err?.message?.includes("未設定")
        ? "API キーが設定されていません。設定画面で AI プロバイダを確認してください。"
        : err?.message?.includes("API")
        ? "AI に接続できませんでした。ネットワークを確認してください。"
        : "エラーが発生しました。もう一度お試しください。";
      addMessage("ai", errText);
      setError(errText);
      setSuggestions([]);
    } finally {
      clearTimeout(typingTimer);
      setTyping(false);
      setIsLoading(false);
    }
  }, [isLoading, addMessage, stored, db, sendMessage, buildAIContext]);

  /** ユーザーの質問を送信する */
  const send = useCallback(
    (text) => _doSend(text?.trim()),
    [_doSend]
  );

  /** 直前のメッセージをリトライする */
  const retry = useCallback(
    () => _doSend(lastText),
    [_doSend, lastText]
  );

  /** 会話履歴を全件クリアする（挨拶は残る） */
  const clear = useCallback(() => {
    clearHistory();
    setError(null);
    setLastText("");
    setSuggestions([]);
  }, [clearHistory]);

  return { messages, isLoading, typing, error, suggestions, send, clear, retry };
}
