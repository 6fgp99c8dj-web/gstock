// src/hooks/useNotification.js
// ============================================================
// 通知管理フック — Phase 8-B 完全版
//
// 【責務】UI を持たない。通知ロジックのみ。
// 【対応】Web Notifications API（現在）/ Expo・Capacitor（将来）
//
// 【将来の差し替え箇所】
//   _sendNative()  → expo-notifications の scheduleNotificationAsync
//   _scheduleAt()  → expo-notifications の scheduleNotificationAsync + trigger
// ============================================================
import { useState, useCallback, useEffect, useRef } from "react";
import { todayStr } from "../utils/storage.js";

// localStorage キー
const PERM_KEY      = "gstock_notif_permission";
const SCHEDULE_KEY  = "gstock_notif_scheduled"; // 登録済み通知IDリスト

// セッション中の重複送信防止フラグ
const _sentThisSession = new Set();

/**
 * 通知管理フック
 *
 * @param {object} db        DBContext の db オブジェクト
 * @param {object} settings  db.settings
 * @returns {{
 *   permission:           "granted"|"denied"|"default",
 *   supported:            boolean,
 *   requestPermission:    () => Promise<boolean>,
 *   checkAndNotify:       () => void,
 *   notifyLowStock:       (products: Array) => void,
 *   notifyScheduleChange: (message: string) => void,
 *   scheduleAll:          () => void,
 *   clearScheduled:       () => void,
 *   scheduledCount:       number,
 * }}
 */
export function useNotification(db, settings) {
  const supported = typeof Notification !== "undefined";

  const [permission, setPermission] = useState(() => {
    if (!supported) return "denied";
    return Notification.permission;
  });

  // 登録済み通知ID（表示用）
  const [scheduledCount, setScheduledCount] = useState(() => {
    try {
      const raw = localStorage.getItem(SCHEDULE_KEY);
      return raw ? JSON.parse(raw).length : 0;
    } catch { return 0; }
  });

  // ── 通知許可リクエスト ────────────────────────────────────
  const requestPermission = useCallback(async () => {
    if (!supported) return false;
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      localStorage.setItem(PERM_KEY, result);
      return result === "granted";
    } catch {
      return false;
    }
  }, [supported]);

  // ── ネイティブ通知送信（内部ヘルパー） ───────────────────
  // 将来: expo-notifications.scheduleNotificationAsync に差し替える
  const _sendNative = useCallback((title, body, tag) => {
    if (!supported || Notification.permission !== "granted") return;
    if (_sentThisSession.has(tag)) return;
    _sentThisSession.add(tag);
    try {
      new Notification(title, {
        body,
        icon:               "/icon.png",
        tag,
        requireInteraction: false,
      });
    } catch { /* ignore */ }
  }, [supported]);

  // ── スケジュール時刻通知（内部ヘルパー） ─────────────────
  // 将来: Expo の trigger オプションで置き換え可能
  const _scheduleAt = useCallback((title, body, tag, targetHour) => {
    const now  = new Date();
    const fire = new Date();
    fire.setHours(targetHour, 0, 0, 0);

    const msUntil = fire.getTime() - now.getTime();
    if (msUntil < 0 || msUntil > 86400000) return; // 過去・24時間超はスキップ

    const timerId = setTimeout(() => {
      _sendNative(title, body, tag);
    }, msUntil);

    // 登録済みIDを localStorage に保存
    try {
      const ids = JSON.parse(localStorage.getItem(SCHEDULE_KEY) ?? "[]");
      ids.push(tag);
      localStorage.setItem(SCHEDULE_KEY, JSON.stringify(ids.slice(-50)));
      setScheduledCount(ids.length);
    } catch { /* ignore */ }

    return timerId; // clearTimeout 用
  }, [_sendNative]);

  // ── 全スケジュール登録 ────────────────────────────────────
  const _timerIds = useRef([]);

  const scheduleAll = useCallback(() => {
    if (!settings?.notifyEnabled) return;

    // 既存タイマーをクリア
    _timerIds.current.forEach(clearTimeout);
    _timerIds.current = [];

    const today    = todayStr();
    const tomorrow = _addDays(today, 1);
    const schedules = db?.schedules ?? [];

    // 前日 18:00 通知
    if (settings?.notifyDayBefore) {
      schedules
        .filter((s) => s.startDate <= tomorrow && s.endDate >= tomorrow)
        .forEach((s) => {
          const name = [s.siteName, s.processName].filter(Boolean).join(" ");
          const tag  = `tomorrow-${s.id}-${tomorrow}`;
          const tid  = _scheduleAt("明日の現場があります", `明日は「${name}」です`, tag, 18);
          if (tid) _timerIds.current.push(tid);
        });
    }

    // 当日 7:00 通知
    if (settings?.notifyMorning) {
      schedules
        .filter((s) => s.startDate <= today && s.endDate >= today)
        .forEach((s) => {
          const name = [s.siteName, s.processName].filter(Boolean).join(" ");
          const tag  = `today-${s.id}-${today}`;
          const tid  = _scheduleAt("本日の現場", `本日は「${name}」です`, tag, 7);
          if (tid) _timerIds.current.push(tid);
        });
    }
  }, [db, settings, _scheduleAt]);

  // ── 登録済みスケジュールを全解除 ─────────────────────────
  const clearScheduled = useCallback(() => {
    _timerIds.current.forEach(clearTimeout);
    _timerIds.current = [];
    _sentThisSession.clear();
    try {
      localStorage.removeItem(SCHEDULE_KEY);
      setScheduledCount(0);
    } catch { /* ignore */ }
  }, []);

  // ── 即時チェック通知（現在時刻に応じて即送信） ───────────
  const checkAndNotify = useCallback(() => {
    if (!settings?.notifyEnabled) return;

    const today    = todayStr();
    const tomorrow = _addDays(today, 1);
    const hour     = new Date().getHours();
    const schedules = db?.schedules ?? [];

    // 前日 18:00 以降
    if (settings?.notifyDayBefore && hour >= 18) {
      schedules
        .filter((s) => s.startDate <= tomorrow && s.endDate >= tomorrow)
        .forEach((s) => {
          const tag  = `tomorrow-${s.id}-${tomorrow}`;
          const name = [s.siteName, s.processName].filter(Boolean).join(" ");
          _sendNative("明日の現場があります", `明日は「${name}」です`, tag);
        });
    }

    // 当日 7:00〜9:00
    if (settings?.notifyMorning && hour >= 7 && hour < 9) {
      schedules
        .filter((s) => s.startDate <= today && s.endDate >= today)
        .forEach((s) => {
          const tag  = `today-${s.id}-${today}`;
          const name = [s.siteName, s.processName].filter(Boolean).join(" ");
          _sendNative("本日の現場", `本日は「${name}」です`, tag);
        });
    }
  }, [db, settings, _sendNative]);

  // ── 在庫不足通知 ─────────────────────────────────────────
  const notifyLowStock = useCallback((products) => {
    if (!settings?.notifyEnabled || !settings?.notifyLowStock) return;
    const empty = (products ?? []).filter((p) => p.arrival - p.used <= 0);
    if (empty.length === 0) return;
    const tag   = `low-stock-${todayStr()}`;
    const names = empty.slice(0, 3).map((p) => p.name).join("、");
    const more  = empty.length > 3 ? `他${empty.length - 3}品目` : "";
    _sendNative("材料不足です", `${names}${more} の在庫がなくなっています`, tag);
  }, [settings, _sendNative]);

  // ── 工程変更通知 ─────────────────────────────────────────
  const notifyScheduleChange = useCallback((message) => {
    if (!settings?.notifyEnabled || !settings?.notifyScheduleChange) return;
    const tag = `schedule-change-${Date.now()}`;
    _sendNative("工程変更があります", message ?? "工程が更新されました", tag);
  }, [settings, _sendNative]);

  // ── 起動時: 許可済みなら即チェック + スケジュール登録 ────
  const initialized = useRef(false);
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    if (permission === "granted" && settings?.notifyEnabled) {
      checkAndNotify();
      scheduleAll();
    }
  }, [permission, settings, checkAndNotify, scheduleAll]);

  // アンマウント時にタイマー全解除
  useEffect(() => {
    return () => { _timerIds.current.forEach(clearTimeout); };
  }, []);

  return {
    permission,
    supported,
    requestPermission,
    checkAndNotify,
    notifyLowStock,
    notifyScheduleChange,
    scheduleAll,
    clearScheduled,
    scheduledCount,
  };
}

// ── 内部ヘルパー ──────────────────────────────────────────────
function _addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
