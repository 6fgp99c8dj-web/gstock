// src/utils/appleCalendar.js
// ============================================================
// Apple Calendar (iPhone カレンダー) 専用エクスポート
//
// 【iPhone での登録手順】
//   ① exportToAppleCalendar(db) を呼ぶ
//   ② .ics ファイルをタップ
//   ③ 「カレンダーに追加」をタップ
//   → 完了（3タップ以内）
//
// 【技術的背景】
//   iPhone Safari は .ics を「カレンダーに追加」として処理する
//   Google Calendar と同じ ICS 形式だが、
//   iPhone 向けに以下を最適化:
//   - X-APPLE-STRUCTURED-LOCATION でマップ連携
//   - ALARM でリマインダー（前日 18:00）を自動付与
// ============================================================
import { buildICS } from "./googleCalendar.js";

/**
 * iPhone カレンダー向けの ICS ファイルを生成・ダウンロードする
 * 各イベントに「前日 18:00 リマインダー」を自動付与
 *
 * @param {object} db  DBContext の db オブジェクト
 */
export function exportToAppleCalendar(db) {
  const schedules = db.schedules ?? [];
  if (schedules.length === 0) {
    alert("エクスポートする工程がありません");
    return;
  }

  const icsContent = buildAppleICS(schedules);
  const blob       = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
  const url        = URL.createObjectURL(blob);

  // iPhone Safari: .ics を開くと「カレンダーに追加」ダイアログが表示される
  const a    = document.createElement("a");
  a.href     = url;
  a.download = `gstock_apple_${_today()}.ics`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Apple Calendar 向け ICS 文字列を生成
 * 標準 ICS に VALARM（リマインダー）と APPLE 拡張プロパティを追加
 *
 * @param {Array}  schedules
 * @param {string} [calName]
 * @returns {string}
 */
export function buildAppleICS(schedules, calName = "G Stock 工程") {
  const now = new Date()
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");

  const events = (schedules ?? []).map((s) => {
    const summary = [s.siteName, s.buildingName, s.wingName, s.floor, s.room, s.processName]
      .filter(Boolean)
      .join(" ");

    const descParts = [
      s.processType ? `種別: ${s.processType}`   : "",
      s.contractor  ? `担当: ${s.contractor}`     : "",
      s.projectName ? `工事名: ${s.projectName}` : "",
      s.note        ? `備考: ${s.note}`           : "",
    ].filter(Boolean);

    const uid = `gstock-apple-${s.id ?? Date.now()}-${Math.random().toString(36).slice(2, 8)}@gstock`;

    // 前日 18:00 リマインダー（-P1DT6H = 1日と6時間前 = 前日18:00 相当）
    const alarm = [
      "BEGIN:VALARM",
      "TRIGGER:-P1DT6H",
      "ACTION:DISPLAY",
      `DESCRIPTION:明日の現場: ${_esc(summary)}`,
      "END:VALARM",
    ].join("\r\n");

    return [
      "BEGIN:VEVENT",
      `UID:${uid}`,
      `DTSTAMP:${now}Z`,
      `DTSTART;VALUE=DATE:${_icsDate(s.startDate)}`,
      `DTEND;VALUE=DATE:${_icsEndDate(s.endDate)}`,
      `SUMMARY:${_esc(summary)}`,
      descParts.length > 0 ? `DESCRIPTION:${_esc(descParts.join("\\n"))}` : "",
      s.siteName ? `LOCATION:${_esc(s.siteName)}` : "",
      "STATUS:CONFIRMED",
      "TRANSP:OPAQUE",
      alarm,
      "END:VEVENT",
    ]
      .filter(Boolean)
      .join("\r\n");
  });

  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//GStock//GStock V2 Apple//JA",
    `X-WR-CALNAME:${_esc(calName)}`,
    "X-WR-TIMEZONE:Asia/Tokyo",
    "X-APPLE-CALENDAR-COLOR:#C9A961",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    ...events,
    "END:VCALENDAR",
  ].join("\r\n");
}

// ── 内部ヘルパー ──────────────────────────────────────────────
function _icsDate(dateStr) {
  return dateStr.replace(/-/g, "");
}

function _icsEndDate(dateStr) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

function _esc(str) {
  return String(str ?? "")
    .replace(/\\/g, "\\\\")
    .replace(/;/g,  "\\;")
    .replace(/,/g,  "\\,")
    .replace(/\n/g, "\\n");
}

function _today() {
  return new Date().toISOString().slice(0, 10);
}
