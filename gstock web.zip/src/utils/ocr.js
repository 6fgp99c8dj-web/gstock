// src/utils/ocr.js
// 工程表 OCR エンジン（Canvas 前処理 + Claude Vision API）

import { uid } from "./storage.js";

// ----------------------------------------------------------------
// 工程種別マスタ
// ----------------------------------------------------------------
export const PROCESS_TYPES = [
  "シーリング", "防水", "塗装", "足場", "左官", "建具",
  "電気", "設備", "内装", "外構", "鉄骨", "コンクリート",
  "解体", "仮設", "基礎", "躯体", "屋根", "タイル",
  "金属", "木工", "ガラス", "断熱", "耐火", "下地",
  "仕上げ", "検査", "引渡", "その他",
];

// ----------------------------------------------------------------
// 1. Canvas 画像前処理
//    ・最大 2048px リサイズ
//    ・ヒストグラム均等化（CLAHE 近似）
//    ・輝度 1.05 倍のシャープ強調
//    ・JPEG 0.92 で出力
// ----------------------------------------------------------------
export async function preprocessImage(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);

    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("画像の読み込みに失敗しました"));
    };

    img.onload = () => {
      URL.revokeObjectURL(url);

      const MAX = 2048;
      let w = img.width;
      let h = img.height;

      if (w > MAX || h > MAX) {
        if (w > h) { h = Math.round((h * MAX) / w); w = MAX; }
        else        { w = Math.round((w * MAX) / h); h = MAX; }
      }

      const canvas = document.createElement("canvas");
      canvas.width  = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });

      ctx.drawImage(img, 0, 0, w, h);

      // ヒストグラム均等化
      const imageData = ctx.getImageData(0, 0, w, h);
      const d    = imageData.data;
      const hist = new Array(256).fill(0);

      for (let i = 0; i < d.length; i += 4) {
        const lum = Math.round(0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]);
        hist[lum]++;
      }

      const total = w * h;
      let cdf = 0;
      const lut = new Array(256);
      for (let v = 0; v < 256; v++) {
        cdf    += hist[v];
        lut[v]  = Math.round((cdf / total) * 255);
      }

      for (let i = 0; i < d.length; i += 4) {
        d[i]     = Math.min(255, lut[d[i]]     * 1.05);
        d[i + 1] = Math.min(255, lut[d[i + 1]] * 1.05);
        d[i + 2] = Math.min(255, lut[d[i + 2]] * 1.05);
      }

      ctx.putImageData(imageData, 0, 0);

      canvas.toBlob(
        (blob) => {
          const reader   = new FileReader();
          reader.onload  = () => resolve(reader.result.split(",")[1]);
          reader.onerror = () => reject(new Error("base64 変換に失敗しました"));
          reader.readAsDataURL(blob);
        },
        "image/jpeg",
        0.92
      );
    };

    img.src = url;
  });
}

// ----------------------------------------------------------------
// 2. OCR プロンプト構築
// ----------------------------------------------------------------
function buildOCRPrompt(userProfile, learning) {
  const companyFilter = userProfile?.companyName
    ? `\n【重要】ユーザーの業者名は「${userProfile.companyName}」です。` +
      `この業者が担当する工程を優先的に抽出してください。` +
      `業者欄、担当欄、施工者欄などに「${userProfile.companyName}」` +
      `またはその略称・類似表記があるものを特定してください。`
    : "";

  const learningHints =
    learning?.length > 0
      ? "\n【過去の修正履歴（優先適用）】\n" +
        learning
          .slice(-10)
          .map((l) => `- ${l.field}: "${l.original}" → "${l.corrected}"`)
          .join("\n")
      : "";

  return (
    `あなたは建設工事の工程表を解析する専門AIです。\n` +
    `画像は工程表（月間・週間・Excel印刷・紙の写真・傾き・シワあり）です。\n` +
    `多少の傾き・影・折れ・暗さがあっても最大限読み取ってください。\n` +
    `${companyFilter}${learningHints}\n\n` +
    `以下の工程種別を認識してください：\n${PROCESS_TYPES.join("、")}\n\n` +
    `工程表から全ての工程エントリを抽出し、以下のJSON形式で返してください。\n` +
    `JSON以外のテキストは一切出力しないでください。\n\n` +
    `{\n` +
    `  "tableInfo": {\n` +
    `    "title": "工程表のタイトル（あれば）",\n` +
    `    "period": "工程表の対象期間（例：2025年7月）",\n` +
    `    "projectName": "工事名・プロジェクト名",\n` +
    `    "siteName": "現場名・物件名",\n` +
    `    "buildingName": "建物名（あれば）"\n` +
    `  },\n` +
    `  "schedules": [\n` +
    `    {\n` +
    `      "id": "一意のID（連番文字列）",\n` +
    `      "projectName": "工事名",\n` +
    `      "siteName": "現場名",\n` +
    `      "buildingName": "建物名（なければ空文字）",\n` +
    `      "wingName": "棟名（なければ空文字）",\n` +
    `      "floor": "階数（例：3F、なければ空文字）",\n` +
    `      "room": "部屋番号（なければ空文字）",\n` +
    `      "processName": "工程名（具体的に）",\n` +
    `      "processType": "工程種別（上記マスタから最も近いもの）",\n` +
    `      "startDate": "開始日（YYYY-MM-DD形式）",\n` +
    `      "endDate": "終了日（YYYY-MM-DD形式）",\n` +
    `      "contractor": "担当業者名（なければ空文字）",\n` +
    `      "note": "備考（なければ空文字）",\n` +
    `      "confidence": 0.95\n` +
    `    }\n` +
    `  ],\n` +
    `  "warnings": ["解析上の注意点があれば記載"]\n` +
    `}\n\n` +
    `注意事項：\n` +
    `- 日付が「7/10〜7/15」形式の場合、工程表の年を推定してYYYY-MM-DD形式に変換\n` +
    `- ガントチャート形式の場合、横軸の日付目盛りを正確に読み取る\n` +
    `- 同一現場・同一工程が複数行ある場合は全て抽出（重複除去は後工程で行う）\n` +
    `- confidenceは読み取り確度（0.0〜1.0）\n` +
    `- 必ずJSONのみ返すこと。マークダウンのコードブロックも不要`
  );
}

// ----------------------------------------------------------------
// 3. Claude Vision API 呼び出し（1枚）
// ----------------------------------------------------------------
export async function analyzeScheduleImage(base64Image, userProfile, learning) {
  const prompt = buildOCRPrompt(userProfile, learning);

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({
      model:      "claude-sonnet-4-6",
      max_tokens: 4000,
      messages: [
        {
          role: "user",
          content: [
            {
              type:   "image",
              source: {
                type:       "base64",
                media_type: "image/jpeg",
                data:       base64Image,
              },
            },
            { type: "text", text: prompt },
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }

  const data  = await response.json();
  const text  = (data.content ?? []).map((c) => c.text ?? "").join("");
  const clean = text.replace(/```json\n?|\n?```/g, "").trim();

  try {
    return JSON.parse(clean);
  } catch {
    throw new Error(
      "AIの返答をJSONとして解析できませんでした。再試行してください。"
    );
  }
}

// ----------------------------------------------------------------
// 4. 複数ページのマージ + 重複除去
// ----------------------------------------------------------------
export function mergeScheduleResults(results) {
  const tableInfo = results[0]?.tableInfo ?? {};
  const all       = [];

  results.forEach((r, pageIndex) => {
    (r.schedules ?? []).forEach((s) => {
      all.push({ ...s, id: uid(), pageIndex });
    });
  });

  const seen    = new Set();
  const deduped = all.filter((s) => {
    const key = `${s.siteName}|${s.processName}|${s.startDate}|${s.endDate}|${s.floor}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return { tableInfo, schedules: deduped };
}

// ----------------------------------------------------------------
// 5. 業者フィルタ
// ----------------------------------------------------------------
export function applyCompanyFilter(schedules, userProfile) {
  const name    = userProfile?.companyName;
  const aliases = userProfile?.contractorAliases ?? [];

  if (!name) return schedules;

  return schedules.filter((s) => {
    const c = s.contractor ?? "";
    return (
      c === "" ||
      c.includes(name) ||
      aliases.some((a) => c.includes(a))
    );
  });
}
