// src/utils/storage.js
// localStorage の読み書き / v1→v2 マイグレーション / バックアップ

export const STORAGE_KEY    = "gstock_v2";
const        STORAGE_KEY_V1 = "gstock_v1";

// ----------------------------------------------------------------
// デフォルト DB 構造
// ----------------------------------------------------------------
export function createDefaultDB() {
  return {
    categories:  [],
    products:    [],
    sites:       [],
    attendance:  [],
    photos:      [],
    qrHistory:   [],
    schedules:   [],
    ocrHistory:  [],
    ocrLearning: [],
    userProfile: { companyName: "", contractorAliases: [] },
    // Phase 8: 通知・カレンダー・AI設定の永続化先
    settings: {
      notifyEnabled:        false,
      notifyDayBefore:      true,
      notifyMorning:        true,
      notifyLowStock:       true,
      notifyScheduleChange: true,
      syncGoogleCalendar:   false,
      syncAppleCalendar:    false,
      aiProvider:           "mock",
    },
    // 将来の職人管理（Phase 9 予定）
    workers: [],
  };
}

// ----------------------------------------------------------------
// 読み込み（v1 → v2 マイグレーション対応）
// ----------------------------------------------------------------
export function loadDB() {
  try {
    const rawV2 = localStorage.getItem(STORAGE_KEY);
    if (rawV2) {
      return { ...createDefaultDB(), ...JSON.parse(rawV2) };
    }
    // 旧バージョン (gstock_v1) からの移行
    const rawV1 = localStorage.getItem(STORAGE_KEY_V1);
    if (rawV1) {
      return { ...createDefaultDB(), ...JSON.parse(rawV1) };
    }
    return createDefaultDB();
  } catch {
    return createDefaultDB();
  }
}

// ----------------------------------------------------------------
// 書き込み
// ----------------------------------------------------------------
export function saveDB(db) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    // ストレージ容量超過などは無視
  }
}

// ----------------------------------------------------------------
// ユーティリティ
// ----------------------------------------------------------------

/** ユニーク ID 生成 */
export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

/** 今日の日付文字列 YYYY-MM-DD */
export const todayStr = () => new Date().toISOString().slice(0, 10);

// ----------------------------------------------------------------
// バックアップ / エクスポート / インポート
// ----------------------------------------------------------------

/** 在庫を CSV としてダウンロード */
export function exportInventoryCSV(products, categories) {
  const catMap = Object.fromEntries(categories.map((c) => [c.id, c.name]));
  const header = "カテゴリ,商品名,単位,入荷数,使用数,在庫数";
  const rows   = products.map((p) =>
    [
      catMap[p.categoryId] ?? "未分類",
      p.name,
      p.unit,
      p.arrival,
      p.used,
      p.arrival - p.used,
    ].join(",")
  );
  _download(
    new Blob([[header, ...rows].join("\n")], { type: "text/csv" }),
    "gstock_inventory.csv"
  );
}

/** DB 全体を JSON としてダウンロード */
export function exportJSON(db) {
  _download(
    new Blob([JSON.stringify(db, null, 2)], { type: "application/json" }),
    `gstock_backup_${todayStr()}.json`
  );
}

/** JSON ファイルを読み込んで DB オブジェクトを返す */
export function importJSON(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        resolve({ ...createDefaultDB(), ...parsed });
      } catch {
        reject(new Error("JSON の解析に失敗しました"));
      }
    };
    reader.onerror = () =>
      reject(new Error("ファイルの読み込みに失敗しました"));
    reader.readAsText(file);
  });
}

// 内部ヘルパー
function _download(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const a   = document.createElement("a");
  a.href     = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
}
