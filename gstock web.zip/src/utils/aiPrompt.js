// src/utils/aiPrompt.js
// ============================================================
// AI プロンプト構築ユーティリティ
// 責務: DB のデータをプロンプト文字列に変換するのみ
// Phase 8: db.history / db.workers / db.inventory 追加対応
// ============================================================
import { todayStr } from "./storage.js";

// ── システムプロンプト（全 API 共通） ───────────────────────
export const BASE_SYSTEM_PROMPT =
  "あなたは建設現場のシーリング職人をサポートする専門AIアシスタントです。\n" +
  "防水・シーリング・塗装・足場・左官・建具・設備などの建設工事に精通しています。\n" +
  "以下のルールを守ってください:\n" +
  "- 簡潔で実用的な日本語で回答する\n" +
  "- 材料名・数量・乾燥時間・施工手順など具体的な数値を含める\n" +
  "- 危険な作業には必ず安全上の注意を添える\n" +
  "- 在庫・工程・出面・現場・過去履歴の情報が提供された場合はそれを優先して回答する\n" +
  "- 過去の施工履歴から傾向を読み取り、先回りした提案を行う";

/**
 * DB 全体から AI コンテキストオブジェクトを生成する
 * AIScreen.jsx → useAI.js → aiService.js に渡す context の構築に使用
 *
 * @param {object} db            DBContext の db
 * @param {string} [today]       YYYY-MM-DD（省略時は todayStr()）
 * @returns {object}             context オブジェクト
 */
export function buildAIContext(db, today) {
  const t = today ?? todayStr();

  // 今日の工程
  const todaySchedule = (db.schedules ?? []).find(
    (s) => s.startDate <= t && s.endDate >= t
  ) ?? null;

  // 今日の現場
  const todaySite = todaySchedule?.siteId
    ? (db.sites ?? []).find((s) => s.id === todaySchedule.siteId) ?? null
    : null;

  // 在庫不足
  const threshold        = db.settings?.lowStockThreshold ?? 5;
  const lowStockProducts = (db.products ?? [])
    .filter((p) => p.arrival - p.used <= threshold)
    .sort((a, b) => (a.arrival - a.used) - (b.arrival - b.used));

  // 当月の出面
  const currentMonth = t.slice(0, 7);
  const attendance   = (db.attendance ?? []).filter(
    (a) => a.date?.startsWith(currentMonth)
  );

  // 過去の AI 会話履歴（ai_history から）
  let aiHistory = [];
  try {
    const raw = localStorage.getItem("ai_history");
    if (raw) aiHistory = JSON.parse(raw).slice(-5); // 直近5件
  } catch { /* ignore */ }

  return {
    // 今日の情報
    todaySchedule,
    todaySite,

    // 全データ
    allSchedules:    db.schedules   ?? [],
    products:        db.products    ?? [],
    sites:           db.sites       ?? [],
    categories:      db.categories  ?? [],
    attendance,
    qrHistory:       (db.qrHistory  ?? []).slice(0, 20),

    // 派生データ
    lowStockProducts,
    totalProducts:   (db.products ?? []).length,

    // ユーザー設定
    userProfile:     db.userProfile ?? {},
    settings:        db.settings    ?? {},

    // 過去の AI 会話履歴（文脈参照用）
    aiHistory,

    // 将来対応フィールド（DB に追加された際に自動で渡せる）
    workers:   db.workers   ?? [],  // 職人管理（将来）
    inventory: db.inventory ?? [],  // 詳細在庫（将来）
  };
}

/**
 * コンテキスト情報をシステムプロンプトに埋め込む
 *
 * @param {object} context  buildAIContext() の戻り値
 * @returns {string}        コンテキスト付きシステムプロンプト
 */
export function buildSystemPrompt(context) {
  const today = todayStr();
  const lines = [BASE_SYSTEM_PROMPT, "", `【現在日時】${today}`];

  // ── 今日の現場 ────────────────────────────────────────────
  if (context?.todaySite?.name) {
    lines.push(`\n【今日の現場】${context.todaySite.name}`);
    if (context.todaySite.address) {
      lines.push(`住所: ${context.todaySite.address}`);
    }
  }

  // ── 今日の工程 ────────────────────────────────────────────
  if (context?.todaySchedule) {
    const s = context.todaySchedule;
    [
      `\n【今日の工程】`,
      `工程名: ${s.processName ?? "未設定"}`,
      `種別: ${s.processType ?? "未設定"}`,
      `期間: ${s.startDate} 〜 ${s.endDate}`,
      s.contractor ? `担当業者: ${s.contractor}` : "",
      s.floor      ? `階数: ${s.floor}`           : "",
      s.note       ? `備考: ${s.note}`            : "",
    ]
      .filter(Boolean)
      .forEach((l) => lines.push(l));
  }

  // ── 今後の工程（直近5件） ────────────────────────────────
  const upcoming = (context?.allSchedules ?? [])
    .filter((s) => s.startDate > today)
    .sort((a, b) => a.startDate.localeCompare(b.startDate))
    .slice(0, 5);

  if (upcoming.length > 0) {
    lines.push(
      `\n【今後の工程（直近${upcoming.length}件）】`,
      ...upcoming.map(
        (s) => `・${s.startDate} 〜 ${s.endDate}: ${s.siteName ?? ""} ${s.processName ?? ""}`
      )
    );
  }

  // ── 在庫一覧 ─────────────────────────────────────────────
  const products = context?.products ?? [];
  if (products.length > 0) {
    const stockLines = products.map((p) => {
      const stock = p.arrival - p.used;
      const flag  = stock <= 0 ? "⚠在庫なし" : stock <= 5 ? "⚠残りわずか" : "";
      return `・${p.name}: ${stock}${p.unit} ${flag}`.trimEnd();
    });
    lines.push(`\n【在庫一覧（全${products.length}品目）】`, ...stockLines);
  }

  // ── 不足材料 ─────────────────────────────────────────────
  const low = context?.lowStockProducts ?? [];
  if (low.length > 0) {
    lines.push(
      `\n【不足・残りわずかの材料】`,
      ...low.map((p) => `・${p.name}: 残り${p.arrival - p.used}${p.unit}`)
    );
  }

  // ── 当月の出面 ────────────────────────────────────────────
  const att = context?.attendance ?? [];
  if (att.length > 0) {
    const total = att.reduce((sum, a) => sum + (a.value ?? 0), 0);
    lines.push(
      `\n【出面（当月合計: ${total}人工）】`,
      ...att.slice(0, 10).map((a) => `・${a.date}: ${a.value}人工`)
    );
  }

  // ── 現場一覧 ─────────────────────────────────────────────
  const sites = context?.sites ?? [];
  if (sites.length > 0) {
    lines.push(
      `\n【登録現場（全${sites.length}件）】`,
      ...sites.map((s) => `・${s.name}${s.address ? ` (${s.address})` : ""}`)
    );
  }

  // ── QR 操作履歴（よく使う材料の把握） ───────────────────
  const qrHistory = context?.qrHistory ?? [];
  if (qrHistory.length > 0) {
    lines.push(
      `\n【最近の材料操作（直近${qrHistory.length}件）】`,
      ...qrHistory.slice(0, 5).map(
        (h) => `・${h.type === "in" ? "入荷" : "使用"}: ${h.productId}`
      )
    );
  }

  // ── 過去の AI 会話履歴（文脈理解） ──────────────────────
  const aiHistory = context?.aiHistory ?? [];
  if (aiHistory.length > 0) {
    lines.push(
      `\n【過去の相談履歴（直近${aiHistory.length}件）】`,
      ...aiHistory.map(
        (m) => `・${m.role === "user" ? "質問" : "回答"}: ${String(m.text ?? "").slice(0, 40)}`
      )
    );
  }

  // ── 職人情報（将来対応） ─────────────────────────────────
  const workers = context?.workers ?? [];
  if (workers.length > 0) {
    lines.push(
      `\n【職人一覧（${workers.length}名）】`,
      ...workers.map((w) => `・${w.name}${w.role ? ` (${w.role})` : ""}`)
    );
  }

  // ── ユーザー業者名 ────────────────────────────────────────
  if (context?.userProfile?.companyName) {
    lines.push(`\n【ユーザー業者名】${context.userProfile.companyName}`);
  }

  return lines.join("\n");
}

/**
 * 会話履歴を各 API の形式に変換
 *
 * @param {Array}  messages  { role, text }[]
 * @param {"openai"|"gemini"|"claude"} provider
 * @returns {Array}
 */
export function formatHistoryForProvider(messages, provider) {
  // 直近10件のみ（トークン節約）
  // 挨拶メッセージ（id === "__greeting__"）は除外
  const recent = messages
    .filter((m) => m.id !== "__greeting__")
    .slice(-10);

  switch (provider) {
    case "openai":
    case "claude":
      return recent.map((m) => ({
        role:    m.role === "ai" ? "assistant" : "user",
        content: m.text,
      }));

    case "gemini":
      return recent.map((m) => ({
        role:  m.role === "ai" ? "model" : "user",
        parts: [{ text: m.text }],
      }));

    default:
      return recent;
  }
}
