// src/utils/qr.js
// QR コード生成 URL / jsQR 動的ロード / 在庫レベル色

// ----------------------------------------------------------------
// QR 画像 URL 生成
// ----------------------------------------------------------------

/**
 * 商品 ID から QR 画像 URL を生成する（外部 API 利用）
 * @param {string} productId
 * @param {number} [size=240]
 */
export function qrImageUrl(productId, size = 240) {
  return (
    "https://api.qrserver.com/v1/create-qr-code/" +
    `?size=${size}x${size}` +
    "&color=C9A961" +
    "&bgcolor=0A0A0A" +
    `&data=${encodeURIComponent(productId)}`
  );
}

// ----------------------------------------------------------------
// jsQR 動的ロード（CDN / キャッシュ付き）
// ----------------------------------------------------------------
let _jsQRPromise = null;

/**
 * jsQR ライブラリを CDN から動的ロードして返す
 * 2 回目以降は既存の Promise をそのまま返す（シングルトン）
 */
export function loadJsQR() {
  if (window.jsQR) return Promise.resolve(window.jsQR);
  if (_jsQRPromise) return _jsQRPromise;

  _jsQRPromise = new Promise((resolve, reject) => {
    const script  = document.createElement("script");
    script.src    = "https://cdnjs.cloudflare.com/ajax/libs/jsqr/1.4.0/jsQR.js";
    script.onload  = () => resolve(window.jsQR);
    script.onerror = () => reject(new Error("jsQR の読み込みに失敗しました"));
    document.head.appendChild(script);
  });

  return _jsQRPromise;
}

// ----------------------------------------------------------------
// 在庫レベル色
// ----------------------------------------------------------------

/**
 * 在庫数に応じた表示色を返す
 * @param {number} stock  在庫数（arrival - used）
 * @param {object} T      デザイントークン
 */
export function stockLevelColor(stock, T) {
  if (stock <= 0) return T.red;
  if (stock <= 5) return T.gold;
  return T.green;
}
