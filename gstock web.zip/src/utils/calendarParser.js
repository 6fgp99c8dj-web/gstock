// src/utils/calendarParser.js
// ============================================================
// 工程表パーサー — CSV / TSV / プレーンテキスト → 工程オブジェクト
//
// 【責務】ファイル読み込みと変換のみ。UI・API通信は持たない。
//
// 【対応フォーマット】
//   - CSV（カンマ区切り）
//   - TSV（タブ区切り）
//   - Excel から貼り付けたテキスト（タブ区切り）
//
// 【出力スキーマ】
//   {
//     title:    string,   // 工程名
//     start:    string,   // YYYY-MM-DD
//     end:      string,   // YYYY-MM-DD
//     site:     string,   // 現場名
//     worker:   string,   // 担当者
//     memo:     string,   // 備考
//     processType: string // 工程種別（自動判定）
//     raw:      object    // 元データ（デバッグ用）
//   }
// ============================================================
import { uid } from "./storage.js";

// ── 工程種別キーワードマップ ──────────────────────────────────
const PROCESS_KEYWORDS = {
  シーリング:     ["シーリング", "シール", "sealing", "コーキング", "caulk"],
  防水:          ["防水", "waterproof"],
  塗装:          ["塗装", "塗り", "paint"],
  足場:          ["足場", "scaffold"],
  左官:          ["左官", "モルタル", "plaster"],
  建具:          ["建具", "サッシ", "ドア", "window"],
  電気:          ["電気", "電工", "electric"],
  設備:          ["設備", "配管", "plumbing"],
  内装:          ["内装", "クロス", "内部"],
  外構:          ["外構", "外部", "外壁"],
  解体:          ["解体", "撤去"],
  検査:          ["検査", "立会", "確認"],
  引渡:          ["引渡", "竣工", "完成"],
};

/**
 * テキスト内のキーワードから工程種別を推定する
 * @param {string} text
 * @returns {string}
 */
function detectProcessType(text) {
  const t = String(text ?? "").toLowerCase();
  for (const [type, keywords] of Object.entries(PROCESS_KEYWORDS)) {
    if (keywords.some((kw) => t.includes(kw.toLowerCase()))) {
      return type;
    }
  }
  return "その他";
}

/**
 * 日付文字列を YYYY-MM-DD に正規化する
 * 対応フォーマット:
 *   2025/7/10, 2025-7-10, 7/10（年を推定）,
 *   令和7年7月10日, R7.7.10
 *
 * @param {string} raw
 * @param {number} [baseYear]  年が省略された場合の基準年
 * @returns {string|null}      YYYY-MM-DD または null
 */
export function normalizeDate(raw, baseYear) {
  if (!raw) return null;
  const s = String(raw).trim();

  // YYYY/MM/DD または YYYY-MM-DD（ゼロパディング不要）
  let m = s.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
  if (m) {
    return `${m[1]}-${m[2].padStart(2,"0")}-${m[3].padStart(2,"0")}`;
  }

  // M/D または M-D（年を baseYear で補完）
  m = s.match(/^(\d{1,2})[\/\-](\d{1,2})$/);
  if (m) {
    const y = baseYear ?? new Date().getFullYear();
    return `${y}-${m[1].padStart(2,"0")}-${m[2].padStart(2,"0")}`;
  }

  // 令和 / 平成 / 昭和
  m = s.match(/^(?:令和|R)(\d{1,2})[\.\-年](\d{1,2})[\.\-月](\d{1,2})日?$/);
  if (m) {
    const y = 2018 + parseInt(m[1], 10); // 令和1=2019
    return `${y}-${m[2].padStart(2,"0")}-${m[3].padStart(2,"0")}`;
  }

  // YYYY年MM月DD日
  m = s.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日?$/);
  if (m) {
    return `${m[1]}-${m[2].padStart(2,"0")}-${m[3].padStart(2,"0")}`;
  }

  return null;
}

/**
 * CSV 文字列を行・列の 2D 配列に分割する
 * ダブルクォート内のカンマを正しく処理する
 *
 * @param {string} text  CSV テキスト
 * @param {string} [sep] 区切り文字（デフォルト: 自動検出）
 * @returns {string[][]}
 */
export function parseCSVToGrid(text, sep) {
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");

  // 区切り文字を自動検出（タブが多ければ TSV、なければ CSV）
  const delimiter = sep ?? (
    (lines[0]?.split("\t").length ?? 0) > (lines[0]?.split(",").length ?? 0)
      ? "\t"
      : ","
  );

  return lines
    .map((line) => {
      const cells = [];
      let cur = "";
      let inQ  = false;

      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
          if (inQ && line[i + 1] === '"') { cur += '"'; i++; }
          else { inQ = !inQ; }
        } else if (ch === delimiter && !inQ) {
          cells.push(cur.trim());
          cur = "";
        } else {
          cur += ch;
        }
      }
      cells.push(cur.trim());
      return cells;
    })
    .filter((row) => row.some((c) => c !== ""));
}

/**
 * ヘッダー行を解析してカラムインデックスを返す
 *
 * @param {string[]} headerRow
 * @returns {{ title, start, end, site, worker, memo }}
 */
function detectColumns(headerRow) {
  const h = headerRow.map((c) => String(c).toLowerCase());

  const find = (...keywords) => {
    const idx = h.findIndex((c) => keywords.some((k) => c.includes(k)));
    return idx >= 0 ? idx : null;
  };

  return {
    title:  find("工程", "作業", "title", "名称", "内容"),
    start:  find("開始", "start", "from", "着工"),
    end:    find("終了", "end", "to",   "完了", "竣工"),
    site:   find("現場", "物件", "site", "場所"),
    worker: find("担当", "業者", "職人", "worker", "作業者"),
    memo:   find("備考", "メモ", "note", "memo", "コメント"),
  };
}

/**
 * CSV / TSV テキストを工程オブジェクト配列に変換する（メイン関数）
 *
 * @param {string} text       CSV / TSV のテキスト
 * @param {object} [options]
 * @param {number} [options.baseYear]     日付の年が省略された場合の補完値
 * @param {boolean}[options.hasHeader]   1行目をヘッダーとして扱うか（デフォルト: true）
 * @returns {{
 *   schedules: Array,   正常にパースできた工程
 *   errors:    Array,   { row, message } 形式のエラー
 * }}
 */
export function parseScheduleText(text, options = {}) {
  const { baseYear = new Date().getFullYear(), hasHeader = true } = options;

  const grid     = parseCSVToGrid(text);
  if (grid.length === 0) return { schedules: [], errors: [] };

  // ヘッダー行からカラムを検出
  const headerRow = hasHeader ? grid[0] : null;
  const cols      = hasHeader
    ? detectColumns(headerRow)
    : { title: 0, start: 1, end: 2, site: 3, worker: 4, memo: 5 };

  const dataRows = hasHeader ? grid.slice(1) : grid;
  const schedules = [];
  const errors    = [];

  dataRows.forEach((row, rowIdx) => {
    const lineNum = rowIdx + (hasHeader ? 2 : 1);

    const title  = cols.title  !== null ? (row[cols.title]  ?? "") : "";
    const start  = cols.start  !== null ? (row[cols.start]  ?? "") : "";
    const end    = cols.end    !== null ? (row[cols.end]    ?? "") : "";
    const site   = cols.site   !== null ? (row[cols.site]   ?? "") : "";
    const worker = cols.worker !== null ? (row[cols.worker] ?? "") : "";
    const memo   = cols.memo   !== null ? (row[cols.memo]   ?? "") : "";

    // 空行はスキップ
    if (!title && !start) return;

    const startNorm = normalizeDate(start, baseYear);
    const endNorm   = normalizeDate(end,   baseYear) ?? startNorm; // 終了省略は開始と同日

    if (!startNorm) {
      errors.push({ row: lineNum, message: `${lineNum}行目: 開始日「${start}」を解析できません` });
      return;
    }

    schedules.push({
      id:          uid(),
      title:       title  || site || "工程",
      start:       startNorm,
      end:         endNorm,
      // db.schedules の形式に合わせたフィールドも付与
      startDate:   startNorm,
      endDate:     endNorm,
      processName: title,
      processType: detectProcessType(title),
      siteName:    site,
      contractor:  worker,
      note:        memo,
      source:      "csv",
      confirmed:   false,
      createdAt:   Date.now(),
      raw: { title, start, end, site, worker, memo }, // デバッグ用
    });
  });

  return { schedules, errors };
}

/**
 * File オブジェクトからテキストを読み込んでパースする
 *
 * @param {File}    file
 * @param {object} [options]  parseScheduleText と同じ
 * @returns {Promise<{ schedules, errors }>}
 */
export function parseScheduleFile(file, options = {}) {
  return new Promise((resolve, reject) => {
    const reader   = new FileReader();
    reader.onload  = (e) => {
      try {
        const text   = e.target.result;
        const result = parseScheduleText(text, options);
        resolve(result);
      } catch (err) {
        reject(new Error(`ファイルの解析に失敗しました: ${err.message}`));
      }
    };
    reader.onerror = () => reject(new Error("ファイルの読み込みに失敗しました"));

    // Excel (xlsx) は SheetJS が別途必要なため、CSV/TSV のみ対応
    if (file.name.match(/\.(xlsx?|xls)$/i)) {
      reject(new Error("Excel ファイルは直接読み込めません。CSVとして保存してから読み込んでください。"));
      return;
    }

    reader.readAsText(file, "UTF-8");
  });
}
