// src/utils/googleCalendar.js
// ============================================================
// Google Calendar 連携ユーティリティ — Phase 8-B
//
// 【責務】スケジュール → ICS 生成 / Google API ラッパー
// 【UI なし】呼び出し元のコンポーネントが結果を表示する
//
// 【現在の実装】
//   - ICS ファイル生成（Google Calendar の「インポート」機能で登録）
//   - Google Calendar API ラッパー（apiKey 設定後に有効化）
//
// 【将来の差し替え箇所】
//   GoogleCalendarAPI クラスの send() を実際の API 呼び出しに変更する
//   それ以外のコードは変更不要
// ============================================================

// ================================================================
// ICS ヘルパー関数
// ================================================================

/** YYYY-MM-DD → YYYYMMDD */
function toICSDate(dateStr) {
  return String(dateStr ?? "").replace(/-/g, "");
}

/** 終了日 +1 日（ICS 終日イベントの仕様） */
function toICSEndDate(dateStr) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

/** ICS 用テキストエスケープ */
function esc(str) {
  return String(str ?? "")
    .replace(/\\/g, "\\\\")
    .replace(/;/g,  "\\;")
    .replace(/,/g,  "\\,")
    .replace(/\n/g, "\\n");
}

/** ICS 用 UID 生成 */
function makeUID(id) {
  return `gstock-${id ?? Date.now()}-${Math.random().toString(36).slice(2, 8)}@gstock.app`;
}

/** 現在時刻を ICS の DTSTAMP 形式で返す */
function nowStamp() {
  return new Date()
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");
}

// ================================================================
// ICS ビルダー（Google / Apple 共通）
// ================================================================

/**
 * スケジュール配列から ICS 文字列を生成する
 *
 * @param {Array}  schedules  db.schedules の配列
 * @param {string} [calName]  カレンダー名
 * @returns {string}          ICS 形式文字列
 */
export function buildICS(schedules, calName = "G Stock 工程") {
  const stamp  = nowStamp();
  const events = (schedules ?? []).map((s) => {
    const summary = [
      s.siteName, s.buildingName, s.wingName,
      s.floor, s.room, s.processName,
    ]
      .filter(Boolean)
      .join(" ");

    const descParts = [
      s.processType  ? `種別: ${s.processType}`   : "",
      s.contractor   ? `担当: ${s.contractor}`     : "",
      s.projectName  ? `工事名: ${s.projectName}` : "",
      s.note         ? `備考: ${s.note}`           : "",
    ].filter(Boolean);

    const location = [s.siteName, s.buildingName, s.floor]
      .filter(Boolean)
      .join(" ");

    return [
      "BEGIN:VEVENT",
      `UID:${makeUID(s.id)}`,
      `DTSTAMP:${stamp}Z`,
      `DTSTART;VALUE=DATE:${toICSDate(s.startDate)}`,
      `DTEND;VALUE=DATE:${toICSEndDate(s.endDate)}`,
      `SUMMARY:${esc(summary)}`,
      descParts.length > 0
        ? `DESCRIPTION:${esc(descParts.join("\\n"))}`
        : "",
      location ? `LOCATION:${esc(location)}` : "",
      "STATUS:CONFIRMED",
      "END:VEVENT",
    ]
      .filter(Boolean)
      .join("\r\n");
  });

  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//GStock//GStock V2//JA",
    `X-WR-CALNAME:${esc(calName)}`,
    "X-WR-TIMEZONE:Asia/Tokyo",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    ...events,
    "END:VCALENDAR",
  ].join("\r\n");
}

// ================================================================
// ダウンロード関数
// ================================================================

/**
 * db.schedules を ICS ファイルとしてダウンロードする
 * Google Calendar の「インポート」またはブラウザの開封で登録できる
 *
 * @param {object} db
 */
export function exportSchedulesToICS(db) {
  const schedules = db?.schedules ?? [];
  if (schedules.length === 0) {
    alert("エクスポートする工程がありません");
    return;
  }
  _download(
    buildICS(schedules, "G Stock 工程"),
    "text/calendar;charset=utf-8",
    `gstock_schedule_${_today()}.ics`
  );
}

/**
 * 単一スケジュールを ICS としてダウンロードする
 *
 * @param {object} schedule
 */
export function exportSingleToICS(schedule) {
  const summary = [schedule.siteName, schedule.processName]
    .filter(Boolean)
    .join("_");
  _download(
    buildICS([schedule]),
    "text/calendar;charset=utf-8",
    `gstock_${summary}_${_today()}.ics`
  );
}

// ================================================================
// Google Calendar API ラッパー
// 将来: apiKey と clientId を .env に設定して有効化
// ================================================================

/**
 * Google Calendar API クライアント
 *
 * 【使い方】
 * 1. .env に VITE_GOOGLE_API_KEY と VITE_GOOGLE_CLIENT_ID を追加
 * 2. GoogleCalendarClient.init() を呼ぶ
 * 3. addEvent() / updateEvent() / deleteEvent() を使う
 */
export class GoogleCalendarClient {
  constructor() {
    this._apiKey    = import.meta.env?.VITE_GOOGLE_API_KEY    ?? "";
    this._clientId  = import.meta.env?.VITE_GOOGLE_CLIENT_ID  ?? "";
    this._calendarId = import.meta.env?.VITE_GOOGLE_CALENDAR_ID ?? "primary";
    this._initialized = false;
  }

  get isConfigured() {
    return !!(this._apiKey && this._clientId);
  }

  /**
   * Google API クライアントを初期化する
   * @returns {Promise<boolean>}
   */
  async init() {
    if (!this.isConfigured) return false;
    // 将来の実装:
    // await loadScript("https://apis.google.com/js/api.js");
    // await gapi.load("client:auth2");
    // await gapi.client.init({ apiKey, clientId, scope: SCOPE });
    this._initialized = false; // 未実装
    return false;
  }

  /**
   * スケジュールを Google Calendar に追加する
   * @param {object} schedule  db.schedules の1件
   * @returns {Promise<string|null>}  Google Event ID または null
   */
  async addEvent(schedule) {
    if (!this._initialized) {
      console.warn("[GoogleCalendar] 未初期化。ICS エクスポートを使用してください。");
      return null;
    }
    // 将来の実装:
    // const event = _toGoogleEvent(schedule);
    // const res   = await gapi.client.calendar.events.insert({
    //   calendarId: this._calendarId,
    //   resource:   event,
    // });
    // return res.result.id;
    return null;
  }

  /**
   * Google Calendar のイベントを更新する
   * @param {string} googleEventId
   * @param {object} schedule
   * @returns {Promise<boolean>}
   */
  async updateEvent(googleEventId, schedule) {
    if (!this._initialized) return false;
    // 将来の実装:
    // await gapi.client.calendar.events.update({
    //   calendarId: this._calendarId,
    //   eventId:    googleEventId,
    //   resource:   _toGoogleEvent(schedule),
    // });
    return false;
  }

  /**
   * Google Calendar のイベントを削除する
   * @param {string} googleEventId
   * @returns {Promise<boolean>}
   */
  async deleteEvent(googleEventId) {
    if (!this._initialized) return false;
    // 将来の実装:
    // await gapi.client.calendar.events.delete({
    //   calendarId: this._calendarId,
    //   eventId:    googleEventId,
    // });
    return false;
  }

  /**
   * 複数スケジュールを一括追加する
   * @param {Array} schedules
   * @returns {Promise<string[]>}  追加できた Google Event ID の配列
   */
  async addAllEvents(schedules) {
    const ids = [];
    for (const s of schedules) {
      const id = await this.addEvent(s);
      if (id) ids.push(id);
    }
    return ids;
  }
}

// ── Google Calendar イベント形式への変換（将来の実装用） ─────
// function _toGoogleEvent(schedule) {
//   const summary = [schedule.siteName, schedule.processName].filter(Boolean).join(" ");
//   return {
//     summary,
//     location:    schedule.siteName,
//     description: [
//       schedule.processType ? `種別: ${schedule.processType}` : "",
//       schedule.contractor  ? `担当: ${schedule.contractor}`  : "",
//       schedule.note        ? `備考: ${schedule.note}`        : "",
//     ].filter(Boolean).join("\n"),
//     start: { date: schedule.startDate },
//     end:   { date: _addDay(schedule.endDate) },
//   };
// }
// function _addDay(dateStr) {
//   const d = new Date(dateStr); d.setDate(d.getDate() + 1);
//   return d.toISOString().slice(0, 10);
// }

// シングルトンインスタンス（アプリ全体で共有）
export const googleCalendarClient = new GoogleCalendarClient();

// ── 内部ヘルパー ──────────────────────────────────────────────
function _download(content, mimeType, fileName) {
  const blob = new Blob([content], { type: mimeType });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement("a"), {
    href: url, download: fileName,
  });
  a.click();
  URL.revokeObjectURL(url);
}

function _today() {
  return new Date().toISOString().slice(0, 10);
}
