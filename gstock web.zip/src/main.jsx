// src/main.jsx
import React       from "react";
import { createRoot } from "react-dom/client";
import App         from "./App.jsx";

// グローバルスタイル（Vite では CSS ファイルより JSX 内インラインスタイルで管理）
const globalStyle = document.createElement("style");
globalStyle.textContent = `
  * {
    box-sizing:              border-box;
    -webkit-tap-highlight-color: transparent;
  }
  html, body {
    margin:                  0;
    padding:                 0;
    background:              #0A0A0A;
    color:                   #F5F3EF;
    font-family:
      'Hiragino Sans',
      'Hiragino Kaku Gothic ProN',
      'Noto Sans JP',
      -apple-system,
      BlinkMacSystemFont,
      sans-serif;
    -webkit-font-smoothing:  antialiased;
    overscroll-behavior:     none;
  }
  #root {
    min-height: 100dvh;
  }
  input, textarea, select {
    font-family: inherit;
    font-size:   16px; /* iOS でズームしないように 16px 以上に設定 */
  }
  ::-webkit-scrollbar {
    width:  0;
    height: 0;
  }
  input[type="date"] {
    color-scheme: dark;
  }
  select option {
    background: #1A1816;
  }
`;
document.head.appendChild(globalStyle);

const root = createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
