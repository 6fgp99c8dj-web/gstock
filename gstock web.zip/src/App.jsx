// src/App.jsx
// ============================================================
// Phase 9 統合版
// - 全ルーティング確認済み
// - useNotification をアプリ起動時に初期化
// - CalendarScreen への navigate("calendar-screen") 接続
// - 未使用の useEffect / SUB_SCREENS を削除
// ============================================================
import React, { useState, useCallback } from "react";
import { DBProvider }     from "./context/DBContext.jsx";
import BottomNavigation   from "./components/BottomNavigation.jsx";
import AppNotificationInit from "./components/AppNotificationInit.jsx";

// ── タブ画面 ────────────────────────────────────────────────
import Home          from "./pages/Home.jsx";
import Inventory     from "./pages/Inventory.jsx";
import Sites         from "./pages/Sites.jsx";
import Attendance    from "./pages/Attendance.jsx";
import Photos        from "./pages/Photos.jsx";
import Settings      from "./pages/Settings.jsx";
import ProcessScreen from "./pages/ProcessScreen.jsx";
import AIScreen      from "./pages/sub/AIScreen.jsx";

// ── サブ画面 ────────────────────────────────────────────────
import OcrScreen        from "./pages/sub/OcrScreen.jsx";
import ScheduleScreen   from "./pages/sub/ScheduleScreen.jsx";
import QRScreen         from "./pages/sub/QRScreen.jsx";
import CategoriesScreen from "./pages/sub/CategoriesScreen.jsx";
import ProductsScreen   from "./pages/sub/ProductsScreen.jsx";
import LineScreen       from "./pages/sub/LineScreen.jsx";
import ProfileScreen    from "./pages/sub/ProfileScreen.jsx";
import CalendarScreen   from "./pages/sub/CalendarScreen.jsx";

// BottomNav のタブキー（これに含まれる場合はスタックをリセット）
const BOTTOM_TABS = [
  "home", "inventory", "sites", "calendar",
  "attendance", "ai", "settings",
];

// ================================================================
// App ルート
// ================================================================
export default function App() {
  const [tab,   setTab]   = useState("home");
  const [stack, setStack] = useState([]);

  const currentScreen = stack.length > 0 ? stack[stack.length - 1].screen : tab;
  const currentParams = stack.length > 0 ? stack[stack.length - 1].params : undefined;

  /** 画面遷移 */
  const navigate = useCallback((screen, params) => {
    if (BOTTOM_TABS.includes(screen)) {
      setStack([]);
      setTab(screen);
    } else {
      setStack((prev) => [...prev, { screen, params }]);
    }
  }, []);

  /** 戻る */
  const goBack = useCallback(() => {
    setStack((prev) => prev.slice(0, -1));
  }, []);

  /** BottomNav タブ切り替え */
  const handleTabChange = useCallback((key) => {
    setStack([]);
    setTab(key);
  }, []);

  return (
    <DBProvider>
      <div
        style={{
          minHeight:  "100vh",
          background: "#0A0A0A",
          fontFamily:
            "'Hiragino Sans','Hiragino Kaku Gothic ProN','Noto Sans JP'," +
            "-apple-system,BlinkMacSystemFont,sans-serif",
          maxWidth:   520,
          margin:     "0 auto",
          position:   "relative",
          paddingTop: "env(safe-area-inset-top)",
        }}
      >
        {/* グローバル CSS */}
        <style>{`
          * { -webkit-tap-highlight-color: transparent; box-sizing: border-box; }
          input[type="date"] { color-scheme: dark; }
          select option      { background: #1A1816; }
          ::-webkit-scrollbar { width: 0; height: 0; }
          @keyframes gstock-spin {
            from { transform: rotate(0deg); }
            to   { transform: rotate(360deg); }
          }
          @keyframes gstock-scan {
            0%   { top: 12%; }
            50%  { top: 84%; }
            100% { top: 12%; }
          }
        `}</style>

        {/* 通知初期化（UI なし・DBContext 内で動作） */}
        <AppNotificationInit />

        {/* 画面レンダリング */}
        <ScreenRouter
          screen={currentScreen}
          params={currentParams}
          navigate={navigate}
          goBack={goBack}
        />

        {/* BottomNavigation：サブ画面では非表示 */}
        {stack.length === 0 && (
          <BottomNavigation currentTab={tab} onTabChange={handleTabChange} />
        )}
      </div>
    </DBProvider>
  );
}

// ================================================================
// ScreenRouter — 全ルーティング一覧
// ================================================================
function ScreenRouter({ screen, params, navigate, goBack }) {
  const props = { navigate, onBack: goBack, params };

  switch (screen) {
    // ── BottomNav タブ画面 ─────────────────────────────────
    case "home":        return <Home          {...props} />;
    case "inventory":   return <Inventory     {...props} />;
    case "sites":       return <Sites         {...props} />;
    case "calendar":    return <ProcessScreen {...props} />;  // 工程タブ
    case "attendance":  return <Attendance    {...props} />;
    case "ai":          return <AIScreen      {...props} />;
    case "settings":    return <Settings      {...props} />;

    // ── サブ画面（スタックで管理） ──────────────────────────
    case "photos":           return <Photos          {...props} />;
    case "ocr":              return <OcrScreen        {...props} />;
    case "schedule":         return <ScheduleScreen   {...props} />;
    case "calendar-screen":  return <CalendarScreen   {...props} />;  // 月表示カレンダー
    case "qr":               return <QRScreen         {...props} />;
    case "categories":       return <CategoriesScreen {...props} />;
    case "products":         return <ProductsScreen   {...props} />;
    case "line":             return <LineScreen       {...props} />;
    case "profile":          return <ProfileScreen    {...props} />;

    default: return <Home {...props} />;
  }
}
