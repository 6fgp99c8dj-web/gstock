// src/components/EmptyState.jsx
import React from "react";
import { T } from "./tokens.js";

/**
 * データが0件のときに表示するプレースホルダー
 *
 * @param {Component} icon
 * @param {string}    text   メインメッセージ
 * @param {string}   [sub]   サブメッセージ
 */
export default function EmptyState({ icon: Icon, text, sub }) {
  return (
    <div
      style={{
        display:        "flex",
        flexDirection:  "column",
        alignItems:     "center",
        padding:        "60px 30px",
        textAlign:      "center",
        gap:            10,
      }}
    >
      {Icon && (
        <Icon size={36} color={T.whiteFaint} strokeWidth={1.5} />
      )}
      <div style={{ color: T.whiteDim, fontSize: 15, fontWeight: 600 }}>
        {text}
      </div>
      {sub && (
        <div style={{ color: T.whiteFaint, fontSize: 13 }}>
          {sub}
        </div>
      )}
    </div>
  );
}
