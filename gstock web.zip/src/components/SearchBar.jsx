// src/components/SearchBar.jsx
import React from "react";
import { Search, X } from "lucide-react";
import { T, iconBtnStyle } from "./tokens.js";

/**
 * 検索バー
 *
 * @param {string}   value
 * @param {Function} onChange     (value: string) => void
 * @param {string}  [placeholder]
 */
export default function SearchBar({ value, onChange, placeholder = "検索" }) {
  return (
    <div
      style={{
        display:      "flex",
        alignItems:   "center",
        gap:          8,
        background:   T.bgElevated,
        border:       `1px solid ${T.cardBorder}`,
        borderRadius: 14,
        padding:      "10px 14px",
        margin:       "10px 16px",
      }}
    >
      <Search size={18} color={T.whiteFaint} />

      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          flex:       1,
          background: "transparent",
          border:     "none",
          outline:    "none",
          color:      T.white,
          fontSize:   15,
        }}
      />

      {value && (
        <button
          onClick={() => onChange("")}
          style={{ ...iconBtnStyle, padding: 4, margin: -4 }}
          aria-label="クリア"
        >
          <X size={16} color={T.whiteFaint} />
        </button>
      )}
    </div>
  );
}
