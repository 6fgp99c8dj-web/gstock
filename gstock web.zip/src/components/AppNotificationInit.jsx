// src/components/AppNotificationInit.jsx
// UI なし・通知初期化専用コンポーネント
// App.jsx の DBProvider 内に配置してアプリ起動時に通知をスケジュールする
import { useEffect, useCallback } from "react";
import { useDB }           from "../context/DBContext.jsx";
import { useNotification } from "../hooks/useNotification.js";

export default function AppNotificationInit() {
  const { db }   = useDB();
  const settings = db.settings ?? {};

  const { permission, checkAndNotify, scheduleAll } = useNotification(db, settings);

  // useCallback でラップして deps に含められるようにする
  const init = useCallback(() => {
    if (permission === "granted" && settings.notifyEnabled) {
      checkAndNotify();
      scheduleAll();
    }
  }, [permission, settings.notifyEnabled, checkAndNotify, scheduleAll]);

  // 起動時 + schedules 変更時に実行
  useEffect(() => {
    init();
  }, [init, db.schedules?.length]); // eslint-disable-line react-hooks/exhaustive-deps

  return null;
}
