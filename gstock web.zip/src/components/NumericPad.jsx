// src/components/NumericPad.jsx
import React, { useState, useEffect } from "react";
import { T } from "./tokens.js";
import Modal from "./Modal.jsx";
import { PrimaryButton } from "./Card.jsx";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "←"];

/**
 * 在庫数直接入力テンキー
 *
 * @param {object|null} target   対象商品オブジェクト（null で非表示）
 *   target: { id, name, unit, arrival, used }
 * @param {Function}    onSave   (productId: string, newStock: number) => void
 * @param {Function}    onClose
 */
export default function NumericPad({ target, onSave, onClose }) {
  const [val, setVal] = useState("");

  // target が変わるたびに現在の在庫数でリセット
  useEffect(() => {
    if (target) {
      setVal(String(target.arrival - target.used));
    }
  }, [target]);

  if (!target) return null;

  const handleKey = (k) => {
    if (k === "←") return setVal((v) => v.slice(0, -1));
    if (k === "C")  return setVal("");
    setVal((v) => (v + k).slice(0, 6)); // 最大6桁
  };

  const handleSave = () => {
    onSave(target.id, Number(val) || 0);
    onClose();
  };

  return (
    <Modal open={!!target} onClose={onClose} title={target.name}>
      {/* 表示値 */}
      <div style={{ textAlign: "center", padding: "10px 0 20px" }}>
        <span style={{ fontSize: 48, fontWeight: 800, color: T.goldBright }}>
          {val || "0"}
        </span>
        <span style={{ fontSize: 16, color: T.whiteFaint, marginLeft: 8 }}>
          {target.unit}
        </span>
      </div>

      {/* テンキー 3×4 */}
      <div
        style={{
          display:             "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap:                 10,
        }}
      >
        {KEYS.map((k) => (
          <button
            key={k}
            onClick={() => handleKey(k)}
            style={{
              padding:                 "17px 0",
              borderRadius:            12,
              background:              T.card,
              border:                  `1px solid ${T.cardBorder}`,
              color:                   k === "C" ? T.goldBright : T.white,
              fontSize:                20,
              fontWeight:              700,
              cursor:                  "pointer",
              WebkitTapHighlightColor: "transparent",
            }}
          >
            {k}
          </button>
        ))}
      </div>

      <div style={{ marginTop: 14 }}>
        <PrimaryButton onClick={handleSave}>在庫数を更新</PrimaryButton>
      </div>
    </Modal>
  );
}
