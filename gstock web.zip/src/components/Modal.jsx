// src/components/Modal.jsx
import React, { useEffect } from "react";
import { X } from "lucide-react";
import { T, iconBtnStyle } from "./tokens.js";
import TopBar from "./TopBar.jsx";

/**
 * モーダル（ボトムシート or フルスクリーン）
 *
 * @param {boolean}   open
 * @param {Function}  onClose
 * @param {string}    title
 * @param {ReactNode} children
 * @param {boolean}  [fullScreen]  true のときフルスクリーン表示
 */
export default function Modal({ open, onClose, title, children, fullScreen }) {
  // 背景スクロールのロック
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  if (!open) return null;

  // ── フルスクリーンモード ─────────────────────────────────────
  if (fullScreen) {
    return (
      <div
        style={{
          position:  "fixed",
          inset:     0,
          zIndex:    100,
          background: T.bg,
          overflowY: "auto",
        }}
      >
        <div style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
          <TopBar title={title} onBack={onClose} />
          {children}
        </div>
      </div>
    );
  }

  // ── ボトムシートモード ───────────────────────────────────────
  return (
    <div
      onClick={onClose}
      style={{
        position:       "fixed",
        inset:          0,
        zIndex:         100,
        display:        "flex",
        flexDirection:  "column",
        justifyContent: "flex-end",
        background:     "rgba(0,0,0,0.65)",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background:   T.bgElevated,
          borderRadius: "22px 22px 0 0",
          padding:      "10px 18px",
          paddingBottom: "calc(20px + env(safe-area-inset-bottom))",
          maxHeight:    "90vh",
          overflowY:    "auto",
          border:       `1px solid ${T.cardBorder}`,
          borderBottom: "none",
        }}
      >
        {/* ドラッグハンドル */}
        <div
          style={{
            width:        40,
            height:       4,
            borderRadius: 2,
            background:   T.cardBorder,
            margin:       "6px auto 14px",
          }}
        />

        {/* ヘッダー */}
        <div
          style={{
            display:        "flex",
            alignItems:     "center",
            justifyContent: "space-between",
            marginBottom:   16,
          }}
        >
          <div style={{ fontSize: 17, fontWeight: 700, color: T.white }}>
            {title}
          </div>
          <button onClick={onClose} style={iconBtnStyle} aria-label="閉じる">
            <X size={22} color={T.whiteDim} />
          </button>
        </div>

        {children}
      </div>
    </div>
  );
}
