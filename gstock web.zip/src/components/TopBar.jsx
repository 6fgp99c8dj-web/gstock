// src/components/TopBar.jsx
import React from "react";
import { ArrowLeft } from "lucide-react";
import { T, iconBtnStyle } from "./tokens.js";

/**
 * 全画面共通ヘッダー
 *
 * @param {string}    title   中央タイトル
 * @param {string}   [sub]    タイトル下のサブテキスト
 * @param {Function} [onBack] 指定時のみ左に戻るボタンを表示
 * @param {ReactNode}[right]  右端に配置するアクション
 */
export default function TopBar({ title, sub, onBack, right }) {
  return (
    <div
      style={{
        display:        "flex",
        alignItems:     "center",
        justifyContent: "space-between",
        padding:        "14px 16px",
        position:       "sticky",
        top:            0,
        zIndex:         20,
        background:     "rgba(10,10,10,0.94)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
        borderBottom:   `1px solid ${T.cardBorder}`,
      }}
    >
      {/* 左：戻るボタン（44px タップ領域） */}
      <div style={{ minWidth: 44, display: "flex", alignItems: "center" }}>
        {onBack && (
          <button onClick={onBack} style={iconBtnStyle} aria-label="戻る">
            <ArrowLeft size={22} color={T.gold} />
          </button>
        )}
      </div>

      {/* 中央：タイトル */}
      <div style={{ textAlign: "center", flex: 1 }}>
        <div style={{ fontSize: 17, fontWeight: 700, color: T.white, lineHeight: 1.2 }}>
          {title}
        </div>
        {sub && (
          <div style={{ fontSize: 11, color: T.whiteFaint, marginTop: 2 }}>
            {sub}
          </div>
        )}
      </div>

      {/* 右：カスタムアクション */}
      <div style={{ minWidth: 44, display: "flex", justifyContent: "flex-end" }}>
        {right}
      </div>
    </div>
  );
}
