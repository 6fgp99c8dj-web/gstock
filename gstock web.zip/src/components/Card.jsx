// src/components/Card.jsx
// 汎用カード / フォームUI / ボタン / バッジ / ステップ表示
import React from "react";
import { RefreshCw } from "lucide-react";
import { T, iconBtnStyle, processColor } from "./tokens.js";
import Modal from "./Modal.jsx";

// ================================================================
// ホーム画面グリッドカード
// ================================================================
export function HomeCard({ icon: Icon, label, sub, onClick, badge }) {
  return (
    <button
      onClick={onClick}
      style={{
        background:              T.card,
        border:                  `1px solid ${T.cardBorder}`,
        borderRadius:            20,
        padding:                 "20px 16px",
        display:                 "flex",
        flexDirection:           "column",
        alignItems:              "flex-start",
        gap:                     10,
        cursor:                  "pointer",
        WebkitTapHighlightColor: "transparent",
        textAlign:               "left",
        position:                "relative",
        width:                   "100%",
      }}
    >
      {/* バッジ */}
      {badge != null && Number(badge) > 0 && (
        <div
          style={{
            position:     "absolute",
            top:          12,
            right:        12,
            background:   T.gold,
            color:        "#15120C",
            fontSize:     11,
            fontWeight:   800,
            borderRadius: 10,
            padding:      "2px 7px",
            minWidth:     20,
            textAlign:    "center",
          }}
        >
          {badge}
        </div>
      )}

      {/* アイコン背景 */}
      <div
        style={{
          width:          46,
          height:         46,
          borderRadius:   13,
          background:     T.bgElevated,
          display:        "flex",
          alignItems:     "center",
          justifyContent: "center",
        }}
      >
        <Icon size={24} color={T.gold} strokeWidth={1.8} />
      </div>

      {/* テキスト */}
      <div>
        <div style={{ fontSize: 16, fontWeight: 700, color: T.white }}>
          {label}
        </div>
        {sub && (
          <div style={{ fontSize: 12, color: T.whiteFaint, marginTop: 2 }}>
            {sub}
          </div>
        )}
      </div>
    </button>
  );
}

// ================================================================
// カテゴリ / フィルタ チップ
// ================================================================
export function CatChip({ active, onClick, label }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding:                 "8px 16px",
        borderRadius:            20,
        whiteSpace:              "nowrap",
        flexShrink:              0,
        border:                  `1px solid ${active ? T.gold : T.cardBorder}`,
        background:              active ? `${T.gold}1F` : "transparent",
        color:                   active ? T.goldBright : T.whiteDim,
        fontSize:                13,
        fontWeight:              700,
        cursor:                  "pointer",
        WebkitTapHighlightColor: "transparent",
      }}
    >
      {label}
    </button>
  );
}

// ================================================================
// 2分割タブ
// ================================================================
export function TabButton({ active, onClick, label }) {
  return (
    <button
      onClick={onClick}
      style={{
        flex:                    1,
        padding:                 "11px 0",
        borderRadius:            12,
        border:                  `1px solid ${active ? T.gold : T.cardBorder}`,
        background:              active ? `${T.gold}1A` : "transparent",
        color:                   active ? T.goldBright : T.whiteDim,
        fontSize:                13,
        fontWeight:              700,
        cursor:                  "pointer",
        WebkitTapHighlightColor: "transparent",
      }}
    >
      {label}
    </button>
  );
}

// ================================================================
// テキストフィールド
// ================================================================
export function TextField({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  autoFocus,
}) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && (
        <div
          style={{
            fontSize:     12,
            color:        T.whiteFaint,
            marginBottom: 6,
            fontWeight:   600,
          }}
        >
          {label}
        </div>
      )}
      <input
        autoFocus={autoFocus}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width:        "100%",
          boxSizing:    "border-box",
          background:   T.card,
          border:       `1px solid ${T.cardBorder}`,
          borderRadius: 12,
          padding:      "13px 14px",
          color:        T.white,
          fontSize:     16,
          outline:      "none",
        }}
      />
    </div>
  );
}

// ================================================================
// テキストエリア
// ================================================================
export function TextArea({
  label,
  value,
  onChange,
  placeholder,
  rows = 3,
}) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && (
        <div
          style={{
            fontSize:     12,
            color:        T.whiteFaint,
            marginBottom: 6,
            fontWeight:   600,
          }}
        >
          {label}
        </div>
      )}
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        style={{
          width:        "100%",
          boxSizing:    "border-box",
          background:   T.card,
          border:       `1px solid ${T.cardBorder}`,
          borderRadius: 12,
          padding:      "13px 14px",
          color:        T.white,
          fontSize:     15,
          outline:      "none",
          resize:       "vertical",
          fontFamily:   "inherit",
        }}
      />
    </div>
  );
}

// ================================================================
// プライマリボタン
// ================================================================
export function PrimaryButton({
  children,
  onClick,
  disabled,
  danger,
  loading,
}) {
  const isDisabled = disabled || loading;

  return (
    <button
      onClick={onClick}
      disabled={isDisabled}
      style={{
        width:                   "100%",
        padding:                 "15px",
        borderRadius:            14,
        border:                  "none",
        background:              isDisabled
          ? T.cardBorder
          : danger
          ? T.danger
          : `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`,
        color:                   isDisabled
          ? T.whiteFaint
          : danger
          ? T.white
          : "#15120C",
        fontSize:                16,
        fontWeight:              700,
        cursor:                  isDisabled ? "default" : "pointer",
        WebkitTapHighlightColor: "transparent",
        display:                 "flex",
        alignItems:              "center",
        justifyContent:          "center",
        gap:                     8,
      }}
    >
      {loading && (
        <RefreshCw
          size={18}
          style={{ animation: "gstock-spin 1s linear infinite" }}
        />
      )}
      {children}
    </button>
  );
}

// ================================================================
// ゴーストボタン（サブアクション）
// ================================================================
export function GhostButton({ children, onClick, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        width:                   "100%",
        padding:                 "13px",
        borderRadius:            14,
        border:                  `1px solid ${T.cardBorder}`,
        background:              "transparent",
        color:                   T.whiteDim,
        fontSize:                15,
        fontWeight:              600,
        marginTop:               8,
        cursor:                  "pointer",
        WebkitTapHighlightColor: "transparent",
      }}
    >
      {children}
    </button>
  );
}

// ================================================================
// 削除確認モーダル（共通）
// ================================================================
export function ConfirmDeleteModal({ open, onClose, onConfirm, itemName }) {
  return (
    <Modal open={open} onClose={onClose} title="削除確認">
      <div style={{ color: T.whiteDim, fontSize: 14, marginBottom: 18 }}>
        「{itemName}」を削除します。元に戻せません。
      </div>
      <PrimaryButton danger onClick={onConfirm}>
        削除する
      </PrimaryButton>
      <GhostButton onClick={onClose}>キャンセル</GhostButton>
    </Modal>
  );
}

// ================================================================
// 工程種別バッジ
// ================================================================
export function ProcessBadge({ type }) {
  const color = processColor(type);
  return (
    <span
      style={{
        background:   color + "2A",
        color,
        border:       `1px solid ${color}40`,
        borderRadius: 8,
        padding:      "2px 8px",
        fontSize:     11,
        fontWeight:   700,
      }}
    >
      {type || "その他"}
    </span>
  );
}

// ================================================================
// OCR ステップインジケーター
// ================================================================
export function StepIndicator({ steps, current }) {
  return (
    <div style={{ display: "flex", alignItems: "center", padding: "12px 16px" }}>
      {steps.map((label, i) => (
        <React.Fragment key={i}>
          {/* ステップ丸 */}
          <div
            style={{
              display:       "flex",
              flexDirection: "column",
              alignItems:    "center",
              gap:           4,
            }}
          >
            <div
              style={{
                width:          28,
                height:         28,
                borderRadius:   14,
                display:        "flex",
                alignItems:     "center",
                justifyContent: "center",
                background:
                  i < current
                    ? T.gold
                    : i === current
                    ? T.goldBright
                    : T.cardBorder,
                color:      i <= current ? "#15120C" : T.whiteFaint,
                fontSize:   12,
                fontWeight: 800,
              }}
            >
              {i < current ? "✓" : i + 1}
            </div>
            <div
              style={{
                fontSize:   10,
                color:      i === current ? T.gold : T.whiteFaint,
                fontWeight: i === current ? 700 : 400,
                whiteSpace: "nowrap",
              }}
            >
              {label}
            </div>
          </div>

          {/* ステップ間の線 */}
          {i < steps.length - 1 && (
            <div
              style={{
                flex:         1,
                height:       2,
                background:   i < current ? T.gold : T.cardBorder,
                marginBottom: 16,
              }}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}
