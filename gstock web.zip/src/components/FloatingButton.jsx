// src/components/FloatingButton.jsx
import React from "react";
import { Plus } from "lucide-react";
import { T } from "./tokens.js";

/**
 * 画面右下 FAB（Floating Action Button）
 * BottomNavigation 分の高さを考慮した bottom 値を使用
 *
 * @param {Function}  onClick
 * @param {Component} [icon]    デフォルト: Plus
 * @param {string}   [bottom]   CSS bottom 値
 */
export default function FloatingButton({
  onClick,
  icon: Icon = Plus,
  bottom = "calc(80px + env(safe-area-inset-bottom))",
}) {
  return (
    <button
      onClick={onClick}
      aria-label="追加"
      style={{
        position:                "fixed",
        right:                   18,
        bottom,
        width:                   58,
        height:                  58,
        borderRadius:            29,
        background:              `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`,
        border:                  "none",
        display:                 "flex",
        alignItems:              "center",
        justifyContent:          "center",
        boxShadow:               "0 6px 20px rgba(201,169,97,0.35), 0 2px 6px rgba(0,0,0,0.3)",
        zIndex:                  30,
        WebkitTapHighlightColor: "transparent",
        cursor:                  "pointer",
      }}
    >
      <Icon size={26} color="#15120C" strokeWidth={2.4} />
    </button>
  );
}
