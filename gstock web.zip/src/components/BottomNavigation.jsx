// src/components/BottomNavigation.jsx
import React from "react";
import { Home, Package, MapPin, Calendar, Users, Settings, Bot } from "lucide-react";
import { T } from "./tokens.js";

// Phase 6: 「AI」タブを追加（設定の前）
const TABS = [
  { key: "home",       label: "ホーム",  Icon: Home     },
  { key: "inventory",  label: "在庫",    Icon: Package  },
  { key: "sites",      label: "現場",    Icon: MapPin   },
  { key: "calendar",   label: "工程",    Icon: Calendar },
  { key: "attendance", label: "出面",    Icon: Users    },
  { key: "ai",         label: "AI",      Icon: Bot      },
  { key: "settings",   label: "設定",    Icon: Settings },
];

/**
 * 画面下部 固定ナビゲーション（7タブ）
 * iPhone の safe-area-inset-bottom に対応
 *
 * @param {string}   currentTab   現在選択中のタブキー
 * @param {Function} onTabChange  タブ切り替えコールバック (key: string) => void
 */
export default function BottomNavigation({ currentTab, onTabChange }) {
  return (
    <nav
      style={{
        position:             "fixed",
        bottom:               0,
        left:                 "50%",
        transform:            "translateX(-50%)",
        width:                "100%",
        maxWidth:             520,
        zIndex:               50,
        background:           "rgba(10,10,10,0.97)",
        backdropFilter:       "blur(16px)",
        WebkitBackdropFilter: "blur(16px)",
        borderTop:            `1px solid ${T.cardBorder}`,
        display:              "flex",
        paddingBottom:        "env(safe-area-inset-bottom)",
      }}
    >
      {TABS.map(({ key, label, Icon }) => {
        const active = currentTab === key;
        return (
          <button
            key={key}
            onClick={() => onTabChange(key)}
            style={{
              flex:                    1,
              display:                 "flex",
              flexDirection:           "column",
              alignItems:              "center",
              justifyContent:          "center",
              padding:                 "10px 0 8px",
              border:                  "none",
              background:              "transparent",
              cursor:                  "pointer",
              WebkitTapHighlightColor: "transparent",
              gap:                     3,
              minHeight:               56,
            }}
          >
            {/* アイコン背景ピル（アクティブ時のみ表示） */}
            <div
              style={{
                width:          32,
                height:         28,
                borderRadius:   9,
                display:        "flex",
                alignItems:     "center",
                justifyContent: "center",
                background:     active ? `${T.gold}1F` : "transparent",
                transition:     "background 0.18s ease",
              }}
            >
              <Icon
                size={21}
                color={active ? T.gold : T.whiteFaint}
                strokeWidth={active ? 2.2 : 1.8}
              />
            </div>

            <span
              style={{
                fontSize:   9,
                fontWeight: active ? 700 : 400,
                color:      active ? T.gold : T.whiteFaint,
                lineHeight: 1,
              }}
            >
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}

// タブ定義をエクスポート（App.jsx などで参照用）
export { TABS };
