// src/components/tokens.js
// デザイントークン — 全コンポーネントで共有する定数

// ----------------------------------------------------------------
// カラーパレット
// ----------------------------------------------------------------
export const T = {
  bg:         "#0A0A0A",
  bgElevated: "#141414",
  card:       "#1A1816",
  cardBorder: "#2A2622",
  gold:       "#C9A961",
  goldBright: "#E0C078",
  goldDim:    "#8A7340",
  white:      "#F5F3EF",
  whiteDim:   "#A8A39A",
  whiteFaint: "#6B675F",
  red:        "#D9534F",
  green:      "#5CB85C",
  danger:     "#C24B42",
  blue:       "#4A9FD5",
  purple:     "#8B6FBF",
};

// ----------------------------------------------------------------
// 共通スタイル
// ----------------------------------------------------------------

/** アイコンボタン共通スタイル（44px タップ領域確保） */
export const iconBtnStyle = {
  background:              "transparent",
  border:                  "none",
  padding:                 10,
  margin:                  -10,
  minWidth:                44,
  minHeight:               44,
  display:                 "flex",
  alignItems:              "center",
  justifyContent:          "center",
  WebkitTapHighlightColor: "transparent",
  cursor:                  "pointer",
};

// ----------------------------------------------------------------
// 工程種別カラー
// ----------------------------------------------------------------
export const PROCESS_COLORS = {
  シーリング: "#4A9FD5",
  防水:       "#5B9FE0",
  塗装:       "#E07B5B",
  足場:       "#8B7355",
  左官:       "#B8A878",
  建具:       "#8B6FBF",
  電気:       "#F5C842",
  設備:       "#5CB85C",
  内装:       "#D55A88",
  外構:       "#6BAE8A",
  その他:     "#6B675F",
};

export const processColor = (type) =>
  PROCESS_COLORS[type] ?? T.gold;
