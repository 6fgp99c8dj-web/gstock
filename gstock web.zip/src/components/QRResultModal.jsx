// src/components/QRResultModal.jsx
import React from "react";
import { Plus, Minus } from "lucide-react";
import { T } from "./tokens.js";
import Modal from "./Modal.jsx";
import { GhostButton } from "./Card.jsx";
import { stockLevelColor } from "../utils/qr.js";

/**
 * QR スキャン後の在庫 +/- 操作モーダル
 *
 * @param {object|null} product   スキャンで見つかった商品（null で非表示）
 * @param {Function}    onAdjust  (delta: number) => void
 * @param {Function}    onClose
 */
export default function QRResultModal({ product, onAdjust, onClose }) {
  if (!product) return null;

  const stock = product.arrival - product.used;
  const color = stockLevelColor(stock, T);

  return (
    <Modal open={!!product} onClose={onClose} title="スキャン完了">
      {/* 商品名と在庫数 */}
      <div style={{ textAlign: "center" }}>
        <div
          style={{
            fontSize:     18,
            fontWeight:   800,
            color:        T.white,
            marginBottom: 16,
          }}
        >
          {product.name}
        </div>

        <div style={{ margin: "16px 0 24px" }}>
          <span style={{ fontSize: 52, fontWeight: 800, color, lineHeight: 1 }}>
            {stock}
          </span>
          <span style={{ fontSize: 16, color: T.whiteFaint, marginLeft: 8 }}>
            {product.unit}
          </span>
        </div>
      </div>

      {/* +/- ボタン */}
      <div style={{ display: "flex", gap: 12, marginBottom: 8 }}>
        <button
          onClick={() => onAdjust(-1)}
          style={{
            flex:           1,
            padding:        "18px 0",
            borderRadius:   14,
            background:     T.bgElevated,
            border:         `1px solid ${T.cardBorder}`,
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            cursor:         "pointer",
          }}
        >
          <Minus size={26} color={T.white} />
        </button>

        <button
          onClick={() => onAdjust(1)}
          style={{
            flex:           1,
            padding:        "18px 0",
            borderRadius:   14,
            border:         "none",
            background:     `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`,
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            cursor:         "pointer",
          }}
        >
          <Plus size={26} color="#15120C" />
        </button>
      </div>

      <GhostButton onClick={onClose}>完了</GhostButton>
    </Modal>
  );
}
