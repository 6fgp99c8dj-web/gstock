// src/components/QRScanner.jsx
import React, { useRef, useState, useEffect, useCallback } from "react";
import { T } from "./tokens.js";
import { loadJsQR } from "../utils/qr.js";

/**
 * カメラ QR スキャナー（jsQR CDN 使用）
 *
 * @param {Function} onDetect   QR 検出時コールバック (rawData: string) => void
 * @param {Function} [onCancel] キャンセルボタン押下時
 */
export default function QRScanner({ onDetect, onCancel }) {
  const videoRef  = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef    = useRef(null);
  const jsQRRef   = useRef(null);

  const [active, setActive] = useState(false);
  const [error,  setError]  = useState("");

  // ── スキャン停止 ─────────────────────────────────────────
  const stopScan = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setActive(false);
  }, []);

  // ── フレームごとの QR 検出ループ ─────────────────────────
  const tick = useCallback(() => {
    const v = videoRef.current;
    const c = canvasRef.current;

    if (!v || !c || v.readyState !== v.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(tick);
      return;
    }

    c.width  = v.videoWidth;
    c.height = v.videoHeight;
    const ctx = c.getContext("2d");
    ctx.drawImage(v, 0, 0);

    const imageData = ctx.getImageData(0, 0, c.width, c.height);
    const code      = jsQRRef.current?.(
      imageData.data,
      imageData.width,
      imageData.height
    );

    if (code?.data) {
      stopScan();
      onDetect(code.data);
      return;
    }

    rafRef.current = requestAnimationFrame(tick);
  }, [stopScan, onDetect]);

  // ── カメラ起動 ────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        jsQRRef.current = await loadJsQR();
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setActive(true);
        tick();
      } catch {
        setError(
          "カメラを起動できませんでした。\nブラウザの設定でカメラの許可を確認してください。"
        );
      }
    })();

    return () => {
      cancelled = true;
      stopScan();
    };
  }, [tick, stopScan]);

  // ── エラー表示 ────────────────────────────────────────────
  if (error) {
    return (
      <div
        style={{
          padding:    24,
          textAlign:  "center",
          color:      T.red,
          fontSize:   13,
          lineHeight: 1.7,
          whiteSpace: "pre-line",
        }}
      >
        {error}
      </div>
    );
  }

  // ── スキャン UI ───────────────────────────────────────────
  return (
    <div>
      <div
        style={{
          position:     "relative",
          borderRadius: 18,
          overflow:     "hidden",
          aspectRatio:  "1",
          background:   "#000",
        }}
      >
        {/* カメラ映像 */}
        <video
          ref={videoRef}
          playsInline
          muted
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />

        {/* jsQR 用不可視 Canvas */}
        <canvas ref={canvasRef} style={{ display: "none" }} />

        {/* スキャン枠 */}
        <div
          style={{
            position:     "absolute",
            inset:        "12%",
            border:       `2px solid ${T.gold}`,
            borderRadius: 16,
            boxShadow:    "0 0 0 2000px rgba(0,0,0,0.3)",
          }}
        />

        {/* スキャンライン（アニメーション） */}
        {active && (
          <>
            <div
              style={{
                position:   "absolute",
                left:       "12%",
                right:      "12%",
                height:     2,
                background: T.gold,
                boxShadow:  `0 0 8px ${T.gold}`,
                animation:  "gstock-scan 1.6s ease-in-out infinite",
              }}
            />
          </>
        )}

        {/* キャンセルボタン */}
        <button
          onClick={() => { stopScan(); onCancel?.(); }}
          style={{
            position:     "absolute",
            bottom:       14,
            left:         "50%",
            transform:    "translateX(-50%)",
            background:   "rgba(0,0,0,0.6)",
            border:       "none",
            borderRadius: 20,
            padding:      "8px 22px",
            color:        T.white,
            fontSize:     13,
            cursor:       "pointer",
          }}
        >
          キャンセル
        </button>
      </div>
    </div>
  );
}
