// src/services/aiService.js
// ============================================================
// AI サービス層 — プロバイダ管理専用
//
// 【責務】
//   - setProvider() / getProvider() でプロバイダを管理する
//   - sendMessage() は現在のプロバイダに委譲するだけ
//   - API 通信ロジックは一切持たない
//
// 【新しい AI を追加する手順】
//   1. src/services/providers/XxxProvider.js を作成
//      （BaseProvider を継承し send() を実装）
//   2. このファイルの PROVIDER_MAP に1行追加
//   3. .env に VITE_AI_PROVIDER=xxx を設定
//   → UI / Hooks の変更はゼロ
//
// 【プロバイダ切り替え方法】
//   実行時: aiService.setProvider("openai")
//   起動時: .env に VITE_AI_PROVIDER=openai
// ============================================================
import { MockProvider }   from "./providers/MockProvider.js";
import { OpenAIProvider } from "./providers/OpenAIProvider.js";
import { GeminiProvider } from "./providers/GeminiProvider.js";
import { ClaudeProvider } from "./providers/ClaudeProvider.js";

// ================================================================
// プロバイダ定数
// ================================================================
export const AI_PROVIDER = {
  MOCK:   "mock",
  OPENAI: "openai",
  GEMINI: "gemini",
  CLAUDE: "claude",
};

// ── プロバイダ名 → クラスのマッピング ──────────────────────────
// 新しい Provider を追加する場合はここに1行追加するだけ
const PROVIDER_MAP = {
  [AI_PROVIDER.MOCK]:   () => new MockProvider(),
  [AI_PROVIDER.OPENAI]: () => new OpenAIProvider(),
  [AI_PROVIDER.GEMINI]: () => new GeminiProvider(),
  [AI_PROVIDER.CLAUDE]: () => new ClaudeProvider(),
};

// ================================================================
// プロバイダ状態管理
// ================================================================

// 起動時の初期プロバイダ（.env > デフォルト mock）
const _initialKey =
  (typeof import.meta !== "undefined" && import.meta.env?.VITE_AI_PROVIDER)
    ? import.meta.env.VITE_AI_PROVIDER
    : AI_PROVIDER.MOCK;

let _currentKey      = _initialKey;
let _currentProvider = _createProvider(_initialKey);

/** プロバイダインスタンスを生成（未知のキーは mock にフォールバック） */
function _createProvider(key) {
  const factory = PROVIDER_MAP[key];
  if (!factory) {
    console.warn(`[aiService] 未知のプロバイダ "${key}" → mock にフォールバック`);
    return new MockProvider();
  }
  return factory();
}

// ================================================================
// 公開インターフェース
// ================================================================

/**
 * 現在のプロバイダキーを返す
 * @returns {string}  例: "mock" | "openai" | "gemini" | "claude"
 */
export function getProvider() {
  return _currentKey;
}

/**
 * プロバイダを切り替える
 * UI からリアルタイムに変更可能（設定画面など）
 *
 * @param {string} key  AI_PROVIDER 定数のいずれか
 * @throws {Error}      PROVIDER_MAP に存在しないキーの場合
 */
export function setProvider(key) {
  if (!PROVIDER_MAP[key]) {
    throw new Error(
      `[aiService] 無効なプロバイダキー "${key}"。` +
      `有効な値: ${Object.keys(PROVIDER_MAP).join(", ")}`
    );
  }
  _currentKey      = key;
  _currentProvider = _createProvider(key);
  console.info(`[aiService] プロバイダを "${key}" に切り替えました`);
}

/**
 * 利用可能なプロバイダの一覧を返す
 * @returns {string[]}  例: ["mock", "openai", "gemini", "claude"]
 */
export function listProviders() {
  return Object.keys(PROVIDER_MAP);
}

/**
 * AI にメッセージを送信する（全プロバイダ共通エントリポイント）
 * 実際の通信は現在のプロバイダの send() に完全委譲する
 *
 * @param {Array}  messages  会話履歴 [{ id, role, text, createdAt }]
 * @param {object} context   DB から渡される現場・在庫・工程情報
 * @returns {Promise<{
 *   reply:       string,
 *   suggestions: string[],
 *   status:      "ok"|"mock"|"error"
 * }>}
 */
export async function sendMessage(messages, context) {
  // 最後のユーザーメッセージを取得
  const lastUser = [...messages].reverse().find((m) => m.role === "user");
  const userText = lastUser?.text ?? "";

  if (!userText) {
    return { reply: "", suggestions: [], status: "ok" };
  }

  try {
    // ── プロバイダに完全委譲 ────────────────────────────────
    return await _currentProvider.send(userText, messages, context);
  } catch (err) {
    console.error(`[aiService][${_currentKey}] エラー:`, err);
    throw err;
  }
}

/**
 * 現在のプロバイダの動作確認
 * @returns {Promise<{ provider: string, ok: boolean }>}
 */
export async function healthCheck() {
  try {
    const ok = await _currentProvider.healthCheck();
    return { provider: _currentKey, ok };
  } catch {
    return { provider: _currentKey, ok: false };
  }
}
