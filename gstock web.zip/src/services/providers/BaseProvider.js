// src/services/providers/BaseProvider.js
// ============================================================
// AI Provider 基底クラス（インターフェース定義）
//
// 全 Provider はこのクラスを継承し、
// send() メソッドを必ずオーバーライドする。
//
// 【設計原則】
// - aiService.js は BaseProvider の send() だけを呼ぶ
// - UI / Hooks は aiService.js だけを見る
// - 新しい AI を追加 = 新しい XxxProvider.js を作るだけ
//   → aiService.js に1行登録するだけで動く
// ============================================================

/**
 * @typedef {Object} AIResponse
 * @property {string}   reply        AI の返答テキスト
 * @property {string[]} suggestions  追加提案リスト（空配列可）
 * @property {"ok"|"mock"|"error"} status  レスポンスのステータス
 */

export class BaseProvider {
  /** @param {string} name  プロバイダ識別名（ログ用） */
  constructor(name) {
    this.name = name;
  }

  /**
   * AI に問い合わせる（サブクラスで必ずオーバーライドする）
   *
   * @param {string}   userText  最後のユーザー発言テキスト
   * @param {Array}    messages  会話履歴全体 [{ id, role, text, createdAt }]
   * @param {object}   context   DB から渡される現場・在庫・工程情報
   * @returns {Promise<AIResponse>}
   */
  // eslint-disable-next-line no-unused-vars
  async send(userText, messages, context) {
    throw new Error(`[${this.name}] send() が実装されていません`);
  }

  /**
   * プロバイダの動作確認（オプション）
   * @returns {Promise<boolean>}
   */
  async healthCheck() {
    return true;
  }
}
