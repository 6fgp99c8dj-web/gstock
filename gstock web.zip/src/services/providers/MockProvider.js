// src/services/providers/MockProvider.js
// ============================================================
// モック AI プロバイダ
// - ネットワーク不要 / 開発・デモ用
// - 現場知識（在庫・工程・材料・出面・LINE）を反映したリッチな返答
// ============================================================
import { BaseProvider } from "./BaseProvider.js";

const DELAY_MS = 750;

export class MockProvider extends BaseProvider {
  constructor() {
    super("mock");
  }

  /** @override */
  async send(userText, _messages, context) {
    await _sleep(DELAY_MS);
    const reply       = _generateReply(userText, context);
    const suggestions = _generateSuggestions(context);
    return { reply, suggestions, status: "mock" };
  }
}

// ================================================================
// 返答ロジック（現場知識を反映）
// ================================================================

function _generateReply(text, ctx) {
  const t        = text.toLowerCase();
  const products = ctx?.products         ?? [];
  const low      = ctx?.lowStockProducts ?? [];
  const sched    = ctx?.todaySchedule;
  const site     = ctx?.todaySite;
  const upcoming = ctx?.allSchedules     ?? [];
  const att      = ctx?.attendance       ?? [];

  // ── 在庫・材料 ────────────────────────────────────────────
  if (
    t.includes("材料足りる") ||
    t.includes("材料たりる") ||
    (t.includes("足りる") && t.includes("材料"))
  ) {
    if (low.length === 0) {
      return "現在の在庫で本日の施工は問題ありません。全材料が十分な数量です。";
    }
    const names = low
      .map((p) => `${p.name}(残${p.arrival - p.used}${p.unit})`)
      .join("、");
    return `以下の材料が不足しています:\n${names}\n\n補充を優先してください。施工前に数量を再確認することをおすすめします。`;
  }

  if (t.includes("在庫") || t.includes("材料")) {
    if (products.length === 0) {
      return "現在、在庫データが登録されていません。在庫画面から商品を追加してください。";
    }
    const list = products
      .slice(0, 8)
      .map((p) => {
        const stock = p.arrival - p.used;
        const mark  = stock <= 0 ? "⚠在庫なし" : stock <= 5 ? "⚠残りわずか" : "✓";
        return `・${p.name}: ${stock}${p.unit} ${mark}`;
      })
      .join("\n");
    const more = products.length > 8 ? `\n... 他${products.length - 8}品目` : "";
    const note = low.length > 0
      ? `⚠ ${low.length}品目が不足しています。`
      : "全材料に問題ありません。";
    return `【在庫一覧】\n${list}${more}\n\n${note}`;
  }

  if (t.includes("不足")) {
    if (low.length === 0) {
      return "現在、不足している材料はありません。全材料の在庫は十分です。";
    }
    const list = low
      .map((p) => {
        const stock = p.arrival - p.used;
        return `・${p.name}: 残り${stock}${p.unit}${stock <= 0 ? " ⚠在庫なし" : ""}`;
      })
      .join("\n");
    return `【不足・残りわずかの材料】\n${list}\n\n早急に発注・補充をご検討ください。`;
  }

  // ── 今日の現場 ────────────────────────────────────────────
  if (
    t.includes("今日") &&
    (t.includes("現場") || t.includes("仕事") || t.includes("作業"))
  ) {
    if (!site && !sched) {
      return "今日の現場はカレンダーに登録されていません。工程表OCRから登録してください。";
    }
    const lines = ["【今日の現場】"];
    if (site?.name)         lines.push(`現場: ${site.name}`);
    if (site?.address)      lines.push(`住所: ${site.address}`);
    if (sched?.processName) lines.push(`工程: ${sched.processName}`);
    if (sched?.startDate)   lines.push(`期間: ${sched.startDate} 〜 ${sched.endDate}`);
    if (sched?.contractor)  lines.push(`担当: ${sched.contractor}`);
    if (sched?.floor)       lines.push(`場所: ${sched.floor}`);
    return lines.join("\n");
  }

  // ── 次の現場・工程 ────────────────────────────────────────
  if (
    t.includes("次の現場") ||
    t.includes("次の工程") ||
    t.includes("つぎ")
  ) {
    const today  = new Date().toISOString().slice(0, 10);
    const future = upcoming
      .filter((s) => s.startDate > today)
      .sort((a, b) => a.startDate.localeCompare(b.startDate))
      .slice(0, 3);
    if (future.length === 0) {
      return "今後の工程はまだ登録されていません。工程表OCRから登録してください。";
    }
    const lines = ["【今後の工程】"];
    future.forEach((s) => {
      lines.push(`・${s.startDate} 〜 ${s.endDate}: ${s.siteName ?? ""} ${s.processName ?? ""}`);
    });
    return lines.join("\n");
  }

  // ── 職人・人数 ────────────────────────────────────────────
  if (
    t.includes("職人") ||
    t.includes("何人") ||
    t.includes("人数") ||
    t.includes("作業員")
  ) {
    if (sched?.processType === "シーリング") {
      return "シーリング工事の目安:\n・小規模（〜50m）: 1〜2名\n・中規模（50〜200m）: 2〜3名\n・大規模（200m〜）: 3〜5名\n\n工程と施工範囲を事前に確認の上、人数を決定してください。";
    }
    return "必要人数は工程・施工範囲・工期によって異なります。工程表の施工数量をもとに積算することをおすすめします。";
  }

  // ── 出面 ──────────────────────────────────────────────────
  if (t.includes("出面")) {
    if (att.length === 0) {
      return "出面データがまだ登録されていません。出面画面から日々の稼働を記録してください。";
    }
    const total  = att.reduce((sum, a) => sum + (a.value ?? 0), 0);
    const recent = att.slice(0, 5);
    const lines  = [`【出面サマリー】\n今月合計: ${total}人工\n\n【直近の出面】`];
    recent.forEach((a) => lines.push(`・${a.date}: ${a.value}人工`));
    return lines.join("\n");
  }

  // ── 現場一覧 ─────────────────────────────────────────────
  if (t.includes("現場一覧") || (t.includes("現場") && t.includes("一覧"))) {
    const sites = ctx?.sites ?? [];
    if (sites.length === 0) {
      return "現場がまだ登録されていません。現場画面から追加してください。";
    }
    const list = sites
      .map((s) => `・${s.name}${s.address ? ` (${s.address})` : ""}`)
      .join("\n");
    return `【登録現場 全${sites.length}件】\n${list}`;
  }

  // ── 天気・雨 ─────────────────────────────────────────────
  if (
    t.includes("天気") ||
    t.includes("雨") ||
    t.includes("天候") ||
    t.includes("施工できる")
  ) {
    return "雨天時のシーリング施工における注意点:\n\n・被着面が濡れている場合は施工禁止\n・相対湿度85%以上では施工を避ける\n・施工後24時間以内に雨が予想される場合は養生を厚めに\n・プライマーは雨天後、十分乾燥してから塗布\n\n天気予報を確認し、施工可否を判断してください。";
  }

  // ── 乾燥時間 ─────────────────────────────────────────────
  if (t.includes("乾燥")) {
    return "シーリング材の乾燥時間の目安:\n\n【変成シリコン】\n・表面硬化: 30〜60分\n・完全硬化: 24〜48時間\n\n【ウレタン系】\n・表面硬化: 2〜4時間\n・完全硬化: 48〜72時間\n\n【シリコン系】\n・表面硬化: 30〜60分\n・完全硬化: 24〜48時間\n\n※気温・湿度により変動。低温・高湿度では乾燥が遅くなります。";
  }

  // ── 必要数量・積算 ───────────────────────────────────────
  if (
    t.includes("必要数量") ||
    t.includes("数量") ||
    t.includes("本数") ||
    t.includes("積算")
  ) {
    return "シーリング材の数量計算:\n\n【基本式】\n使用量(ml) = 目地幅(mm) × 目地深さ(mm) × 施工長(m)\n\n【例】幅10mm × 深さ10mm × 100m\n= 10 × 10 × 1000mm = 100,000mm³ = 100ml\n\n一般的な330mlカートリッジ1本あたり3〜5m施工可能（目地仕様による）。\n余裕として10〜20%増しで発注することをおすすめします。";
  }

  // ── 施工手順 ─────────────────────────────────────────────
  if (
    t.includes("施工手順") ||
    t.includes("手順") ||
    t.includes("やり方") ||
    t.includes("方法")
  ) {
    return "シーリング施工の基本手順:\n\n①既存シール・汚れの除去\n②被着面の清掃・乾燥確認\n③バックアップ材の充填（2面接着）\n④マスキングテープの貼り付け\n⑤プライマーの塗布・乾燥（15〜30分）\n⑥シーリング材の充填\n⑦ヘラによる均し仕上げ\n⑧マスキングテープの撤去（硬化前）\n⑨乾燥・確認\n\n各工程で品質確認を行い、次工程へ進んでください。";
  }

  // ── プライマー ───────────────────────────────────────────
  if (t.includes("プライマー") || t.includes("primer")) {
    return "プライマー塗布の注意点:\n\n・被着面を清掃・乾燥後に塗布\n・均一に薄く塗る（厚塗り禁止）\n・乾燥時間: 15〜30分（製品仕様を確認）\n・オープンタイムを超えた場合は再塗布\n・気温5℃以下・降雨時は塗布禁止\n\n種類: コンクリート用・金属用・サッシ用など被着体に応じて選定してください。";
  }

  // ── 安全 ─────────────────────────────────────────────────
  if (t.includes("安全") || t.includes("危険") || t.includes("注意")) {
    return "現場安全確認事項:\n\n【作業前】\n・KY（危険予知）活動の実施\n・安全帯・保護具の装着確認\n・足場の点検（ぐらつき・破損）\n・工具の落下防止措置\n\n【作業中】\n・有機溶剤使用時は換気を確保\n・高所作業時は安全帯を使用\n・作業区域への第三者立入禁止\n\n【材料】\n・SDS（安全データシート）の確認\n・防毒マスク・保護手袋の着用\n\n安全第一で作業を進めてください。";
  }

  // ── LINE送信 ─────────────────────────────────────────────
  if (t.includes("line") || t.includes("ライン") || t.includes("送信")) {
    return "LINE送信機能について:\n\n出面画面の「LINE送信用データを作成」ボタンから、月次の出面報告テキストを自動生成できます。\n\n【生成される内容】\n・期間（〇月度 21日〜20日）\n・日付ごとの現場名と人工数\n・合計人工数\n\n生成後、コピーしてLINEに貼り付けるか、LINEアプリで直接共有できます。";
  }

  // ── 明日・準備 ───────────────────────────────────────────
  if (t.includes("明日") || t.includes("あした") || t.includes("準備")) {
    const tomorrow    = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().slice(0, 10);
    const tmSchedule  = upcoming.find(
      (s) => s.startDate <= tomorrowStr && s.endDate >= tomorrowStr
    );
    const lines = ["【明日の準備チェックリスト】\n"];
    if (tmSchedule) {
      lines.push(
        `📍 明日の現場: ${tmSchedule.siteName ?? ""} ${tmSchedule.processName ?? ""}`,
        ""
      );
    }
    lines.push(
      "□ 材料数量の確認・補充",
      "□ 工具の点検・充電",
      "□ 天気予報の確認",
      "□ プライマー・養生テープの準備",
      "□ 安全装備の確認",
      "□ 現場アクセス・駐車場の確認"
    );
    return lines.join("\n");
  }

  // ── 挨拶 ─────────────────────────────────────────────────
  if (
    t.includes("おはよう") ||
    t.includes("こんにちは") ||
    t.includes("よろしく") ||
    t.includes("ありがとう")
  ) {
    const name     = ctx?.userProfile?.companyName;
    const greeting = t.includes("ありがとう") ? "お役に立てて嬉しいです！" : "おはようございます！";
    const intro    = name ? `${name}の現場を` : "現場を";
    return `${greeting}今日も${intro}全力でサポートします。\n材料・工程・施工方法など何でもご質問ください。`;
  }

  // ── デフォルト ────────────────────────────────────────────
  const defaults = [
    "ご質問ありがとうございます。現場の状況をもう少し詳しく教えていただけますか？\n「材料足りる？」「今日の現場は？」「施工手順を教えて」など具体的な質問が得意です。",
    "確認しました。具体的な材料名・現場名・工程名を含めて質問していただくと、より正確な回答ができます。",
    "在庫・工程・施工方法・安全注意事項など、現場に関することなら何でもお答えします。",
  ];
  return defaults[Math.floor(Math.random() * defaults.length)];
}

/** コンテキストから動的に提案を生成 */
function _generateSuggestions(ctx) {
  const suggestions = [];
  const low         = ctx?.lowStockProducts ?? [];

  if (low.length > 0) {
    suggestions.push(
      `${low[0].name}の在庫が残りわずかです（残${low[0].arrival - low[0].used}${low[0].unit}）`
    );
  }
  if (ctx?.todaySchedule?.processType === "シーリング") {
    suggestions.push("本日はシーリング施工です。プライマーの準備を確認してください");
  }
  if (low.length >= 3) {
    suggestions.push(`合計${low.length}品目の材料が不足しています`);
  }

  return suggestions.slice(0, 3);
}

function _sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
