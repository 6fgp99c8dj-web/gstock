// src/services/providers/OpenAIProvider.js
// ============================================================
// OpenAI プロバイダ
//
// 【使い方】
// 1. .env に以下を追加:
//    VITE_AI_PROVIDER=openai
//    VITE_OPENAI_API_KEY=sk-xxxxx
//    VITE_OPENAI_MODEL=gpt-4o-mini   # 省略時: gpt-4o-mini
//
// 2. aiService.js の setProvider() が自動的にこのクラスを使用する
// ============================================================
import { BaseProvider }                              from "./BaseProvider.js";
import { buildSystemPrompt, formatHistoryForProvider } from "../../utils/aiPrompt.js";

export class OpenAIProvider extends BaseProvider {
  constructor() {
    super("openai");
    this._apiKey = import.meta.env?.VITE_OPENAI_API_KEY ?? "";
    this._model  = import.meta.env?.VITE_OPENAI_MODEL   ?? "gpt-4o-mini";
    this._endpoint = "https://api.openai.com/v1/chat/completions";
  }

  /** @override */
  async send(userText, messages, context) {
    if (!this._apiKey) {
      throw new Error("VITE_OPENAI_API_KEY が未設定です。.env ファイルを確認してください。");
    }

    const systemPrompt = buildSystemPrompt(context);
    const history      = formatHistoryForProvider(messages, "openai");

    const res = await fetch(this._endpoint, {
      method:  "POST",
      headers: {
        "Content-Type":  "application/json",
        "Authorization": `Bearer ${this._apiKey}`,
      },
      body: JSON.stringify({
        model:       this._model,
        max_tokens:  600,
        temperature: 0.7,
        messages: [
          { role: "system",    content: systemPrompt },
          ...history,
          { role: "user",      content: userText     },
        ],
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message ?? `OpenAI API エラー (${res.status})`);
    }

    const data  = await res.json();
    const reply = data.choices?.[0]?.message?.content ?? "返答を取得できませんでした";
    return { reply, suggestions: [], status: "ok" };
  }

  /** @override */
  async healthCheck() {
    if (!this._apiKey) return false;
    try {
      const res = await fetch("https://api.openai.com/v1/models", {
        headers: { "Authorization": `Bearer ${this._apiKey}` },
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}
