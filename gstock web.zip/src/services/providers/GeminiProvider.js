// src/services/providers/GeminiProvider.js
// ============================================================
// Google Gemini プロバイダ
//
// 【使い方】
// 1. .env に以下を追加:
//    VITE_AI_PROVIDER=gemini
//    VITE_GEMINI_API_KEY=AIzaxxxxx
//    VITE_GEMINI_MODEL=gemini-1.5-flash   # 省略時: gemini-1.5-flash
//
// 2. aiService.js の setProvider() が自動的にこのクラスを使用する
// ============================================================
import { BaseProvider }                              from "./BaseProvider.js";
import { buildSystemPrompt, formatHistoryForProvider } from "../../utils/aiPrompt.js";

const GEMINI_BASE_URL =
  "https://generativelanguage.googleapis.com/v1beta/models";

export class GeminiProvider extends BaseProvider {
  constructor() {
    super("gemini");
    this._apiKey = import.meta.env?.VITE_GEMINI_API_KEY ?? "";
    this._model  = import.meta.env?.VITE_GEMINI_MODEL   ?? "gemini-1.5-flash";
  }

  /** @override */
  async send(userText, messages, context) {
    if (!this._apiKey) {
      throw new Error("VITE_GEMINI_API_KEY が未設定です。.env ファイルを確認してください。");
    }

    const systemPrompt = buildSystemPrompt(context);
    const history      = formatHistoryForProvider(messages, "gemini");

    const url = `${GEMINI_BASE_URL}/${this._model}:generateContent?key=${this._apiKey}`;

    const res = await fetch(url, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: {
          parts: [{ text: systemPrompt }],
        },
        contents: [
          ...history,
          { role: "user", parts: [{ text: userText }] },
        ],
        generationConfig: {
          maxOutputTokens: 600,
          temperature:     0.7,
        },
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message ?? `Gemini API エラー (${res.status})`);
    }

    const data  = await res.json();
    const reply =
      data.candidates?.[0]?.content?.parts?.[0]?.text ??
      "返答を取得できませんでした";
    return { reply, suggestions: [], status: "ok" };
  }

  /** @override */
  async healthCheck() {
    if (!this._apiKey) return false;
    try {
      const url = `${GEMINI_BASE_URL}?key=${this._apiKey}`;
      const res = await fetch(url);
      return res.ok;
    } catch {
      return false;
    }
  }
}
