// src/services/providers/ClaudeProvider.js
// ============================================================
// Anthropic Claude プロバイダ
//
// 【使い方】
// 1. .env に以下を追加:
//    VITE_AI_PROVIDER=claude
//    VITE_CLAUDE_MODEL=claude-sonnet-4-6   # 省略時: claude-sonnet-4-6
//    ※ Claude API はこのアプリ自体の実行環境でキー不要の場合あり
//
// 2. aiService.js の setProvider() が自動的にこのクラスを使用する
// ============================================================
import { BaseProvider }                              from "./BaseProvider.js";
import { buildSystemPrompt, formatHistoryForProvider } from "../../utils/aiPrompt.js";

const CLAUDE_ENDPOINT = "https://api.anthropic.com/v1/messages";

export class ClaudeProvider extends BaseProvider {
  constructor() {
    super("claude");
    this._model = import.meta.env?.VITE_CLAUDE_MODEL ?? "claude-sonnet-4-6";
  }

  /** @override */
  async send(userText, messages, context) {
    const systemPrompt = buildSystemPrompt(context);
    const history      = formatHistoryForProvider(messages, "claude");

    const res = await fetch(CLAUDE_ENDPOINT, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model:      this._model,
        max_tokens: 600,
        system:     systemPrompt,
        messages: [
          ...history,
          { role: "user", content: userText },
        ],
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message ?? `Claude API エラー (${res.status})`);
    }

    const data  = await res.json();
    const reply = data.content?.[0]?.text ?? "返答を取得できませんでした";
    return { reply, suggestions: [], status: "ok" };
  }

  /** @override */
  async healthCheck() {
    try {
      const res = await fetch(CLAUDE_ENDPOINT, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model:      this._model,
          max_tokens: 1,
          messages:   [{ role: "user", content: "ping" }],
        }),
      });
      // 認証エラー以外は接続できている
      return res.status !== 0;
    } catch {
      return false;
    }
  }
}
