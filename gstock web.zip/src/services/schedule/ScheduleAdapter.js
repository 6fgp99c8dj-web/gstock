// src/services/schedule/ScheduleAdapter.js
// ============================================================
// ScheduleAdapter — AI / OCR → db.schedules 変換レイヤー
//
// 【責務】
//   外部ソース（AI・OCR・CSV）から渡される形式を
//   db.schedules の正規スキーマへ変換する。
//   変換以外の処理（保存・API通信・UI）は一切持たない。
//
// 【Single Source of Truth】
//   db.schedules が唯一の正規データ。
//   変換後のオブジェクトを DBContext.update() に渡すだけで
//   既存の保存・読込・編集・表示フローが全て動作する。
//
// 【将来の AI 連携】
//   await aiManager.parseSchedule(image) の戻り値を
//   toSchedules(result) に渡すだけで db.schedules に追加できる:
//
//   const result   = await aiManager.parseSchedule(image);
//   const schedules = toSchedules(result);
//   update(prev => ({
//     schedules: [...prev.schedules, ...schedules]
//   }));
//
// 【入力スキーマ（AI / OCR / CSV から渡される形式）】
//   {
//     title:   string,   // 工程名
//     site:    string,   // 現場名
//     worker:  string?,  // 担当者（省略可）
//     start:   string,   // 開始日 YYYY-MM-DD
//     end:     string,   // 終了日 YYYY-MM-DD
//     memo:    string?,  // 備考（省略可）
//   }
//
// 【出力スキーマ（db.schedules の正規形式）】
//   {
//     id:          string,   // ユニーク ID（uid()）
//     siteName:    string,   // 現場名
//     processName: string,   // 工程名
//     contractor:  string,   // 担当者
//     startDate:   string,   // 開始日 YYYY-MM-DD
//     endDate:     string,   // 終了日 YYYY-MM-DD
//     note:        string,   // 備考
//     confirmed:   boolean,  // 確認済みフラグ（デフォルト false）
//     source:      string,   // データソース識別子
//     createdAt:   number,   // 作成時刻（Unix ミリ秒）
//     updatedAt:   number,   // 更新時刻（Unix ミリ秒）
//     // 既存スキーマの任意フィールド（互換性維持）
//     buildingName: string,
//     wingName:     string,
//     floor:        string,
//     room:         string,
//     projectName:  string,
//     processType:  string,
//   }
// ============================================================

import { uid } from "../../utils/storage.js";

// ================================================================
// バリデーション（内部）
// ================================================================

/**
 * 入力データが最低限必要なフィールドを持つか検証する
 *
 * @param {object} data  変換前のデータ
 * @returns {string[]}   エラーメッセージの配列（空なら valid）
 */
function validate(data) {
  const errors = [];
  if (!data || typeof data !== "object") {
    errors.push("データがオブジェクトではありません");
    return errors;
  }
  if (!String(data.title ?? data.processName ?? "").trim()) {
    errors.push("工程名（title または processName）が必要です");
  }
  if (!String(data.start ?? data.startDate ?? "").trim()) {
    errors.push("開始日（start または startDate）が必要です");
  }
  if (!String(data.end ?? data.endDate ?? "").trim()) {
    errors.push("終了日（end または endDate）が必要です");
  }
  return errors;
}

// ================================================================
// 公開関数
// ================================================================

/**
 * AI / OCR / CSV から渡される単一データを db.schedules 形式へ変換する
 *
 * 入力フィールドが db.schedules の形式（startDate / siteName / processName）に
 * 既に揃っている場合も正しく処理する（フォールバックロジック）。
 *
 * @param {object} data   変換元データ
 * @param {object} [opts] オプション
 * @param {string} [opts.source="ai"]       データソース識別子
 * @param {boolean}[opts.confirmed=false]   確認済みフラグの初期値
 * @returns {{ ok: true, schedule: object } | { ok: false, errors: string[] }}
 *
 * @note id と createdAt について
 * この関数は id と createdAt を生成しますが、
 * addSchedules()（useLocalDB.js）経由で保存した場合は
 * useLocalDB 側で新しい id と createdAt が付与されます。
 * この値は永続化時に上書きされることを前提とした設計です。
 * toSchedule() を addSchedules() を経由せず直接保存する場合のみ
 * ここで生成した値が利用されます。
 * そのため、呼び出し側は id や createdAt の値に依存しないでください。
 */
export function toSchedule(data, opts = {}) {
  const { source = "ai", confirmed = false } = opts;

  // バリデーション
  const errors = validate(data);
  if (errors.length > 0) {
    return { ok: false, errors };
  }

  const now = Date.now();

  const schedule = {
    // ── 必須フィールド ────────────────────────────────────────
    id:          uid(),

    // 工程名: AI 形式（title）/ 既存形式（processName）の両方を受け付ける
    processName: String(data.title        ?? data.processName ?? "").trim(),

    // 現場名: AI 形式（site）/ 既存形式（siteName）の両方を受け付ける
    siteName:    String(data.site         ?? data.siteName    ?? "").trim(),

    // 担当者: AI 形式（worker）/ 既存形式（contractor）の両方を受け付ける
    contractor:  String(data.worker       ?? data.contractor  ?? "").trim(),

    // 開始日: AI 形式（start）/ 既存形式（startDate）の両方を受け付ける
    startDate:   String(data.start        ?? data.startDate   ?? "").trim(),

    // 終了日: AI 形式（end）/ 既存形式（endDate）の両方を受け付ける
    endDate:     String(data.end          ?? data.endDate     ?? "").trim(),

    // 備考: AI 形式（memo）/ 既存形式（note）の両方を受け付ける
    note:        String(data.memo         ?? data.note        ?? "").trim(),

    // ── 管理フィールド ────────────────────────────────────────
    confirmed,
    source,
    // 注意: useLocalDB.js の addSchedules() は id / createdAt を強制上書きする。
    // toSchedule() 単体で使う場合（addSchedules を経由しない場合）は
    // ここで生成した値がそのまま使われる。
    createdAt:   now,
    updatedAt:   now,

    // ── 既存スキーマの任意フィールド（互換性維持・省略可） ────
    // OCR 結果や手動入力で設定されることがある
    buildingName: String(data.buildingName ?? "").trim(),
    wingName:     String(data.wingName     ?? "").trim(),
    floor:        String(data.floor        ?? "").trim(),
    room:         String(data.room         ?? "").trim(),
    projectName:  String(data.projectName  ?? "").trim(),
    processType:  String(data.processType  ?? "").trim(),
  };

  return { ok: true, schedule };
}

/**
 * AI / OCR / CSV から渡される配列データを db.schedules 形式の配列へ変換する
 *
 * バリデーションエラーのアイテムはスキップし、
 * 変換できたものだけを返す（エラー情報も返す）。
 *
 * @param {Array}  items  変換元データの配列
 * @param {object} [opts] toSchedule と同じオプション
 * @returns {{
 *   schedules: object[],              変換成功したスケジュール配列
 *   errors:    Array<{index, errors}> 変換失敗したアイテムとエラー
 * }}
 */
export function toSchedules(items, opts = {}) {
  const schedules = [];
  const errors    = [];

  const arr = Array.isArray(items) ? items : [];

  arr.forEach((item, index) => {
    const result = toSchedule(item, opts);
    if (result.ok) {
      schedules.push(result.schedule);
    } else {
      errors.push({ index, errors: result.errors });
    }
  });

  return { schedules, errors };
}

/**
 * db.schedules の既存エントリに updatedAt を付与して更新する
 * （編集フォームなどで使用する既存エントリの更新用）
 *
 * @param {object} existing  db.schedules の既存エントリ
 * @param {object} patch     上書きするフィールド
 * @returns {object}         マージされた新しいエントリ
 */
export function updateSchedule(existing, patch) {
  return {
    ...existing,
    ...patch,
    updatedAt: Date.now(),
  };
}
