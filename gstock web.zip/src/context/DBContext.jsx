// src/context/DBContext.jsx
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { loadDB, saveDB } from "../utils/storage.js";

// ----------------------------------------------------------------
// Context 定義
// ----------------------------------------------------------------
const DBContext = createContext(null);

/**
 * useDB()
 * 使い方: const { db, update, setDB } = useDB();
 *
 * update(fn)    … fn(prevDB) => partialPatch をマージ
 * update(patch) … patch オブジェクトをシャローマージ
 */
export function useDB() {
  const ctx = useContext(DBContext);
  if (!ctx) {
    throw new Error("useDB() は <DBProvider> の内側で使用してください");
  }
  return ctx;
}

// ----------------------------------------------------------------
// DBProvider
// ----------------------------------------------------------------
export function DBProvider({ children }) {
  const [db, setDB] = useState(loadDB);

  // DB が変わるたびに localStorage へ自動保存
  useEffect(() => {
    saveDB(db);
  }, [db]);

  // 部分的に DB を更新する
  const update = useCallback((fnOrPatch) => {
    setDB((prev) => {
      const patch =
        typeof fnOrPatch === "function" ? fnOrPatch(prev) : fnOrPatch;
      return { ...prev, ...patch };
    });
  }, []);

  // value はメモ化してプロバイダの不要な再レンダを防ぐ
  const value = useMemo(
    () => ({ db, update, setDB }),
    [db, update]
  );

  return (
    <DBContext.Provider value={value}>
      {children}
    </DBContext.Provider>
  );
}
