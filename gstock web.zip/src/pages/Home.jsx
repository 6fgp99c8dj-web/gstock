// src/pages/Home.jsx
import React, { useMemo } from "react";
import {
  FileText, Calendar, Package, QrCode,
  MapPin, Users, Camera, Send,
} from "lucide-react";
import { T } from "../components/tokens.js";
import { HomeCard } from "../components/Card.jsx";
import { useDB } from "../context/DBContext.jsx";
import { todayStr } from "../utils/storage.js";

/**
 * ホーム画面（既存 UI をそのまま維持）
 * @param {Function} navigate
 */
export default function Home({ navigate }) {
  const { db } = useDB();
  const today  = todayStr();

  // 今日が期間内に入るスケジュール
  const todaySchedules = useMemo(
    () =>
      (db.schedules ?? []).filter(
        (s) => s.startDate <= today && s.endDate >= today
      ),
    [db.schedules, today]
  );

  const hasCompany = !!db.userProfile?.companyName;

  return (
    <div style={{ paddingBottom: 100 }}>
      {/* ヘッダーテキスト */}
      <div style={{ padding: "22px 20px 6px" }}>
        <div
          style={{
            fontSize:      13,
            color:         T.gold,
            fontWeight:    700,
            letterSpacing: 2,
          }}
        >
          G STOCK
        </div>
        <div
          style={{
            fontSize:   22,
            fontWeight: 800,
            color:      T.white,
            marginTop:  2,
          }}
        >
          今日も一日、よろしく
        </div>

        {/* 今日の工程バナー */}
        {todaySchedules.length > 0 && (
          <div
            style={{
              marginTop:    10,
              background:   `${T.gold}15`,
              border:       `1px solid ${T.gold}30`,
              borderRadius: 12,
              padding:      "8px 12px",
            }}
          >
            <div style={{ fontSize: 12, color: T.gold, fontWeight: 700 }}>
              今日の現場 {todaySchedules.length}件
            </div>
            {todaySchedules.slice(0, 2).map((s) => (
              <div key={s.id} style={{ fontSize: 13, color: T.white, marginTop: 3 }}>
                {s.siteName}
                {s.floor ? ` ${s.floor}` : ""}
                {s.processName ? ` ${s.processName}` : ""}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 2列グリッド */}
      <div
        style={{
          display:             "grid",
          gridTemplateColumns: "1fr 1fr",
          gap:                 12,
          padding:             "14px 16px",
        }}
      >
        <HomeCard
          icon={FileText}
          label="工程表OCR"
          sub="撮影→AI解析→登録"
          onClick={() => navigate("ocr")}
          badge={!hasCompany ? 1 : null}
        />
        <HomeCard
          icon={Calendar}
          label="スケジュール"
          sub="工程カレンダー"
          onClick={() => navigate("calendar-screen")}
          badge={todaySchedules.length || null}
        />
        <HomeCard
          icon={Package}
          label="在庫"
          sub="材料・数量を管理"
          onClick={() => navigate("inventory")}
        />
        <HomeCard
          icon={QrCode}
          label="QR"
          sub="読取で即入力"
          onClick={() => navigate("qr")}
        />
        <HomeCard
          icon={MapPin}
          label="現場"
          sub="現場と履歴"
          onClick={() => navigate("sites")}
        />
        <HomeCard
          icon={Users}
          label="出面"
          sub="21日〜20日集計"
          onClick={() => navigate("attendance")}
        />
        <HomeCard
          icon={Camera}
          label="写真"
          sub="現場の記録"
          onClick={() => navigate("photos")}
        />
        <HomeCard
          icon={Send}
          label="LINE"
          sub="送信データ作成"
          onClick={() => navigate("line")}
        />
      </div>
    </div>
  );
}
