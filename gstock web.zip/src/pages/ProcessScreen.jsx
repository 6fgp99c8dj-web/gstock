// src/pages/ProcessScreen.jsx
// ============================================================
// Phase 2 — 工程タブ メイン画面
//
// 今後ここに追加予定の機能：
//   - 工程表（ガントチャート表示）
//   - 工程一覧（フィルタ・検索）
//   - Google カレンダー連携
//   - Apple カレンダー連携
//   - AI 解析（工程表 OCR）
//
// 今回は画面レイアウトのみ実装。
// 各機能ボタンは navigate() で将来のサブ画面へ接続できる構造にしてある。
// ============================================================
import React, { useMemo } from "react";
import {
  FileText,
  List,
  Calendar,
  Zap,
  ChevronRight,
} from "lucide-react";
import { T } from "../components/tokens.js";
import { ProcessBadge } from "../components/Card.jsx";
import { useSchedules }  from "../hooks/useLocalDB.js";
import { todayStr }      from "../utils/storage.js";

/**
 * 工程タブ メイン画面
 *
 * @param {Function} navigate  画面遷移（将来のサブ画面用）
 */
export default function ProcessScreen({ navigate }) {
  const { schedules } = useSchedules();
  const today         = todayStr();

  // ── 統計データ ───────────────────────────────────────────
  const todayItems = useMemo(
    () => schedules.filter((s) => s.startDate <= today && s.endDate >= today),
    [schedules, today]
  );

  const upcomingItems = useMemo(() => {
    const weekLater = new Date();
    weekLater.setDate(weekLater.getDate() + 7);
    const weekStr = weekLater.toISOString().slice(0, 10);
    return schedules.filter(
      (s) => s.startDate > today && s.startDate <= weekStr
    ).sort((a, b) => a.startDate.localeCompare(b.startDate));
  }, [schedules, today]);

  const totalItems = schedules.length;

  // ── 機能メニュー定義 ────────────────────────────────────
  // 将来 navigate("ocr") などのサブ画面へ接続する
  const MENU_ITEMS = [
    {
      key:     "ocr",
      icon:    FileText,
      label:   "工程表を読み込む",
      sub:     "撮影 → AI 解析 → 自動登録",
      color:   T.gold,
      onPress: () => navigate("ocr"),
      ready:   true,
    },
    {
      key:     "list",
      icon:    List,
      label:   "工程一覧",
      sub:     "登録済み工程の確認・編集",
      color:   T.blue,
      onPress: () => navigate("schedule"),
      ready:   true,
    },
    {
      key:     "calendar-screen",
      icon:    Calendar,
      label:   "カレンダー表示",
      sub:     "月表示で工程を確認・エクスポート",
      color:   T.green,
      onPress: () => navigate("calendar-screen"),
      ready:   true,
    },
    {
      key:     "google",
      icon:    Calendar,
      label:   "Google カレンダー連携",
      sub:     "工程を Google カレンダーへ書き出し",
      color:   "#4CAF50",
      onPress: () => {},   // Phase 3 で実装
      ready:   false,
    },
    {
      key:     "apple",
      icon:    Calendar,
      label:   "Apple カレンダー連携",
      sub:     "工程を iPhone カレンダーへ書き出し",
      color:   "#007AFF",
      onPress: () => {},
      ready:   false,
    },
    {
      key:     "ai",
      icon:    Zap,
      label:   "AI 工程解析",
      sub:     "工程の最適化・提案（準備中）",
      color:   T.purple,
      onPress: () => {},   // Phase 3 で実装
      ready:   false,
    },
  ];

  return (
    <div style={{ paddingBottom: 100 }}>

      {/* ── ヘッダー ──────────────────────────────────────── */}
      <div style={{ padding: "22px 20px 16px" }}>
        <div
          style={{
            fontSize:      13,
            color:         T.gold,
            fontWeight:    700,
            letterSpacing: 2,
            marginBottom:  2,
          }}
        >
          PROCESS
        </div>
        <div style={{ fontSize: 22, fontWeight: 800, color: T.white }}>
          工程管理
        </div>
      </div>

      {/* ── サマリーカード ────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          gap:     10,
          padding: "0 16px 20px",
        }}
      >
        <SummaryCard
          icon={Clock}
          label="今日の工程"
          value={todayItems.length}
          unit="件"
          color={todayItems.length > 0 ? T.gold : T.whiteFaint}
        />
        <SummaryCard
          icon={AlertCircle}
          label="今週の予定"
          value={upcomingItems.length}
          unit="件"
          color={upcomingItems.length > 0 ? T.blue : T.whiteFaint}
        />
        <SummaryCard
          icon={CheckCircle}
          label="登録済み"
          value={totalItems}
          unit="件"
          color={T.green}
        />
      </div>

      {/* ── 今日の工程（最大3件プレビュー） ─────────────── */}
      {todayItems.length > 0 && (
        <div style={{ padding: "0 16px 20px" }}>
          <SectionLabel>今日の工程</SectionLabel>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {todayItems.slice(0, 3).map((s) => (
              <TodayScheduleRow key={s.id} schedule={s} />
            ))}
            {todayItems.length > 3 && (
              <div
                style={{
                  textAlign:  "center",
                  color:      T.whiteFaint,
                  fontSize:   12,
                  paddingTop: 4,
                }}
              >
                他 {todayItems.length - 3} 件
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── 機能メニュー ──────────────────────────────────── */}
      <div style={{ padding: "0 16px" }}>
        <SectionLabel>機能</SectionLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {MENU_ITEMS.map((item) => (
            <MenuRow key={item.key} item={item} />
          ))}
        </div>
      </div>

      {/* ── 今後追加予定の説明 ────────────────────────────── */}
      <div style={{ padding: "24px 16px 0" }}>
        <div
          style={{
            background:   `${T.gold}0A`,
            border:       `1px solid ${T.gold}20`,
            borderRadius: 14,
            padding:      "14px 16px",
          }}
        >
          <div
            style={{
              fontSize:     12,
              color:        T.gold,
              fontWeight:   700,
              marginBottom: 6,
            }}
          >
            Phase 3 以降で追加予定
          </div>
          <div
            style={{
              color:      T.whiteFaint,
              fontSize:   12,
              lineHeight: 1.7,
            }}
          >
            Google カレンダー連携 / Apple カレンダー連携 /
            AI 工程最適化 / ガントチャート表示 / 進捗管理
          </div>
        </div>
      </div>
    </div>
  );
}

// ── 内部コンポーネント ────────────────────────────────────────

/** サマリー数値カード */
function SummaryCard({ icon: Icon, label, value, unit, color }) {
  return (
    <div
      style={{
        flex:          1,
        background:    T.card,
        border:        `1px solid ${T.cardBorder}`,
        borderRadius:  14,
        padding:       "12px 10px",
        textAlign:     "center",
      }}
    >
      <Icon size={16} color={color} style={{ marginBottom: 6 }} />
      <div
        style={{
          fontSize:   22,
          fontWeight: 800,
          color,
          lineHeight: 1,
        }}
      >
        {value}
      </div>
      <div style={{ fontSize: 9, color: T.whiteFaint, marginTop: 3 }}>
        {unit}
      </div>
      <div style={{ fontSize: 10, color: T.whiteFaint, marginTop: 4 }}>
        {label}
      </div>
    </div>
  );
}

/** 今日の工程行 */
function TodayScheduleRow({ schedule: s }) {
  return (
    <div
      style={{
        background:   T.card,
        border:       `1px solid ${T.gold}40`,
        borderRadius: 12,
        padding:      "10px 14px",
        display:      "flex",
        alignItems:   "center",
        gap:          10,
      }}
    >
      <ProcessBadge type={s.processType} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            color:        T.white,
            fontSize:     13,
            fontWeight:   700,
            overflow:     "hidden",
            textOverflow: "ellipsis",
            whiteSpace:   "nowrap",
          }}
        >
          {[s.siteName, s.floor, s.room].filter(Boolean).join(" ")}
        </div>
        <div style={{ color: T.whiteFaint, fontSize: 11, marginTop: 1 }}>
          {s.processName}
          {s.contractor ? `  ／  ${s.contractor}` : ""}
        </div>
      </div>
    </div>
  );
}

/** 機能メニュー行 */
function MenuRow({ item }) {
  const { icon: Icon, label, sub, color, onPress, ready } = item;

  return (
    <button
      onClick={onPress}
      disabled={!ready}
      style={{
        background:              T.card,
        border:                  `1px solid ${T.cardBorder}`,
        borderRadius:            16,
        padding:                 "14px 16px",
        display:                 "flex",
        alignItems:              "center",
        gap:                     14,
        cursor:                  ready ? "pointer" : "default",
        WebkitTapHighlightColor: "transparent",
        width:                   "100%",
        textAlign:               "left",
        opacity:                 ready ? 1 : 0.45,
      }}
    >
      {/* アイコン背景 */}
      <div
        style={{
          width:          44,
          height:         44,
          borderRadius:   12,
          background:     ready ? color + "18" : T.bgElevated,
          display:        "flex",
          alignItems:     "center",
          justifyContent: "center",
          flexShrink:     0,
        }}
      >
        <Icon size={22} color={ready ? color : T.whiteFaint} strokeWidth={1.8} />
      </div>

      {/* テキスト */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            color:      T.white,
            fontSize:   15,
            fontWeight: 700,
          }}
        >
          {label}
        </div>
        <div
          style={{
            color:     T.whiteFaint,
            fontSize:  12,
            marginTop: 2,
          }}
        >
          {sub}
        </div>
      </div>

      {/* 矢印 / 準備中バッジ */}
      {ready ? (
        <ChevronRight size={18} color={T.whiteFaint} style={{ flexShrink: 0 }} />
      ) : (
        <span
          style={{
            fontSize:     10,
            fontWeight:   700,
            color:        T.whiteFaint,
            background:   T.bgElevated,
            border:       `1px solid ${T.cardBorder}`,
            borderRadius: 6,
            padding:      "3px 7px",
            flexShrink:   0,
            whiteSpace:   "nowrap",
          }}
        >
          準備中
        </span>
      )}
    </button>
  );
}

/** セクションラベル */
function SectionLabel({ children }) {
  return (
    <div
      style={{
        fontSize:      12,
        color:         T.whiteFaint,
        fontWeight:    700,
        letterSpacing: 0.5,
        marginBottom:  10,
      }}
    >
      {children}
    </div>
  );
}
