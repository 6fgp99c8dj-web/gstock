// src/pages/Photos.jsx
import React, { useState, useMemo, useRef, useCallback } from "react";
import { Camera } from "lucide-react";
import { T } from "../components/tokens.js";
import TopBar         from "../components/TopBar.jsx";
import FloatingButton from "../components/FloatingButton.jsx";
import EmptyState     from "../components/EmptyState.jsx";
import { CatChip }    from "../components/Card.jsx";
import { usePhotos }  from "../hooks/useLocalDB.js";
import { useSites }   from "../hooks/useLocalDB.js";

/**
 * 写真管理画面
 * @param {Function} navigate
 */
export default function Photos({ navigate }) {
  const { photos, addPhoto } = usePhotos();
  const { sites }            = useSites();

  const [siteFilter,   setSiteFilter]   = useState("all");
  const [pendingSiteId, setPendingSiteId] = useState(sites[0]?.id ?? "");
  const fileRef = useRef(null);

  // フィルタ済み写真（新しい順）
  const filtered = useMemo(() => {
    const list =
      siteFilter === "all"
        ? photos
        : photos.filter((p) => p.siteId === siteFilter);
    return [...list].sort((a, b) => b.createdAt - a.createdAt);
  }, [photos, siteFilter]);

  const siteName = useCallback(
    (id) => sites.find((s) => s.id === id)?.name ?? "未設定",
    [sites]
  );

  // ファイル選択 → DataURL に変換して保存
  const handleUpload = useCallback(
    (e) => {
      const file = e.target.files?.[0];
      if (!file) return;

      // ファイルサイズ上限チェック（10MB）
      if (file.size > 10 * 1024 * 1024) {
        alert("ファイルサイズが大きすぎます（上限 10MB）");
        e.target.value = "";
        return;
      }

      const reader    = new FileReader();
      reader.onload   = () => {
        addPhoto({
          siteId:  pendingSiteId || null,
          dataUrl: reader.result,
          caption: "",
        });
      };
      reader.onerror  = () => {
        alert("写真の読み込みに失敗しました。別の画像をお試しください。");
      };
      reader.readAsDataURL(file);
      e.target.value = "";
    },
    [pendingSiteId, addPhoto]
  );

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="写真" />

      {/* 現場フィルタチップ */}
      <div
        style={{
          display:    "flex",
          gap:        8,
          overflowX:  "auto",
          padding:    "10px 16px",
          WebkitOverflowScrolling: "touch",
        }}
      >
        <CatChip
          active={siteFilter === "all"}
          onClick={() => setSiteFilter("all")}
          label="すべて"
        />
        {sites.map((s) => (
          <CatChip
            key={s.id}
            active={siteFilter === s.id}
            onClick={() => setSiteFilter(s.id)}
            label={s.name}
          />
        ))}
      </div>

      {/* 写真グリッド */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Camera}
          text="写真がありません"
          sub="右下のカメラボタンから撮影・追加してください"
        />
      ) : (
        <div
          style={{
            display:             "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap:                 6,
            padding:             "4px 16px",
          }}
        >
          {filtered.map((ph) => (
            <div
              key={ph.id}
              style={{
                position:     "relative",
                borderRadius: 10,
                overflow:     "hidden",
                aspectRatio:  "1",
              }}
            >
              <img
                src={ph.dataUrl}
                alt=""
                style={{
                  width:     "100%",
                  height:    "100%",
                  objectFit: "cover",
                }}
              />
              {/* 現場名オーバーレイ */}
              <div
                style={{
                  position:   "absolute",
                  bottom:     0,
                  left:       0,
                  right:      0,
                  padding:    "4px 6px",
                  background: "linear-gradient(transparent, rgba(0,0,0,0.7))",
                  fontSize:   10,
                  color:      T.white,
                }}
              >
                {siteName(ph.siteId)}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 保存先現場セレクト */}
      {sites.length > 0 && (
        <div style={{ padding: "12px 16px 0" }}>
          <div
            style={{
              fontSize:     12,
              color:        T.whiteFaint,
              marginBottom: 6,
              fontWeight:   600,
            }}
          >
            保存先の現場
          </div>
          <select
            value={pendingSiteId}
            onChange={(e) => setPendingSiteId(e.target.value)}
            style={{
              width:        "100%",
              boxSizing:    "border-box",
              background:   T.card,
              border:       `1px solid ${T.cardBorder}`,
              borderRadius: 12,
              padding:      "13px 14px",
              color:        T.white,
              fontSize:     15,
              outline:      "none",
            }}
          >
            {sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* ファイル入力（不可視） */}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleUpload}
        style={{ display: "none" }}
      />

      <FloatingButton
        icon={Camera}
        onClick={() => fileRef.current?.click()}
      />
    </div>
  );
}
