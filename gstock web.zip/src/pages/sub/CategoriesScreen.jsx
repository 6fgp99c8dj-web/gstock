// src/pages/sub/CategoriesScreen.jsx
import React, { useState, useMemo, useCallback } from "react";
import { Package, Edit2, Trash2 } from "lucide-react";
import { T, iconBtnStyle } from "../../components/tokens.js";
import TopBar           from "../../components/TopBar.jsx";
import SearchBar        from "../../components/SearchBar.jsx";
import FloatingButton   from "../../components/FloatingButton.jsx";
import EmptyState       from "../../components/EmptyState.jsx";
import Modal            from "../../components/Modal.jsx";
import {
  TextField,
  PrimaryButton,
  ConfirmDeleteModal,
} from "../../components/Card.jsx";
import { useInventory, useSearch } from "../../hooks/useLocalDB.js";

/**
 * カテゴリ管理画面
 * @param {Function} navigate
 * @param {Function} onBack
 */
export default function CategoriesScreen({ navigate, onBack }) {
  const {
    categories,
    products,
    addCategory,
    editCategory,
    deleteCategory,
  } = useInventory();

  const { query, setQuery, filtered } = useSearch(categories, ["name"]);
  const sorted = useMemo(
    () => [...filtered].sort((a, b) => b.createdAt - a.createdAt),
    [filtered]
  );

  const [modalOpen,    setModalOpen]    = useState(false);
  const [editing,      setEditing]      = useState(null);
  const [name,         setName]         = useState("");
  const [deleteTarget, setDeleteTarget] = useState(null);

  const openNew = useCallback(() => {
    setEditing(null);
    setName("");
    setModalOpen(true);
  }, []);

  const openEdit = useCallback((c) => {
    setEditing(c);
    setName(c.name);
    setModalOpen(true);
  }, []);

  const handleSave = useCallback(() => {
    if (!name.trim()) return;
    if (editing) {
      editCategory(editing.id, name);
    } else {
      addCategory(name);
    }
    setModalOpen(false);
  }, [name, editing, editCategory, addCategory]);

  const handleDelete = useCallback(() => {
    deleteCategory(deleteTarget.id);
    setDeleteTarget(null);
  }, [deleteTarget, deleteCategory]);

  const productCount = useCallback(
    (catId) => products.filter((p) => p.categoryId === catId).length,
    [products]
  );

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="カテゴリ" onBack={onBack} />
      <SearchBar value={query} onChange={setQuery} placeholder="カテゴリを検索" />

      {sorted.length === 0 ? (
        <EmptyState
          icon={Package}
          text="カテゴリがありません"
          sub="右下の＋から追加してください"
        />
      ) : (
        <div
          style={{
            padding:       "4px 16px",
            display:       "flex",
            flexDirection: "column",
            gap:           10,
          }}
        >
          {sorted.map((c) => (
            <div
              key={c.id}
              style={{
                background:   T.card,
                border:       `1px solid ${T.cardBorder}`,
                borderRadius: 16,
                padding:      "14px 16px",
                display:      "flex",
                alignItems:   "center",
              }}
            >
              {/* カテゴリ名（タップで商品一覧へ） */}
              <button
                onClick={() => navigate("products", { categoryId: c.id })}
                style={{
                  flex:                    1,
                  background:              "none",
                  border:                  "none",
                  textAlign:               "left",
                  cursor:                  "pointer",
                  WebkitTapHighlightColor: "transparent",
                  minWidth:                0,
                }}
              >
                <div style={{ color: T.white, fontSize: 16, fontWeight: 700 }}>
                  {c.name}
                </div>
                <div style={{ color: T.whiteFaint, fontSize: 12, marginTop: 3 }}>
                  {productCount(c.id)} 商品
                </div>
              </button>

              <button onClick={() => openEdit(c)} style={iconBtnStyle}>
                <Edit2 size={18} color={T.whiteDim} />
              </button>
              <button onClick={() => setDeleteTarget(c)} style={iconBtnStyle}>
                <Trash2 size={18} color={T.danger} />
              </button>
            </div>
          ))}
        </div>
      )}

      <FloatingButton onClick={openNew} />

      {/* 追加 / 編集モーダル */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "カテゴリ編集" : "カテゴリ追加"}
      >
        <TextField
          label="カテゴリ名"
          value={name}
          onChange={setName}
          placeholder="例：防水資材"
          autoFocus
        />
        <PrimaryButton onClick={handleSave} disabled={!name.trim()}>
          保存
        </PrimaryButton>
      </Modal>

      {/* 削除確認 */}
      <ConfirmDeleteModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        itemName={deleteTarget?.name}
      />
    </div>
  );
}
