// src/pages/sub/ProfileScreen.jsx
import React, { useState, useCallback } from "react";
import { T } from "../../components/tokens.js";
import TopBar from "../../components/TopBar.jsx";
import {
  TextField,
  PrimaryButton,
  GhostButton,
} from "../../components/Card.jsx";
import { useDB } from "../../context/DBContext.jsx";

/**
 * 詳細プロフィール設定画面
 * - 会社名 / 業者名
 * - 略称・別名
 * - AI 学習データ確認・リセット
 *
 * @param {Function} onBack
 */
export default function ProfileScreen({ onBack }) {
  const { db, update } = useDB();

  const [companyName, setCompanyName] = useState(
    db.userProfile?.companyName ?? ""
  );
  const [aliases, setAliases] = useState(
    (db.userProfile?.contractorAliases ?? []).join("、")
  );
  const [saved, setSaved] = useState(false);

  const handleSave = useCallback(() => {
    const aliasList = aliases
      .split(/[、,，\s]+/)
      .map((s) => s.trim())
      .filter(Boolean);

    update((prev) => ({
      userProfile: {
        ...prev.userProfile,
        companyName:       companyName.trim(),
        contractorAliases: aliasList,
      },
    }));

    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  }, [companyName, aliases, update]);

  const handleResetLearning = useCallback(() => {
    if (!window.confirm("AI 学習データをリセットしますか？")) return;
    update({ ocrLearning: [] });
  }, [update]);

  const learningData  = db.ocrLearning ?? [];
  const learningCount = learningData.length;

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="プロフィール設定" onBack={onBack} />

      <div style={{ padding: "16px 16px 0" }}>

        {/* 説明バナー */}
        <div
          style={{
            background:   `${T.gold}12`,
            border:       `1px solid ${T.gold}30`,
            borderRadius: 14,
            padding:      "12px 14px",
            marginBottom: 20,
          }}
        >
          <div
            style={{
              color:        T.gold,
              fontSize:     13,
              fontWeight:   700,
              marginBottom: 4,
            }}
          >
            業者名フィルタについて
          </div>
          <div
            style={{
              color:      T.whiteDim,
              fontSize:   12,
              lineHeight: 1.6,
            }}
          >
            会社名・業者名を登録すると、工程表 OCR で自分の担当工程のみを
            自動抽出します。略称・別名も登録しておくと精度が上がります。
          </div>
        </div>

        {/* 入力フォーム */}
        <TextField
          label="会社名 / 業者名"
          value={companyName}
          onChange={setCompanyName}
          placeholder="例：松尾シーリング"
          autoFocus
        />
        <TextField
          label="略称・別名（複数は「、」区切り）"
          value={aliases}
          onChange={setAliases}
          placeholder="例：松尾、マツオ"
        />

        <PrimaryButton
          onClick={handleSave}
          disabled={!companyName.trim()}
        >
          {saved ? "保存しました ✓" : "保存する"}
        </PrimaryButton>

        {/* AI 学習データ */}
        <div
          style={{
            fontSize:     12,
            color:        T.whiteFaint,
            fontWeight:   700,
            margin:       "28px 0 10px",
            letterSpacing: 0.5,
          }}
        >
          AI 学習データ
        </div>

        <div
          style={{
            background:   T.card,
            border:       `1px solid ${T.cardBorder}`,
            borderRadius: 14,
            padding:      "14px 16px",
            marginBottom: 12,
          }}
        >
          <div style={{ color: T.white, fontSize: 14, fontWeight: 700 }}>
            学習済み修正件数：{learningCount} 件
          </div>
          <div
            style={{
              color:     T.whiteFaint,
              fontSize:  12,
              marginTop: 4,
            }}
          >
            工程表 OCR で修正した内容が次回解析に活用されます
          </div>
        </div>

        {/* 直近の学習履歴 */}
        {learningCount > 0 && (
          <div style={{ marginBottom: 12 }}>
            <div
              style={{
                fontSize:     12,
                color:        T.gold,
                fontWeight:   700,
                marginBottom: 8,
              }}
            >
              直近の修正履歴
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {learningData.slice(-8).reverse().map((l) => (
                <div
                  key={l.id}
                  style={{
                    background:   T.card,
                    borderRadius: 10,
                    padding:      "8px 12px",
                    border:       `1px solid ${T.cardBorder}`,
                  }}
                >
                  <div style={{ fontSize: 11, color: T.whiteFaint }}>
                    {l.field}
                  </div>
                  <div style={{ fontSize: 12, color: T.whiteDim, marginTop: 2 }}>
                    「{l.original}」→「{l.corrected}」
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {learningCount > 0 && (
          <button
            onClick={handleResetLearning}
            style={{
              background: "none",
              border:     "none",
              color:      T.danger,
              fontSize:   13,
              cursor:     "pointer",
              padding:    "8px 0",
            }}
          >
            学習データをリセット
          </button>
        )}
      </div>
    </div>
  );
}
