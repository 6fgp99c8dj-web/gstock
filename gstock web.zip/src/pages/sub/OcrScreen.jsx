// src/pages/sub/OcrScreen.jsx
import React, { useState, useRef, useCallback } from "react";
import {
  FileText, Plus, X, Zap, Edit2, CheckCircle, AlertCircle,
} from "lucide-react";
import { T, iconBtnStyle, processColor } from "../../components/tokens.js";
import TopBar       from "../../components/TopBar.jsx";
import Modal        from "../../components/Modal.jsx";
import {
  StepIndicator,
  ProcessBadge,
  TextField,
  PrimaryButton,
  GhostButton,
} from "../../components/Card.jsx";
import { useDB }         from "../../context/DBContext.jsx";
import { useSchedules }  from "../../hooks/useLocalDB.js";
import {
  preprocessImage,
  analyzeScheduleImage,
  mergeScheduleResults,
  applyCompanyFilter,
  PROCESS_TYPES,
} from "../../utils/ocr.js";
import { uid } from "../../utils/storage.js";

// useOCRLearning は useLocalDB に未定義のため、
// useSchedules を利用して学習データを管理するインライン実装
// （useLocalDB への追加は Phase 9 以降で統合予定）
function useOCRLearningFallback() {
  const { db, update } = useDB();
  const addLearning = useCallback((field, original, corrected) => {
    if (original === corrected) return;
    update((prev) => ({
      ocrLearning: [
        ...(prev.ocrLearning ?? []),
        { id: uid(), field, original, corrected, createdAt: Date.now() },
      ].slice(-50),
    }));
  }, [update]);
  return { ocrLearning: db.ocrLearning ?? [], addLearning };
}

/**
 * 工程表 OCR 画面
 * 撮影 → 前処理 → AI 解析 → 確認・修正 → カレンダー登録
 *
 * @param {Function} navigate
 * @param {Function} onBack
 */
export default function OcrScreen({ navigate, onBack }) {
  const { db }                                    = useDB();
  const { addSchedules, addOcrHistory }           = useSchedules();
  const { ocrLearning, addLearning }              = useOCRLearningFallback();

  const [step,        setStep]        = useState("capture");
  // capture | processing | review | done
  const [images,      setImages]      = useState([]);
  const [results,     setResults]     = useState(null);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [progress,    setProgress]    = useState({ current: 0, total: 0, msg: "" });
  const [error,       setError]       = useState("");
  const [editingIdx,  setEditingIdx]  = useState(null);
  const fileRef = useRef(null);

  const hasCompany = !!db.userProfile?.companyName;

  // ── 画像追加 ─────────────────────────────────────────────
  const handleFiles = useCallback((e) => {
    const files = Array.from(e.target.files ?? []);
    setImages((prev) => [
      ...prev,
      ...files.map((f) => ({ file: f, preview: URL.createObjectURL(f) })),
    ]);
    e.target.value = "";
  }, []);

  const removeImage = useCallback((idx) => {
    setImages((prev) => {
      URL.revokeObjectURL(prev[idx].preview);
      return prev.filter((_, i) => i !== idx);
    });
  }, []);

  // ── AI 解析実行 ──────────────────────────────────────────
  const analyze = useCallback(async () => {
    if (!images.length) return;
    setStep("processing");
    setError("");
    try {
      const raws = [];
      for (let i = 0; i < images.length; i++) {
        setProgress({
          current: i + 1,
          total:   images.length,
          msg:     `画像 ${i + 1} / ${images.length} を解析中…`,
        });
        const b64 = await preprocessImage(images[i].file);
        const res = await analyzeScheduleImage(
          b64,
          db.userProfile,
          ocrLearning
        );
        raws.push(res);
      }
      setProgress({ current: images.length, total: images.length, msg: "統合中…" });
      const merged = mergeScheduleResults(raws);
      merged.schedules = applyCompanyFilter(merged.schedules, db.userProfile);
      setResults(merged);
      setSelectedIds(new Set(merged.schedules.map((s) => s.id)));
      setStep("review");
    } catch (e) {
      setError(`解析エラー: ${e.message}`);
      setStep("capture");
    }
  }, [images, db.userProfile, ocrLearning]);

  // ── フィールド修正 + 学習記録 ────────────────────────────
  const patchSchedule = useCallback((idx, field, val) => {
    const old = results.schedules[idx];
    addLearning(field, old[field], val);
    setResults((prev) => ({
      ...prev,
      schedules: prev.schedules.map((s, i) =>
        i === idx ? { ...s, [field]: val } : s
      ),
    }));
  }, [results, addLearning]);

  // ── カレンダーへ登録 ────────────────────────────────────
  const register = useCallback(() => {
    const toAdd = results.schedules
      .filter((s) => selectedIds.has(s.id))
      .map((s) => ({
        ...s,
        id:         uid(),
        source:     "ocr",
        confirmed:  false,
        createdAt:  Date.now(),
      }));
    addSchedules(toAdd);
    addOcrHistory({ imageCount: images.length, resultCount: toAdd.length });
    setStep("done");
  }, [results, selectedIds, addSchedules, addOcrHistory, images.length]);

  // ── リセット ─────────────────────────────────────────────
  const reset = useCallback(() => {
    images.forEach((img) => URL.revokeObjectURL(img.preview));
    setImages([]);
    setResults(null);
    setError("");
    setStep("capture");
    setSelectedIds(new Set());
  }, [images]);

  const pct = progress.total
    ? (progress.current / progress.total) * 100
    : 10;

  const stepIndex = { capture: 0, processing: 1, review: 2, done: 3 }[step];

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="工程表 OCR" onBack={onBack} />

      <StepIndicator
        steps={["撮影", "AI 解析", "確認・修正", "完了"]}
        current={stepIndex}
      />

      {/* 業者未登録の警告 */}
      {!hasCompany && (
        <div
          style={{
            margin:       "0 16px 10px",
            background:   `${T.gold}15`,
            border:       `1px solid ${T.gold}40`,
            borderRadius: 14,
            padding:      "10px 14px",
            display:      "flex",
            alignItems:   "center",
            gap:          8,
          }}
        >
          <AlertCircle size={16} color={T.gold} />
          <span style={{ color: T.gold, fontSize: 12, fontWeight: 700 }}>
            設定から業者名を登録すると担当工程を自動フィルタします
          </span>
        </div>
      )}

      {/* ── STEP 1: 撮影 ───────────────────────────────── */}
      {step === "capture" && (
        <div style={{ padding: "0 16px" }}>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFiles}
            style={{ display: "none" }}
          />

          {images.length === 0 ? (
            <div
              style={{
                background:   T.card,
                border:       `2px dashed ${T.cardBorder}`,
                borderRadius: 20,
                padding:      "48px 24px",
                textAlign:    "center",
              }}
            >
              <FileText
                size={52}
                color={T.whiteFaint}
                strokeWidth={1.2}
                style={{ marginBottom: 14 }}
              />
              <div
                style={{
                  color:        T.white,
                  fontSize:     17,
                  fontWeight:   700,
                  marginBottom: 6,
                }}
              >
                工程表を撮影・選択
              </div>
              <div
                style={{
                  color:        T.whiteFaint,
                  fontSize:     12,
                  lineHeight:   1.7,
                  marginBottom: 24,
                }}
              >
                月間・週間・Excel 印刷・紙の写真<br />
                傾き・影・折れも対応 / 複数枚 OK
              </div>
              <PrimaryButton onClick={() => fileRef.current.click()}>
                📷　撮影 / 画像を選択
              </PrimaryButton>
            </div>
          ) : (
            <>
              {/* サムネイルグリッド */}
              <div
                style={{
                  display:             "grid",
                  gridTemplateColumns: "repeat(3, 1fr)",
                  gap:                 8,
                  marginBottom:        16,
                }}
              >
                {images.map((img, idx) => (
                  <div
                    key={idx}
                    style={{
                      position:     "relative",
                      aspectRatio:  "3/4",
                      borderRadius: 12,
                      overflow:     "hidden",
                    }}
                  >
                    <img
                      src={img.preview}
                      alt=""
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                    <button
                      onClick={() => removeImage(idx)}
                      style={{
                        position:       "absolute",
                        top:            6,
                        right:          6,
                        width:          24,
                        height:         24,
                        borderRadius:   12,
                        background:     "rgba(0,0,0,0.7)",
                        border:         "none",
                        cursor:         "pointer",
                        display:        "flex",
                        alignItems:     "center",
                        justifyContent: "center",
                      }}
                    >
                      <X size={13} color={T.white} />
                    </button>
                    <span
                      style={{
                        position:     "absolute",
                        bottom:       6,
                        left:         6,
                        background:   "rgba(0,0,0,0.7)",
                        borderRadius: 6,
                        padding:      "2px 7px",
                        fontSize:     11,
                        color:        T.white,
                        fontWeight:   700,
                      }}
                    >
                      {idx + 1}
                    </span>
                  </div>
                ))}

                {/* 追加ボタン */}
                <button
                  onClick={() => fileRef.current.click()}
                  style={{
                    aspectRatio:    "3/4",
                    borderRadius:   12,
                    background:     T.card,
                    border:         `2px dashed ${T.cardBorder}`,
                    cursor:         "pointer",
                    display:        "flex",
                    flexDirection:  "column",
                    alignItems:     "center",
                    justifyContent: "center",
                    gap:            6,
                  }}
                >
                  <Plus size={22} color={T.whiteFaint} />
                  <span style={{ fontSize: 11, color: T.whiteFaint }}>追加</span>
                </button>
              </div>

              <PrimaryButton onClick={analyze}>
                <Zap size={18} /> AI 解析開始（{images.length} 枚）
              </PrimaryButton>
              <GhostButton onClick={reset}>やり直す</GhostButton>
            </>
          )}

          {error && (
            <div
              style={{
                marginTop:    12,
                background:   `${T.danger}20`,
                border:       `1px solid ${T.danger}`,
                borderRadius: 12,
                padding:      "12px 14px",
                color:        T.red,
                fontSize:     13,
              }}
            >
              {error}
            </div>
          )}
        </div>
      )}

      {/* ── STEP 2: 解析中 ─────────────────────────────── */}
      {step === "processing" && (
        <div style={{ padding: "60px 24px", textAlign: "center" }}>
          {/* スピナー */}
          <div
            style={{
              position: "relative",
              width:    96,
              height:   96,
              margin:   "0 auto 24px",
            }}
          >
            <svg width="96" height="96" style={{ position: "absolute", inset: 0 }}>
              <circle
                cx="48" cy="48" r="42"
                fill="none" stroke={T.cardBorder} strokeWidth="6"
              />
              <circle
                cx="48" cy="48" r="42"
                fill="none" stroke={T.gold} strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray="264" strokeDashoffset="66"
                style={{
                  animation:       "gstock-spin 1.4s linear infinite",
                  transformOrigin: "48px 48px",
                }}
              />
            </svg>
            <div
              style={{
                position:       "absolute",
                inset:          0,
                display:        "flex",
                alignItems:     "center",
                justifyContent: "center",
              }}
            >
              <Zap size={30} color={T.gold} />
            </div>
          </div>

          <div style={{ color: T.white, fontSize: 16, fontWeight: 700, marginBottom: 8 }}>
            AI 解析中…
          </div>
          <div style={{ color: T.whiteDim, fontSize: 13, marginBottom: 16 }}>
            {progress.msg}
          </div>

          {/* プログレスバー */}
          <div
            style={{
              background:   T.card,
              borderRadius: 4,
              height:       5,
              overflow:     "hidden",
            }}
          >
            <div
              style={{
                height:     "100%",
                background: T.gold,
                borderRadius: 4,
                width:      `${pct}%`,
                transition: "width 0.4s ease",
              }}
            />
          </div>
          <div style={{ color: T.whiteFaint, fontSize: 11, marginTop: 8 }}>
            {progress.current} / {progress.total} 枚処理済
          </div>
          <div
            style={{
              color:      T.whiteFaint,
              fontSize:   11,
              marginTop:  18,
              lineHeight: 1.6,
            }}
          >
            速度より精度を優先しています。<br />しばらくお待ちください。
          </div>
        </div>
      )}

      {/* ── STEP 3: 確認・修正 ─────────────────────────── */}
      {step === "review" && results && (
        <div style={{ padding: "0 16px" }}>
          {/* テーブル情報 */}
          {results.tableInfo?.projectName && (
            <div
              style={{
                background:   T.card,
                border:       `1px solid ${T.cardBorder}`,
                borderRadius: 14,
                padding:      "12px 14px",
                marginBottom: 10,
              }}
            >
              <div
                style={{
                  fontSize:     11,
                  color:        T.gold,
                  fontWeight:   700,
                  marginBottom: 2,
                }}
              >
                読み取り情報
              </div>
              <div style={{ color: T.white, fontSize: 14, fontWeight: 700 }}>
                {results.tableInfo.projectName}
              </div>
              {results.tableInfo.period && (
                <div style={{ color: T.whiteDim, fontSize: 12, marginTop: 2 }}>
                  {results.tableInfo.period}
                </div>
              )}
            </div>
          )}

          {/* 全選択 / 件数 */}
          <div
            style={{
              display:        "flex",
              justifyContent: "space-between",
              alignItems:     "center",
              marginBottom:   8,
            }}
          >
            <span style={{ color: T.whiteDim, fontSize: 13 }}>
              {results.schedules.length} 件を検出
            </span>
            <button
              onClick={() =>
                setSelectedIds(
                  selectedIds.size === results.schedules.length
                    ? new Set()
                    : new Set(results.schedules.map((s) => s.id))
                )
              }
              style={{
                background: "none",
                border:     "none",
                color:      T.gold,
                fontSize:   13,
                fontWeight: 700,
                cursor:     "pointer",
              }}
            >
              {selectedIds.size === results.schedules.length ? "全解除" : "全選択"}
            </button>
          </div>

          {/* カード一覧 */}
          <div
            style={{
              display:       "flex",
              flexDirection: "column",
              gap:           10,
              marginBottom:  16,
            }}
          >
            {results.schedules.map((s, idx) => (
              <OcrResultCard
                key={s.id}
                schedule={s}
                selected={selectedIds.has(s.id)}
                onToggle={() =>
                  setSelectedIds((prev) => {
                    const next = new Set(prev);
                    next.has(s.id) ? next.delete(s.id) : next.add(s.id);
                    return next;
                  })
                }
                onEdit={() => setEditingIdx(idx)}
              />
            ))}
          </div>

          <PrimaryButton
            onClick={register}
            disabled={selectedIds.size === 0}
          >
            <CheckCircle size={18} />
            {selectedIds.size} 件をカレンダーに登録
          </PrimaryButton>
          <GhostButton onClick={reset}>やり直す</GhostButton>
        </div>
      )}

      {/* ── STEP 4: 完了 ───────────────────────────────── */}
      {step === "done" && (
        <div style={{ padding: "60px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>✅</div>
          <div style={{ color: T.white, fontSize: 20, fontWeight: 800, marginBottom: 8 }}>
            登録完了！
          </div>
          <div style={{ color: T.whiteDim, fontSize: 14, marginBottom: 28 }}>
            カレンダーに追加しました
          </div>
          <PrimaryButton onClick={() => navigate("schedule")}>
            スケジュールを確認
          </PrimaryButton>
          <GhostButton onClick={reset}>続けて撮影する</GhostButton>
        </div>
      )}

      {/* 修正モーダル */}
      {editingIdx !== null && results && (
        <ScheduleEditModal
          schedule={results.schedules[editingIdx]}
          onSave={(field, val) => {
            patchSchedule(editingIdx, field, val);
            setEditingIdx(null);
          }}
          onClose={() => setEditingIdx(null)}
        />
      )}
    </div>
  );
}

// ── OCR 結果カード ────────────────────────────────────────────
function OcrResultCard({ schedule: s, selected, onToggle, onEdit }) {
  const conf       = s.confidence ?? 0;
  const confColor  =
    conf >= 0.9 ? T.green : conf >= 0.7 ? T.gold : T.red;

  return (
    <div
      style={{
        background:   T.card,
        borderRadius: 16,
        padding:      "14px 14px",
        border:       `1px solid ${selected ? T.gold : T.cardBorder}`,
        opacity:      selected ? 1 : 0.5,
        transition:   "all 0.2s",
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
        {/* チェックボックス */}
        <button
          onClick={onToggle}
          style={{
            width:          24,
            height:         24,
            borderRadius:   6,
            flexShrink:     0,
            marginTop:      2,
            border:         `2px solid ${selected ? T.gold : T.cardBorder}`,
            background:     selected ? T.gold : "transparent",
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            cursor:         "pointer",
          }}
        >
          {selected && <CheckCircle size={13} color="#15120C" />}
        </button>

        {/* コンテンツ */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div
            style={{
              display:    "flex",
              gap:        6,
              flexWrap:   "wrap",
              marginBottom: 5,
              alignItems: "center",
            }}
          >
            <ProcessBadge type={s.processType} />
            <span
              style={{
                width:        6,
                height:       6,
                borderRadius: 3,
                background:   confColor,
                flexShrink:   0,
              }}
              title={`確度 ${Math.round(conf * 100)}%`}
            />
          </div>
          <div style={{ color: T.white, fontSize: 14, fontWeight: 700 }}>
            {[s.siteName, s.buildingName, s.wingName, s.floor, s.room]
              .filter(Boolean)
              .join(" ")}
          </div>
          <div style={{ color: T.whiteDim, fontSize: 13, marginTop: 1 }}>
            {s.processName}
          </div>
          <div style={{ color: T.whiteFaint, fontSize: 12, marginTop: 3 }}>
            {s.startDate} 〜 {s.endDate}
            {s.contractor && (
              <span style={{ marginLeft: 8 }}>担当: {s.contractor}</span>
            )}
          </div>
          {s.note && (
            <div style={{ color: T.whiteFaint, fontSize: 11, marginTop: 2 }}>
              {s.note}
            </div>
          )}
        </div>

        <button onClick={onEdit} style={iconBtnStyle}>
          <Edit2 size={16} color={T.whiteDim} />
        </button>
      </div>
    </div>
  );
}

// ── 工程修正モーダル ─────────────────────────────────────────
function ScheduleEditModal({ schedule, onSave, onClose }) {
  const [form, setForm] = useState({ ...schedule });
  const set = (k, v) => setForm((prev) => ({ ...prev, [k]: v }));

  const F = ({ label, field, type, placeholder }) => (
    <div style={{ marginBottom: 12 }}>
      <div
        style={{
          fontSize:     11,
          color:        T.whiteFaint,
          marginBottom: 5,
          fontWeight:   600,
        }}
      >
        {label}
      </div>
      <input
        type={type ?? "text"}
        value={form[field] ?? ""}
        onChange={(e) => set(field, e.target.value)}
        placeholder={placeholder}
        style={{
          width:        "100%",
          boxSizing:    "border-box",
          background:   T.card,
          border:       `1px solid ${T.cardBorder}`,
          borderRadius: 10,
          padding:      "11px 12px",
          color:        T.white,
          fontSize:     15,
          outline:      "none",
        }}
      />
    </div>
  );

  const saveAll = () => {
    Object.keys(form).forEach((k) => onSave(k, form[k]));
    onClose();
  };

  return (
    <Modal open title="工程を修正" onClose={onClose}>
      <F label="現場名"   field="siteName"   />
      <F label="建物名"   field="buildingName"/>
      <F label="棟名"     field="wingName"   />
      <F label="階数"     field="floor"      placeholder="例：3F" />
      <F label="部屋番号" field="room"       />
      <F label="工程名"   field="processName"/>

      {/* 工程種別ボタン群 */}
      <div style={{ marginBottom: 12 }}>
        <div
          style={{
            fontSize:     11,
            color:        T.whiteFaint,
            marginBottom: 6,
            fontWeight:   600,
          }}
        >
          工程種別
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {PROCESS_TYPES.slice(0, 14).map((pt) => {
            const c   = processColor(pt);
            const sel = form.processType === pt;
            return (
              <button
                key={pt}
                onClick={() => set("processType", pt)}
                style={{
                  padding:      "5px 10px",
                  borderRadius: 8,
                  fontSize:     12,
                  fontWeight:   600,
                  cursor:       "pointer",
                  border:       `1px solid ${sel ? c : T.cardBorder}`,
                  background:   sel ? c + "28" : "transparent",
                  color:        sel ? c : T.whiteFaint,
                }}
              >
                {pt}
              </button>
            );
          })}
        </div>
      </div>

      <F label="開始日"   field="startDate"  type="date" />
      <F label="終了日"   field="endDate"    type="date" />
      <F label="担当業者" field="contractor" />

      <PrimaryButton onClick={saveAll}>保存</PrimaryButton>
    </Modal>
  );
}
