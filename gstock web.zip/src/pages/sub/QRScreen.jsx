// src/pages/sub/QRScreen.jsx
import React, { useState, useCallback } from "react";
import { QrCode, Download } from "lucide-react";
import { T, iconBtnStyle } from "../../components/tokens.js";
import TopBar          from "../../components/TopBar.jsx";
import SearchBar       from "../../components/SearchBar.jsx";
import EmptyState      from "../../components/EmptyState.jsx";
import QRScanner       from "../../components/QRScanner.jsx";
import QRResultModal   from "../../components/QRResultModal.jsx";
import { TabButton, PrimaryButton } from "../../components/Card.jsx";
import { useInventory, useSearch, useQRHistory } from "../../hooks/useLocalDB.js";
import { qrImageUrl } from "../../utils/qr.js";

/**
 * QR スキャン / 生成画面
 * @param {Function} onBack
 */
export default function QRScreen({ onBack }) {
  const { products, adjustStock } = useInventory();
  const { addQRHistory }          = useQRHistory();

  const { query, setQuery, filtered } = useSearch(products, ["name"]);

  const [mode,           setMode]           = useState("scan"); // "scan" | "generate"
  const [scanning,       setScanning]       = useState(false);
  const [scannedProduct, setScannedProduct] = useState(null);
  const [notFound,       setNotFound]       = useState(false);

  // QR 検出ハンドラ
  const handleDetect = useCallback(
    (raw) => {
      const found = products.find((p) => p.id === raw);
      if (found) {
        setScannedProduct({ ...found });
        setNotFound(false);
        addQRHistory({ productId: found.id, type: "scan" });
      } else {
        // 登録されていない QR コードの場合
        setNotFound(true);
        setTimeout(() => setNotFound(false), 3000);
      }
      setScanning(false);
    },
    [products, addQRHistory]
  );

  // 在庫 +/- ハンドラ（スキャン結果モーダル内）
  const handleAdjust = useCallback(
    (delta) => {
      if (!scannedProduct) return;
      adjustStock(scannedProduct, delta);
      setScannedProduct((prev) =>
        prev
          ? { ...prev, arrival: Math.max(prev.used, prev.arrival + delta) }
          : prev
      );
    },
    [scannedProduct, adjustStock]
  );

  const switchMode = useCallback((m) => {
    setMode(m);
    setScanning(false);
    setScannedProduct(null);
  }, []);

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="QR" onBack={onBack} />

      {/* タブ切り替え */}
      <div style={{ display: "flex", padding: "10px 16px", gap: 8 }}>
        <TabButton
          active={mode === "scan"}
          onClick={() => switchMode("scan")}
          label="読み取り"
        />
        <TabButton
          active={mode === "generate"}
          onClick={() => switchMode("generate")}
          label="QR作成"
        />
      </div>

      {/* ── 読み取りモード ───────────────────────────────── */}
      {mode === "scan" && (
        <div style={{ padding: "0 16px" }}>
          {!scanning && !scannedProduct && (
            <div style={{ textAlign: "center", padding: "40px 20px" }}>
              <QrCode size={48} color={T.whiteFaint} />
              <div
                style={{
                  color:      T.whiteDim,
                  fontSize:   14,
                  margin:     "14px 0 20px",
                  lineHeight: 1.6,
                }}
              >
                カメラで QR コードを読み取ります
              </div>
              {/* 未検出フィードバック（3秒後に自動消去） */}
              {notFound && (
                <div style={{
                  background:   `${T.danger}18`,
                  border:       `1px solid ${T.danger}50`,
                  borderRadius: 12,
                  padding:      "10px 14px",
                  marginBottom: 16,
                  color:        T.red,
                  fontSize:     13,
                  lineHeight:   1.5,
                }}>
                  登録されていない QR コードです。<br />
                  在庫画面から商品を追加してください。
                </div>
              )}
              <PrimaryButton onClick={() => setScanning(true)}>
                カメラを起動
              </PrimaryButton>
            </div>
          )}

          {scanning && (
            <QRScanner
              onDetect={handleDetect}
              onCancel={() => setScanning(false)}
            />
          )}

          <QRResultModal
            product={scannedProduct}
            onAdjust={handleAdjust}
            onClose={() => setScannedProduct(null)}
          />
        </div>
      )}

      {/* ── QR 生成モード ────────────────────────────────── */}
      {mode === "generate" && (
        <>
          <SearchBar value={query} onChange={setQuery} placeholder="商品を検索" />

          {filtered.length === 0 ? (
            <EmptyState icon={QrCode} text="商品がありません" />
          ) : (
            <div
              style={{
                padding:       "4px 16px",
                display:       "flex",
                flexDirection: "column",
                gap:           10,
              }}
            >
              {filtered.map((p) => (
                <div
                  key={p.id}
                  style={{
                    background:   T.card,
                    border:       `1px solid ${T.cardBorder}`,
                    borderRadius: 16,
                    padding:      16,
                    display:      "flex",
                    alignItems:   "center",
                    gap:          14,
                  }}
                >
                  {/* QR 画像 */}
                  <img
                    src={qrImageUrl(p.id, 64)}
                    alt="QR"
                    width={64}
                    height={64}
                    style={{ borderRadius: 8, flexShrink: 0 }}
                  />

                  {/* 商品名 */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        color:      T.white,
                        fontSize:   15,
                        fontWeight: 700,
                      }}
                    >
                      {p.name}
                    </div>
                    <div
                      style={{
                        color:     T.whiteFaint,
                        fontSize:  12,
                        marginTop: 3,
                      }}
                    >
                      タップして保存
                    </div>
                  </div>

                  {/* ダウンロード */}
                  <a
                    href={qrImageUrl(p.id, 480)}
                    download={`${p.name}.png`}
                    style={{ ...iconBtnStyle, textDecoration: "none" }}
                    aria-label="ダウンロード"
                  >
                    <Download size={20} color={T.gold} />
                  </a>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
