// src/pages/sub/ProductsScreen.jsx
import React, { useState, useMemo, useCallback, useRef } from "react";
import { Package, Edit2, Trash2, Camera } from "lucide-react";
import { T, iconBtnStyle } from "../../components/tokens.js";
import TopBar           from "../../components/TopBar.jsx";
import SearchBar        from "../../components/SearchBar.jsx";
import FloatingButton   from "../../components/FloatingButton.jsx";
import EmptyState       from "../../components/EmptyState.jsx";
import Modal            from "../../components/Modal.jsx";
import {
  TextField,
  PrimaryButton,
  ConfirmDeleteModal,
} from "../../components/Card.jsx";
import { useInventory, useSearch } from "../../hooks/useLocalDB.js";
import { stockLevelColor }         from "../../utils/qr.js";

/**
 * 商品管理画面
 * @param {Function} navigate
 * @param {Function} onBack
 * @param {object}   params   { categoryId?: string }
 */
export default function ProductsScreen({ navigate, onBack, params }) {
  const {
    categories,
    products,
    addProduct,
    editProduct,
    deleteProduct,
  } = useInventory();

  const categoryId = params?.categoryId ?? null;
  const category   = categories.find((c) => c.id === categoryId) ?? null;

  // カテゴリでフィルタ
  const catProducts = useMemo(
    () =>
      categoryId
        ? products.filter((p) => p.categoryId === categoryId)
        : products,
    [products, categoryId]
  );

  const { query, setQuery, filtered } = useSearch(catProducts, ["name"]);
  const sorted = useMemo(
    () => [...filtered].sort((a, b) => b.createdAt - a.createdAt),
    [filtered]
  );

  const [modalOpen,    setModalOpen]    = useState(false);
  const [editing,      setEditing]      = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({
    name: "", unit: "", arrival: "0", used: "0", photo: null,
  });
  const fileRef = useRef(null);

  const openNew = useCallback(() => {
    setEditing(null);
    setForm({ name: "", unit: "", arrival: "0", used: "0", photo: null });
    setModalOpen(true);
  }, []);

  const openEdit = useCallback((p) => {
    setEditing(p);
    setForm({
      name:    p.name,
      unit:    p.unit,
      arrival: String(p.arrival),
      used:    String(p.used),
      photo:   p.photo ?? null,
    });
    setModalOpen(true);
  }, []);

  const handlePhoto = useCallback((e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert("ファイルサイズが大きすぎます（上限 5MB）");
      return;
    }
    const reader    = new FileReader();
    reader.onload   = () => setForm((f) => ({ ...f, photo: reader.result }));
    reader.onerror  = () => alert("写真の読み込みに失敗しました。");
    reader.readAsDataURL(file);
  }, []);

  const handleSave = useCallback(() => {
    if (!form.name.trim()) return;
    const data = {
      categoryId: categoryId ?? categories[0]?.id ?? null,
      name:       form.name.trim(),
      unit:       form.unit.trim() || "個",
      arrival:    Number(form.arrival) || 0,
      used:       Number(form.used)    || 0,
      photo:      form.photo,
    };
    if (editing) {
      editProduct(editing.id, data);
    } else {
      addProduct(data);
    }
    setModalOpen(false);
  }, [form, editing, categoryId, categories, editProduct, addProduct]);

  const handleDelete = useCallback(() => {
    deleteProduct(deleteTarget.id);
    setDeleteTarget(null);
  }, [deleteTarget, deleteProduct]);

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar
        title={category ? category.name : "全商品"}
        onBack={onBack}
      />
      <SearchBar value={query} onChange={setQuery} placeholder="商品を検索" />

      {sorted.length === 0 ? (
        <EmptyState
          icon={Package}
          text="商品がありません"
          sub="右下の＋から追加してください"
        />
      ) : (
        <div
          style={{
            padding:       "4px 16px",
            display:       "flex",
            flexDirection: "column",
            gap:           10,
          }}
        >
          {sorted.map((p) => {
            const stock = p.arrival - p.used;
            const color = stockLevelColor(stock, T);
            return (
              <div
                key={p.id}
                style={{
                  background:   T.card,
                  border:       `1px solid ${T.cardBorder}`,
                  borderRadius: 16,
                  padding:      "14px 16px",
                  display:      "flex",
                  alignItems:   "center",
                  gap:          12,
                }}
              >
                {/* サムネイル */}
                <div
                  style={{
                    width:          48,
                    height:         48,
                    borderRadius:   12,
                    background:     T.bgElevated,
                    display:        "flex",
                    alignItems:     "center",
                    justifyContent: "center",
                    flexShrink:     0,
                    overflow:       "hidden",
                  }}
                >
                  {p.photo ? (
                    <img
                      src={p.photo}
                      alt=""
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  ) : (
                    <Package size={20} color={T.whiteFaint} />
                  )}
                </div>

                {/* 名前・在庫（タップで編集） */}
                <div
                  style={{ flex: 1, minWidth: 0 }}
                  onClick={() => openEdit(p)}
                >
                  <div style={{ color: T.white, fontSize: 15, fontWeight: 700 }}>
                    {p.name}
                  </div>
                  <div
                    style={{ color, fontSize: 13, fontWeight: 700, marginTop: 3 }}
                  >
                    在庫 {stock} {p.unit}
                  </div>
                </div>

                <button onClick={() => openEdit(p)} style={iconBtnStyle}>
                  <Edit2 size={18} color={T.whiteDim} />
                </button>
                <button onClick={() => setDeleteTarget(p)} style={iconBtnStyle}>
                  <Trash2 size={18} color={T.danger} />
                </button>
              </div>
            );
          })}
        </div>
      )}

      <FloatingButton onClick={openNew} />

      {/* 追加 / 編集モーダル */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "商品編集" : "商品追加"}
      >
        {/* 写真 */}
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 14 }}>
          <button
            onClick={() => fileRef.current?.click()}
            style={{
              width:          84,
              height:         84,
              borderRadius:   18,
              background:     T.card,
              border:         `1px dashed ${T.cardBorder}`,
              display:        "flex",
              alignItems:     "center",
              justifyContent: "center",
              overflow:       "hidden",
              cursor:         "pointer",
            }}
          >
            {form.photo ? (
              <img
                src={form.photo}
                alt=""
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            ) : (
              <Camera size={26} color={T.whiteFaint} />
            )}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handlePhoto}
            style={{ display: "none" }}
          />
        </div>

        <TextField
          label="商品名"
          value={form.name}
          onChange={(v) => setForm((f) => ({ ...f, name: v }))}
          placeholder="例：シーリング材"
          autoFocus
        />
        <TextField
          label="単位"
          value={form.unit}
          onChange={(v) => setForm((f) => ({ ...f, unit: v }))}
          placeholder="例：本 / 缶 / kg"
        />
        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ flex: 1 }}>
            <TextField
              label="入荷数"
              type="number"
              value={form.arrival}
              onChange={(v) => setForm((f) => ({ ...f, arrival: v }))}
            />
          </div>
          <div style={{ flex: 1 }}>
            <TextField
              label="使用数"
              type="number"
              value={form.used}
              onChange={(v) => setForm((f) => ({ ...f, used: v }))}
            />
          </div>
        </div>

        <PrimaryButton onClick={handleSave} disabled={!form.name.trim()}>
          保存
        </PrimaryButton>
      </Modal>

      {/* 削除確認 */}
      <ConfirmDeleteModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        itemName={deleteTarget?.name}
      />
    </div>
  );
}
