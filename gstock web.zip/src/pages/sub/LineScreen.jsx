// src/pages/sub/LineScreen.jsx
import React, { useState, useMemo, useCallback } from "react";
import { T } from "../../components/tokens.js";
import TopBar from "../../components/TopBar.jsx";
import { PrimaryButton, GhostButton } from "../../components/Card.jsx";
import { useAttendance, useSites, periodLabel, periodKeyFor } from "../../hooks/useLocalDB.js";
import { todayStr } from "../../utils/storage.js";

/**
 * LINE 送信用テキスト生成画面
 * @param {Function} onBack
 * @param {object}   params  { periodKey?: string }
 */
export default function LineScreen({ onBack, params }) {
  const { attendance }  = useAttendance();
  const { sites }       = useSites();

  // params で指定された期間 or 今日の期間
  const today         = todayStr();
  const defaultPeriod = params?.periodKey ?? periodKeyFor(today);
  const [periodKey]   = useState(defaultPeriod);

  const [copied, setCopied] = useState(false);

  // 当期間のエントリ（日付昇順）
  const entries = useMemo(
    () =>
      attendance
        .filter((a) => a.periodKey === periodKey)
        .sort((a, b) => a.date.localeCompare(b.date)),
    [attendance, periodKey]
  );

  const siteName = useCallback(
    (id) => sites.find((s) => s.id === id)?.name ?? "現場未設定",
    [sites]
  );

  const total = useMemo(
    () => entries.reduce((sum, a) => sum + (a.value ?? 0), 0),
    [entries]
  );

  // 送信テキスト生成
  const lineText = useMemo(() => {
    const lines = [
      `【出面報告】${periodLabel(periodKey)}`,
      "",
      ...entries.map(
        (a) =>
          `${a.date}　${siteName(a.siteId)}　${a.value}人工` +
          (a.memo ? `（${a.memo}）` : "")
      ),
      "",
      `合計：${total} 人工`,
    ];
    return lines.join("\n");
  }, [entries, periodKey, total, siteName]);

  // LINE 共有
  const handleLine = useCallback(() => {
    window.open(
      `https://line.me/R/share?text=${encodeURIComponent(lineText)}`,
      "_blank"
    );
  }, [lineText]);

  // クリップボードコピー
  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(lineText);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // フォールバック（古い Safari など）
      const el = document.createElement("textarea");
      el.value = lineText;
      el.style.cssText = "position:fixed;opacity:0";
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  }, [lineText]);

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="LINE 送信" onBack={onBack} />

      <div style={{ padding: "6px 16px" }}>
        {/* 期間ラベル */}
        <div
          style={{
            color:        T.gold,
            fontSize:     13,
            fontWeight:   700,
            marginBottom: 12,
          }}
        >
          {periodLabel(periodKey)}
        </div>

        {/* プレビュー */}
        <div
          style={{
            background:   T.card,
            border:       `1px solid ${T.cardBorder}`,
            borderRadius: 16,
            padding:      16,
            whiteSpace:   "pre-wrap",
            color:        T.white,
            fontSize:     14,
            lineHeight:   1.75,
            minHeight:    160,
            fontFamily:   "inherit",
          }}
        >
          {entries.length === 0 ? (
            <span style={{ color: T.whiteFaint }}>
              この期間の出面データがありません
            </span>
          ) : (
            lineText
          )}
        </div>

        {/* アクションボタン */}
        <div
          style={{
            marginTop:     16,
            display:       "flex",
            flexDirection: "column",
            gap:           10,
          }}
        >
          <PrimaryButton onClick={handleLine} disabled={entries.length === 0}>
            📤　LINE で送信
          </PrimaryButton>
          <GhostButton onClick={handleCopy} disabled={entries.length === 0}>
            {copied ? "✓ コピーしました" : "テキストをコピー"}
          </GhostButton>
        </div>

        <p
          style={{
            color:      T.whiteFaint,
            fontSize:   12,
            marginTop:  14,
            textAlign:  "center",
            lineHeight: 1.6,
          }}
        >
          自動送信はされません。内容を確認のうえ、ご自身で送信してください。
        </p>
      </div>
    </div>
  );
}

// periodKeyFor は useLocalDB からインポートして使用
