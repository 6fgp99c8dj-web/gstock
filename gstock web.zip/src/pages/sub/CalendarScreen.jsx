// src/pages/sub/CalendarScreen.jsx
// ============================================================
// Phase 8-B — 工程管理カレンダー（閲覧専用）
//
// 【責務】
//   - db.schedules の表示・フィルタ・検索
//   - Google / Apple Calendar へのエクスポート呼び出し
//   - AI / 通知 / 編集 / 削除 / 追加 は実装しない
//
// 【依存】
//   - useDB()                          … データ取得
//   - googleCalendar.exportSchedulesToICS … Google 書き出し
//   - appleCalendar.exportToAppleCalendar … Apple 書き出し
//   - lucide-react                      … アイコン
//   - tokens.js                         … 黒×ゴールドデザイン
// ============================================================
import React, { useState, useMemo } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Search,
  Filter,
  Download,
  X,
} from "lucide-react";
import { T, iconBtnStyle, processColor } from "../../components/tokens.js";
import TopBar                            from "../../components/TopBar.jsx";
import { useDB }                         from "../../context/DBContext.jsx";
import { exportSchedulesToICS }          from "../../utils/googleCalendar.js";
import { exportToAppleCalendar }         from "../../utils/appleCalendar.js";

// ================================================================
// 定数・ユーティリティ（内部）
// ================================================================

const TODAY     = new Date().toISOString().slice(0, 10);
const WEEKDAYS  = ["日", "月", "火", "水", "木", "金", "土"];
const MONTHS    = ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"];

/**
 * YYYY-MM-DD 文字列から Date オブジェクトを生成する（ローカル時刻）
 * @param {string} dateStr
 * @returns {Date}
 */
function parseLocalDate(dateStr) {
  const [y, m, d] = String(dateStr ?? "").split("-").map(Number);
  return new Date(y, m - 1, d);
}

/**
 * Date → YYYY-MM-DD 文字列
 * @param {Date} date
 * @returns {string}
 */
function toDateStr(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/**
 * 指定月のカレンダーグリッド（6週×7日）を生成する
 * @param {number} year
 * @param {number} month  0-indexed
 * @returns {Array<Array<{date: Date, dateStr: string, inMonth: boolean}>>}
 */
function buildCalendarGrid(year, month) {
  const firstDay  = new Date(year, month, 1);
  const lastDay   = new Date(year, month + 1, 0);
  const startDow  = firstDay.getDay(); // 0=日
  const weeks     = [];
  let   current   = new Date(year, month, 1 - startDow);

  for (let w = 0; w < 6; w++) {
    const week = [];
    for (let d = 0; d < 7; d++) {
      week.push({
        date:     new Date(current),
        dateStr:  toDateStr(current),
        inMonth:  current.getMonth() === month,
      });
      current.setDate(current.getDate() + 1);
    }
    weeks.push(week);
    if (current > lastDay && w >= 4) break;
  }

  return weeks;
}

/**
 * スケジュールが指定日を含むかチェックする
 * @param {object} s
 * @param {string} dateStr
 * @returns {boolean}
 */
function scheduleIncludesDate(s, dateStr) {
  return (s.startDate ?? s.start) <= dateStr &&
         (s.endDate   ?? s.end)   >= dateStr;
}

/**
 * db.schedules の表示フィールドを正規化する
 * スキーマが { startDate, siteName, processName, contractor } でも
 * { start, site, title, worker } でも同一インターフェースで扱える
 *
 * @param {object} s  生のスケジュールオブジェクト
 * @returns {object}  正規化済みオブジェクト
 */
function normalizeSchedule(s) {
  return {
    id:          s.id,
    title:       s.processName ?? s.title ?? "",
    site:        s.siteName    ?? s.site  ?? "",
    worker:      s.contractor  ?? s.worker ?? "",
    start:       s.startDate   ?? s.start ?? "",
    end:         s.endDate     ?? s.end   ?? "",
    memo:        s.note        ?? s.memo  ?? "",
    color:       s.color       ?? processColor(s.processType),
    processType: s.processType ?? "",
    raw:         s,
  };
}

// フィルタキー定義
const PERIOD_FILTERS = [
  { key: "all",       label: "すべて"  },
  { key: "today",     label: "今日"    },
  { key: "thisweek",  label: "今週"    },
  { key: "thismonth", label: "今月"    },
];

/** 期間フィルタの日付範囲を返す */
function getPeriodRange(key) {
  const today = TODAY;
  const d     = new Date(today);

  if (key === "today") return { start: today, end: today };

  if (key === "thisweek") {
    const dow = (d.getDay() + 6) % 7; // 月=0
    const mon = new Date(d); mon.setDate(d.getDate() - dow);
    const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
    return { start: toDateStr(mon), end: toDateStr(sun) };
  }

  if (key === "thismonth") {
    return {
      start: toDateStr(new Date(d.getFullYear(), d.getMonth(), 1)),
      end:   toDateStr(new Date(d.getFullYear(), d.getMonth() + 1, 0)),
    };
  }

  return { start: "0000-01-01", end: "9999-12-31" };
}

// ================================================================
// メイン画面コンポーネント
// ================================================================

/**
 * CalendarScreen — 工程管理カレンダー（閲覧専用）
 *
 * @param {Function} [onBack]    戻るボタンのハンドラ（BottomNav 経由では不要）
 */
export default function CalendarScreen({ onBack }) {
  const { db } = useDB();

  // ── カレンダー表示月 ────────────────────────────────────────
  const [viewYear,  setViewYear]  = useState(new Date().getFullYear());
  const [viewMonth, setViewMonth] = useState(new Date().getMonth()); // 0-indexed

  // ── 選択日 ──────────────────────────────────────────────────
  const [selectedDate, setSelectedDate] = useState(TODAY);

  // ── 検索・フィルタ ──────────────────────────────────────────
  const [searchQuery,    setSearchQuery]    = useState("");
  const [showSearch,     setShowSearch]     = useState(false);
  const [periodFilter,   setPeriodFilter]   = useState("all");

  // ── スケジュール正規化 ──────────────────────────────────────
  const schedules = useMemo(
    () => (db.schedules ?? []).map(normalizeSchedule),
    [db.schedules]
  );

  // ── 期間フィルタ適用 ────────────────────────────────────────
  const periodFiltered = useMemo(() => {
    const range = getPeriodRange(periodFilter);
    return schedules.filter(
      (s) => s.start <= range.end && s.end >= range.start
    );
  }, [schedules, periodFilter]);

  // ── 検索フィルタ適用 ────────────────────────────────────────
  const searchFiltered = useMemo(() => {
    if (!searchQuery.trim()) return periodFiltered;
    const q = searchQuery.toLowerCase();
    return periodFiltered.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.site.toLowerCase().includes(q)  ||
        s.worker.toLowerCase().includes(q)
    );
  }, [periodFiltered, searchQuery]);

  // ── 選択日の予定（開始日昇順） ──────────────────────────────
  const selectedDaySchedules = useMemo(
    () =>
      searchFiltered
        .filter((s) => scheduleIncludesDate(s, selectedDate))
        .sort((a, b) => a.start.localeCompare(b.start)),
    [searchFiltered, selectedDate]
  );

  // ── 予定がある日のセット（カレンダーのドット表示用） ─────────
  const datesWithSchedules = useMemo(() => {
    const set = new Set();
    searchFiltered.forEach((s) => {
      const cur = parseLocalDate(s.start);
      const end = parseLocalDate(s.end);
      while (cur <= end) {
        set.add(toDateStr(cur));
        cur.setDate(cur.getDate() + 1);
      }
    });
    return set;
  }, [searchFiltered]);

  // ── カレンダーグリッド ──────────────────────────────────────
  const calGrid = useMemo(
    () => buildCalendarGrid(viewYear, viewMonth),
    [viewYear, viewMonth]
  );

  // ── 月移動ハンドラ ──────────────────────────────────────────
  const prevMonth = () => {
    if (viewMonth === 0) { setViewYear((y) => y - 1); setViewMonth(11); }
    else                 { setViewMonth((m) => m - 1); }
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewYear((y) => y + 1); setViewMonth(0); }
    else                  { setViewMonth((m) => m + 1); }
  };
  const goToday = () => {
    const now = new Date();
    setViewYear(now.getFullYear());
    setViewMonth(now.getMonth());
    setSelectedDate(TODAY);
  };

  // ── エクスポートハンドラ（エラーハンドリング付き） ─────────
  const handleGoogleExport = () => {
    try {
      exportSchedulesToICS(db);
    } catch (err) {
      alert(`エクスポートに失敗しました: ${err.message}`);
    }
  };
  const handleAppleExport = () => {
    try {
      exportToAppleCalendar(db);
    } catch (err) {
      alert(`エクスポートに失敗しました: ${err.message}`);
    }
  };

  // ================================================================
  // レンダリング
  // ================================================================
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100dvh", background: T.bg, overflow: "hidden" }}>

      {/* ── ヘッダー ─────────────────────────────────────────── */}
      {renderHeader({
        onBack,
        showSearch,
        setShowSearch,
        searchQuery,
        setSearchQuery,
      })}

      {/* ── スクロール領域 ───────────────────────────────────── */}
      <div style={{ flex: 1, overflowY: "auto", WebkitOverflowScrolling: "touch" }}>

        {/* カレンダー本体 */}
        {renderCalendar({
          viewYear,
          viewMonth,
          calGrid,
          selectedDate,
          setSelectedDate,
          datesWithSchedules,
          prevMonth,
          nextMonth,
          goToday,
        })}

        {/* フィルタチップ */}
        <div style={{ display: "flex", gap: 8, overflowX: "auto", padding: "8px 16px", WebkitOverflowScrolling: "touch" }}>
          {PERIOD_FILTERS.map((f) => (
            <FilterChip
              key={f.key}
              label={f.label}
              active={periodFilter === f.key}
              onClick={() => setPeriodFilter(f.key)}
            />
          ))}
        </div>

        {/* 選択日の予定一覧 */}
        {renderScheduleList({
          selectedDate,
          schedules: selectedDaySchedules,
          allFiltered: searchFiltered,
          periodFilter,
          searchQuery,
        })}

        {/* フッター（エクスポートボタン） */}
        {renderFooter({ onGoogle: handleGoogleExport, onApple: handleAppleExport })}

        {/* 余白 */}
        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

// ================================================================
// ① renderHeader
// ================================================================

/**
 * @param {{ onBack, showSearch, setShowSearch, searchQuery, setSearchQuery }} props
 */
function renderHeader({ onBack, showSearch, setShowSearch, searchQuery, setSearchQuery }) {
  return (
    <>
      <TopBar
        title="📅 工程管理"
        sub={`${new Date().getFullYear()}年${new Date().getMonth() + 1}月${new Date().getDate()}日`}
        onBack={onBack}
        right={
          <button
            onClick={() => { setShowSearch((v) => !v); setSearchQuery(""); }}
            style={iconBtnStyle}
            aria-label="検索"
          >
            <Search size={18} color={showSearch ? T.gold : T.whiteFaint} />
          </button>
        }
      />

      {/* 検索バー（展開時のみ） */}
      {showSearch && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          background: T.bgElevated, borderBottom: `1px solid ${T.cardBorder}`,
          padding: "8px 16px",
        }}>
          <Search size={16} color={T.whiteFaint} />
          <input
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="工程名・現場・担当者で検索"
            style={{
              flex: 1, background: "transparent", border: "none",
              outline: "none", color: T.white, fontSize: 14,
            }}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              style={{ ...iconBtnStyle, padding: 4, margin: -4 }}
              aria-label="クリア"
            >
              <X size={14} color={T.whiteFaint} />
            </button>
          )}
        </div>
      )}
    </>
  );
}

// ================================================================
// ② renderCalendar
// ================================================================

/**
 * @param {{ viewYear, viewMonth, calGrid, selectedDate, setSelectedDate,
 *            datesWithSchedules, prevMonth, nextMonth, goToday }} props
 */
function renderCalendar({
  viewYear, viewMonth, calGrid, selectedDate,
  setSelectedDate, datesWithSchedules, prevMonth, nextMonth, goToday,
}) {
  return (
    <div style={{
      background: T.bgElevated,
      borderBottom: `1px solid ${T.cardBorder}`,
      padding: "12px 16px 8px",
    }}>
      {/* 月ナビゲーション */}
      <div style={{
        display: "flex", alignItems: "center",
        justifyContent: "space-between", marginBottom: 12,
      }}>
        <button onClick={prevMonth} style={iconBtnStyle} aria-label="前月">
          <ChevronLeft size={22} color={T.gold} />
        </button>

        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ color: T.white, fontSize: 16, fontWeight: 700 }}>
            {viewYear}年 {MONTHS[viewMonth]}
          </span>
          <button
            onClick={goToday}
            style={{
              background: `${T.gold}18`, border: `1px solid ${T.gold}50`,
              borderRadius: 8, padding: "4px 10px",
              color: T.gold, fontSize: 11, fontWeight: 700,
              cursor: "pointer", WebkitTapHighlightColor: "transparent",
            }}
          >
            今日へ戻る
          </button>
        </div>

        <button onClick={nextMonth} style={iconBtnStyle} aria-label="翌月">
          <ChevronRight size={22} color={T.gold} />
        </button>
      </div>

      {/* 曜日ヘッダー */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", marginBottom: 4 }}>
        {WEEKDAYS.map((w, i) => (
          <div key={w} style={{
            textAlign: "center", fontSize: 11, fontWeight: 700,
            color: i === 0 ? "#E05252" : i === 6 ? T.blue : T.whiteFaint,
            paddingBottom: 4,
          }}>
            {w}
          </div>
        ))}
      </div>

      {/* 日付グリッド */}
      {calGrid.map((week, wi) => (
        <div key={wi} style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "2px 0" }}>
          {week.map(({ date, dateStr, inMonth }) => {
            const isToday    = dateStr === TODAY;
            const isSelected = dateStr === selectedDate;
            const hasSchedule = datesWithSchedules.has(dateStr);
            const dow        = date.getDay();

            return (
              <button
                key={dateStr}
                onClick={() => setSelectedDate(dateStr)}
                style={{
                  position: "relative",
                  display: "flex", flexDirection: "column",
                  alignItems: "center", justifyContent: "center",
                  height: 40, padding: "2px 0",
                  border: "none", background: "transparent",
                  cursor: "pointer", WebkitTapHighlightColor: "transparent",
                  opacity: inMonth ? 1 : 0.3,
                }}
              >
                {/* 今日のリング */}
                {isToday && !isSelected && (
                  <div style={{
                    position: "absolute",
                    width: 30, height: 30, borderRadius: 15,
                    border: `2px solid ${T.gold}`,
                    top: "50%", left: "50%",
                    transform: "translate(-50%, -50%) translateY(-3px)",
                  }} />
                )}

                {/* 選択日の背景 */}
                {isSelected && (
                  <div style={{
                    position: "absolute",
                    width: 30, height: 30, borderRadius: 15,
                    background: `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`,
                    top: "50%", left: "50%",
                    transform: "translate(-50%, -50%) translateY(-3px)",
                  }} />
                )}

                {/* 日付数字 */}
                <span style={{
                  position: "relative",
                  fontSize: 13, fontWeight: isToday || isSelected ? 800 : 400,
                  color: isSelected
                    ? "#15120C"
                    : isToday
                    ? T.gold
                    : dow === 0
                    ? "#E05252"
                    : dow === 6
                    ? T.blue
                    : T.white,
                  lineHeight: 1,
                  zIndex: 1,
                }}>
                  {date.getDate()}
                </span>

                {/* 予定ドット */}
                {hasSchedule && (
                  <span style={{
                    position: "relative",
                    width: 4, height: 4, borderRadius: 2,
                    background: isSelected ? "#15120C" : T.gold,
                    marginTop: 2, zIndex: 1,
                  }} />
                )}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}

// ================================================================
// ③ renderScheduleList
// ================================================================

/**
 * @param {{ selectedDate, schedules, allFiltered, periodFilter, searchQuery }} props
 */
function renderScheduleList({ selectedDate, schedules, allFiltered, periodFilter, searchQuery }) {
  // フィルタ・検索中は全件を表示（選択日ではなく）
  const isFiltering = periodFilter !== "all" || searchQuery.trim();
  const displayList = isFiltering ? allFiltered : schedules;
  const listTitle   = isFiltering
    ? `${displayList.length}件の工程`
    : `${selectedDate} の予定`;

  return (
    <div style={{ padding: "12px 16px 0" }}>
      {/* セクションラベル */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        marginBottom: 10,
      }}>
        <div style={{
          fontSize: 11, fontWeight: 700, color: T.whiteFaint, letterSpacing: 0.5,
        }}>
          {listTitle}
        </div>
        {isFiltering && (
          <div style={{ fontSize: 11, color: T.gold }}>
            <Filter size={10} style={{ marginRight: 3 }} />
            フィルタ中
          </div>
        )}
      </div>

      {displayList.length === 0
        ? renderEmpty()
        : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {displayList.map((s) => (
              <ScheduleCard key={s.id} schedule={s} />
            ))}
          </div>
        )
      }
    </div>
  );
}

// ================================================================
// ④ renderEmpty
// ================================================================

/** 予定なしの空表示 */
function renderEmpty() {
  return (
    <div style={{
      display: "flex", flexDirection: "column",
      alignItems: "center", padding: "36px 24px", gap: 10,
    }}>
      <CalendarDays size={34} color={T.whiteFaint} strokeWidth={1.5} />
      <div style={{ color: T.whiteDim, fontSize: 14, fontWeight: 600 }}>
        予定はありません
      </div>
      <div style={{ color: T.whiteFaint, fontSize: 12 }}>
        工程表OCRから登録してください
      </div>
    </div>
  );
}

// ================================================================
// ⑤ renderFooter
// ================================================================

/**
 * @param {{ onGoogle, onApple }} props
 */
function renderFooter({ onGoogle, onApple }) {
  return (
    <div style={{ padding: "16px 16px 0", display: "flex", flexDirection: "column", gap: 10 }}>
      {/* Google Calendar 書き出し */}
      <button
        onClick={onGoogle}
        style={_exportBtnStyle("#4285F4")}
      >
        <Download size={16} color="#fff" />
        <span>Google Calendar へ書き出し</span>
      </button>

      {/* Apple Calendar 書き出し */}
      <button
        onClick={onApple}
        style={_exportBtnStyle("#000")}
      >
        <Download size={16} color="#fff" />
        <span>Apple Calendar へ書き出し</span>
      </button>

      <p style={{
        color: T.whiteFaint, fontSize: 11, textAlign: "center",
        margin: 0, lineHeight: 1.6,
      }}>
        .ics ファイルをダウンロードします。<br />
        iPhone は「カレンダーに追加」を選択してください。
      </p>
    </div>
  );
}

// ================================================================
// 内部コンポーネント
// ================================================================

/**
 * 予定カード
 * @param {{ schedule: object }} props
 */
function ScheduleCard({ schedule: s }) {
  const color = s.color ?? T.gold;

  return (
    <div style={{
      background: T.card,
      border: `1px solid ${T.cardBorder}`,
      borderRadius: 14,
      borderLeft: `3px solid ${color}`,
      padding: "12px 14px",
    }}>
      {/* 工程名 */}
      <div style={{ color: T.white, fontSize: 15, fontWeight: 700, marginBottom: 6 }}>
        {s.title || "（工程名なし）"}
      </div>

      {/* 詳細グリッド */}
      <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
        {s.site && (
          <DetailRow label="現場" value={s.site} />
        )}
        {s.worker && (
          <DetailRow label="担当" value={s.worker} />
        )}
        {s.start && (
          <DetailRow
            label="期間"
            value={s.start === s.end ? s.start : `${s.start} 〜 ${s.end}`}
          />
        )}
        {s.memo && (
          <DetailRow label="メモ" value={s.memo} />
        )}
      </div>
    </div>
  );
}

/**
 * カード内の詳細行
 * @param {{ label: string, value: string }} props
 */
function DetailRow({ label, value }) {
  return (
    <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
      <span style={{
        fontSize: 10, fontWeight: 700, color: T.whiteFaint,
        minWidth: 28, paddingTop: 1,
      }}>
        {label}
      </span>
      <span style={{ fontSize: 12, color: T.whiteDim, flex: 1, lineHeight: 1.5 }}>
        {value}
      </span>
    </div>
  );
}

/**
 * フィルタチップ
 * @param {{ label: string, active: boolean, onClick: Function }} props
 */
function FilterChip({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "7px 14px", borderRadius: 20,
        whiteSpace: "nowrap", flexShrink: 0,
        border: `1px solid ${active ? T.gold : T.cardBorder}`,
        background: active ? `${T.gold}1F` : "transparent",
        color: active ? T.goldBright : T.whiteDim,
        fontSize: 12, fontWeight: 700,
        cursor: "pointer", WebkitTapHighlightColor: "transparent",
        transition: "all 0.15s",
      }}
    >
      {label}
    </button>
  );
}

// ── スタイルヘルパー ──────────────────────────────────────────
function _exportBtnStyle(bgColor) {
  return {
    display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
    padding: "13px 16px", borderRadius: 12, border: "none",
    background: bgColor, color: "#fff",
    fontSize: 14, fontWeight: 700,
    cursor: "pointer", WebkitTapHighlightColor: "transparent",
    width: "100%",
  };
}
