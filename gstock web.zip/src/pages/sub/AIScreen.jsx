// src/pages/sub/AIScreen.jsx
// ============================================================
// Phase 8 — AI 現場アシスタント（完成版）
// 追加: Suggestions ボタン / 検索 / お気に入り / コピー /
//       再送信 / 最下部スクロール / AIアイコンアニメーション
// 設計: useAI(db) → aiService → Provider の一方向依存を維持
//       fetch / API ロジックはゼロ
// ============================================================
import React, {
  useState, useRef, useEffect, useCallback, useMemo,
} from "react";
import {
  Send, Trash2, MapPin, Clock, Users, Package,
  Lightbulb, AlertTriangle, CheckCircle, ChevronRight,
  Bot, Search, Star, Copy, RotateCcw, ChevronDown, X,
} from "lucide-react";
import { T, iconBtnStyle } from "../../components/tokens.js";
import TopBar    from "../../components/TopBar.jsx";
import { useDB } from "../../context/DBContext.jsx";
import { useAI } from "../../hooks/useAI.js";

// ── 定数 ────────────────────────────────────────────────────
const LOW_STOCK_THRESHOLD = 5;

const QUICK_QUESTIONS = [
  { label: "乾燥時間",   text: "シーリング材の乾燥時間を教えてください" },
  { label: "必要数量",   text: "今日の施工に必要な材料数量を教えてください" },
  { label: "施工手順",   text: "シーリング施工の正しい手順を教えてください" },
  { label: "天気確認",   text: "今日の天気は施工に問題ありますか？" },
  { label: "安全注意",   text: "現場作業の安全注意事項を教えてください" },
];

const AI_SUGGESTIONS_DEFAULT = [
  { type: "warn", text: "午後から雨予報です。シーリング施工は午前中に終わらせましょう。" },
  { type: "info", text: "プライマー追加をおすすめします。現在の在庫では不足する可能性があります。" },
  { type: "ok",   text: "ウレタン系シーリング材は十分な在庫があります。" },
  { type: "info", text: "工程表では明日に足場解体が予定されています。段取りを確認してください。" },
];

// お気に入りキー（localStorage）
const FAV_KEY = "gstock_ai_favorites";

// ================================================================
// メイン画面
// ================================================================
export default function AIScreen({ onBack }) {
  const { db } = useDB();

  // ── useAI（db を渡す。context は内部で自動構築） ──────────
  const { messages, isLoading, typing, error, suggestions, send, clear, retry } = useAI(db);

  // ── 派生データ ────────────────────────────────────────────
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  const todaySchedule = useMemo(
    () => (db.schedules ?? []).find(
      (s) => s.startDate <= today && s.endDate >= today
    ) ?? null,
    [db.schedules, today]
  );

  const todaySite = useMemo(() => {
    if (!todaySchedule?.siteId) return null;
    return (db.sites ?? []).find((s) => s.id === todaySchedule.siteId) ?? null;
  }, [db.sites, todaySchedule]);

  const lowStockProducts = useMemo(
    () => (db.products ?? [])
      .filter((p) => p.arrival - p.used <= LOW_STOCK_THRESHOLD)
      .sort((a, b) => (a.arrival - a.used) - (b.arrival - b.used)),
    [db.products]
  );

  // ── UI 状態 ───────────────────────────────────────────────
  const [inputText,    setInputText]    = useState("");
  const [activeTab,    setActiveTab]    = useState("chat");   // "chat"|"check"
  const [searchMode,   setSearchMode]   = useState(false);
  const [searchQuery,  setSearchQuery]  = useState("");
  const [favorites,    setFavorites]    = useState(() => {
    try { return JSON.parse(localStorage.getItem(FAV_KEY) ?? "[]"); }
    catch { return []; }
  });
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [copiedId,     setCopiedId]     = useState(null);     // コピー完了表示

  const chatEndRef    = useRef(null);
  const chatAreaRef   = useRef(null);
  const textareaRef   = useRef(null);

  // ── 自動スクロール ────────────────────────────────────────
  useEffect(() => {
    if (!showScrollBtn) {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, typing]);

  // ── スクロールボタン表示判定 ──────────────────────────────
  const handleScroll = useCallback(() => {
    const el = chatAreaRef.current;
    if (!el) return;
    const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollBtn(distFromBottom > 120);
  }, []);

  const scrollToBottom = useCallback(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    setShowScrollBtn(false);
  }, []);

  // ── 送信 ─────────────────────────────────────────────────
  const handleSend = useCallback(async (text) => {
    const target = (text ?? inputText).trim();
    if (!target || isLoading) return;
    setInputText("");
    setActiveTab("chat");
    setSearchMode(false);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    await send(target);
  }, [inputText, isLoading, send]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleInput = useCallback((e) => {
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 96) + "px";
  }, []);

  // ── コピー ────────────────────────────────────────────────
  const handleCopy = useCallback(async (id, text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1600);
    } catch { /* ignore */ }
  }, []);

  // ── お気に入り ────────────────────────────────────────────
  const toggleFavorite = useCallback((text) => {
    setFavorites((prev) => {
      const next = prev.includes(text)
        ? prev.filter((t) => t !== text)
        : [...prev, text].slice(-10);
      try { localStorage.setItem(FAV_KEY, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  }, []);

  // ── 検索フィルタ ─────────────────────────────────────────
  const filteredMessages = useMemo(() => {
    if (!searchMode || !searchQuery.trim()) return messages;
    const q = searchQuery.toLowerCase();
    return messages.filter((m) =>
      m.text?.toLowerCase().includes(q)
    );
  }, [messages, searchMode, searchQuery]);

  return (
    <div style={{
      display: "flex", flexDirection: "column",
      height: "100dvh", background: T.bg, overflow: "hidden",
    }}>
      {/* ── TopBar ─────────────────────────────────────────── */}
      <TopBar
        title="🤖 AI現場アシスタント"
        onBack={onBack}
        right={
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            {/* 検索ボタン */}
            <button
              onClick={() => { setSearchMode((v) => !v); setSearchQuery(""); }}
              style={iconBtnStyle}
              aria-label="検索"
            >
              <Search size={18} color={searchMode ? T.gold : T.whiteFaint} />
            </button>
            {/* 履歴削除 */}
            {messages.length > 1 && (
              <button onClick={clear} style={iconBtnStyle} aria-label="履歴削除">
                <Trash2 size={18} color={T.whiteFaint} />
              </button>
            )}
          </div>
        }
      />

      {/* ── 検索バー（検索モード時のみ） ─────────────────── */}
      {searchMode && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          background: T.bgElevated, borderBottom: `1px solid ${T.cardBorder}`,
          padding: "8px 16px",
        }}>
          <Search size={16} color={T.whiteFaint} />
          <input
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="会話を検索..."
            style={{
              flex: 1, background: "transparent", border: "none",
              outline: "none", color: T.white, fontSize: 14,
            }}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} style={{ ...iconBtnStyle, padding: 4, margin: -4 }}>
              <X size={14} color={T.whiteFaint} />
            </button>
          )}
        </div>
      )}

      {/* ── スクロール領域 ─────────────────────────────────── */}
      <div
        ref={chatAreaRef}
        onScroll={handleScroll}
        style={{
          flex: 1, overflowY: "auto",
          WebkitOverflowScrolling: "touch",
          paddingBottom: 8, position: "relative",
        }}
      >
        {/* ① 今日の現場カード */}
        {!searchMode && (
          <div style={{ padding: "14px 16px 0" }}>
            <TodaySiteCard
              schedule={todaySchedule}
              site={todaySite}
              productCount={db.products?.length ?? 0}
            />
          </div>
        )}

        {/* ② タブ */}
        {!searchMode && (
          <div style={{ display: "flex", gap: 8, padding: "12px 16px 0" }}>
            <TabBtn
              active={activeTab === "chat"}
              onClick={() => setActiveTab("chat")}
              label="AI相談"
            />
            <TabBtn
              active={activeTab === "check"}
              onClick={() => setActiveTab("check")}
              label={
                lowStockProducts.length > 0
                  ? `材料チェック (${lowStockProducts.length})`
                  : "材料チェック"
              }
              warn={lowStockProducts.length > 0}
            />
          </div>
        )}

        {/* ── チャットタブ ─────────────────────────────────── */}
        {(activeTab === "chat" || searchMode) && (
          <div style={{ padding: "12px 16px 0" }}>

            {/* 会話ゼロ + 非検索 → AI 提案 + お気に入り + よく使う質問 */}
            {messages.length <= 1 && !searchMode && (
              <>
                {/* お気に入り質問 */}
                {favorites.length > 0 && (
                  <>
                    <SectionLabel icon={Star} label="お気に入り質問" color={T.gold} />
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
                      {favorites.map((fav) => (
                        <QuickBtn key={fav} label={fav.slice(0, 12)} onClick={() => handleSend(fav)} gold />
                      ))}
                    </div>
                  </>
                )}

                <SectionLabel icon={Lightbulb} label="AIからの提案" />
                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
                  {AI_SUGGESTIONS_DEFAULT.map((s, i) => (
                    <SuggestionCard key={i} type={s.type} text={s.text} />
                  ))}
                </div>

                <SectionLabel label="よく使う質問" />
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
                  {QUICK_QUESTIONS.map((q) => (
                    <QuickBtn key={q.label} label={q.label} onClick={() => handleSend(q.text)} />
                  ))}
                </div>
              </>
            )}

            {/* 会話履歴 */}
            {filteredMessages.length > 0 && (
              <>
                {searchMode && searchQuery && (
                  <div style={{ color: T.whiteFaint, fontSize: 12, marginBottom: 8 }}>
                    「{searchQuery}」の検索結果 {filteredMessages.length}件
                  </div>
                )}

                {filteredMessages.map((msg) => (
                  <ChatBubble
                    key={msg.id}
                    msg={msg}
                    isCopied={copiedId === msg.id}
                    isFavorite={favorites.includes(msg.text)}
                    onCopy={() => handleCopy(msg.id, msg.text)}
                    onResend={msg.role === "user" ? () => handleSend(msg.text) : undefined}
                    onFavorite={msg.role === "user" ? () => toggleFavorite(msg.text) : undefined}
                  />
                ))}

                {/* typing インジケーター */}
                {typing && <TypingIndicator />}

                {/* エラー + リトライ */}
                {error && !isLoading && (
                  <ErrorRow message={error} onRetry={retry} />
                )}

                {/* Suggestions ボタン（最新 AI 返答への候補） */}
                {suggestions.length > 0 && !isLoading && (
                  <SuggestionsRow suggestions={suggestions} onSelect={handleSend} />
                )}

                {/* よく使う質問（会話中も常時表示） */}
                {!searchMode && messages.length > 1 && (
                  <div style={{ marginTop: 12 }}>
                    <SectionLabel label="よく使う質問" />
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                      {QUICK_QUESTIONS.map((q) => (
                        <QuickBtn key={q.label} label={q.label} onClick={() => handleSend(q.text)} />
                      ))}
                    </div>
                  </div>
                )}

                <div ref={chatEndRef} />
              </>
            )}
          </div>
        )}

        {/* ── 材料チェックタブ ─────────────────────────────── */}
        {activeTab === "check" && !searchMode && (
          <div style={{ padding: "12px 16px 0" }}>
            {lowStockProducts.length === 0 ? (
              <AllOkCard />
            ) : (
              <>
                <SectionLabel
                  icon={AlertTriangle}
                  label={`不足・残りわずか（${lowStockProducts.length}品目）`}
                  color={T.red}
                />
                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
                  {lowStockProducts.map((p) => (
                    <LowStockCard key={p.id} product={p} />
                  ))}
                </div>
              </>
            )}

            <SectionLabel icon={Lightbulb} label="AIからの提案" />
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {AI_SUGGESTIONS_DEFAULT.map((s, i) => (
                <SuggestionCard key={i} type={s.type} text={s.text} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── 最下部スクロールボタン ───────────────────────────── */}
      {showScrollBtn && (
        <button
          onClick={scrollToBottom}
          style={{
            position: "fixed",
            right: 18,
            bottom: "calc(80px + env(safe-area-inset-bottom))",
            width: 40, height: 40, borderRadius: 20,
            background: T.bgElevated,
            border: `1px solid ${T.cardBorder}`,
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", zIndex: 20,
            boxShadow: "0 2px 8px rgba(0,0,0,0.4)",
            WebkitTapHighlightColor: "transparent",
          }}
          aria-label="最下部へスクロール"
        >
          <ChevronDown size={20} color={T.whiteDim} />
        </button>
      )}

      {/* ── 入力エリア ─────────────────────────────────────── */}
      <div style={{
        background: T.bgElevated,
        borderTop: `1px solid ${T.cardBorder}`,
        padding: "10px 16px",
        paddingBottom: "calc(10px + env(safe-area-inset-bottom))",
        flexShrink: 0,
      }}>
        <div style={{
          display: "flex", alignItems: "flex-end", gap: 10,
          background: T.card,
          border: `1px solid ${T.cardBorder}`,
          borderRadius: 16,
          padding: "8px 8px 8px 14px",
        }}>
          <textarea
            ref={textareaRef}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            onInput={handleInput}
            placeholder="現場について質問してください"
            rows={1}
            style={{
              flex: 1, background: "transparent",
              border: "none", outline: "none",
              color: T.white, fontSize: 15, lineHeight: 1.5,
              resize: "none", maxHeight: 96,
              fontFamily: "inherit", paddingTop: 4, paddingBottom: 4,
            }}
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputText.trim() || isLoading}
            aria-label="送信"
            style={{
              width: 44, height: 44, borderRadius: 12, border: "none",
              background: inputText.trim() && !isLoading
                ? `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`
                : T.cardBorder,
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: inputText.trim() && !isLoading ? "pointer" : "default",
              flexShrink: 0, transition: "background 0.18s",
              WebkitTapHighlightColor: "transparent",
            }}
          >
            <Send
              size={18}
              color={inputText.trim() && !isLoading ? "#15120C" : T.whiteFaint}
            />
          </button>
        </div>
      </div>
    </div>
  );
}

// ================================================================
// 内部コンポーネント
// ================================================================

// ── チャット吹き出し ─────────────────────────────────────────
function ChatBubble({ msg, isCopied, isFavorite, onCopy, onResend, onFavorite }) {
  const isUser = msg.role === "user";
  const [showActions, setShowActions] = useState(false);

  const timeStr = msg.createdAt
    ? new Date(msg.createdAt).toLocaleTimeString("ja-JP", {
        hour: "2-digit", minute: "2-digit",
      })
    : "";

  return (
    <div style={{
      display: "flex",
      flexDirection: isUser ? "row-reverse" : "row",
      alignItems: "flex-end",
      gap: 8,
      marginBottom: 12,
    }}>
      {/* アバター */}
      <div style={{
        width: 30, height: 30, borderRadius: 15, flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        background: isUser
          ? `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`
          : T.bgElevated,
        border: isUser ? "none" : `1px solid ${T.cardBorder}`,
        fontSize: 12, fontWeight: 700,
        color: isUser ? "#15120C" : T.gold,
        animation: !isUser && msg.id !== "__greeting__" ? "aiAppear 0.4s ease" : "none",
      }}>
        {isUser ? "私" : <BotIcon />}
      </div>

      <div style={{
        maxWidth: "74%", display: "flex",
        flexDirection: "column",
        alignItems: isUser ? "flex-end" : "flex-start",
        gap: 3,
      }}>
        {/* 吹き出し本体（長押しでアクション表示） */}
        <div
          onClick={() => setShowActions((v) => !v)}
          style={{
            background: isUser
              ? `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`
              : T.card,
            color: isUser ? "#15120C" : T.white,
            borderRadius: isUser ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
            padding: "10px 14px",
            fontSize: 14, lineHeight: 1.65,
            fontWeight: isUser ? 600 : 400,
            border: isUser ? "none" : `1px solid ${T.cardBorder}`,
            wordBreak: "break-word",
            boxShadow: isUser
              ? "0 2px 8px rgba(201,169,97,0.2)"
              : "0 2px 6px rgba(0,0,0,0.3)",
            cursor: "pointer",
            whiteSpace: "pre-wrap",
          }}
        >
          {msg.text}
        </div>

        {/* 時刻 */}
        {timeStr && (
          <div style={{ fontSize: 10, color: T.whiteFaint }}>{timeStr}</div>
        )}

        {/* アクションボタン（タップで展開） */}
        {showActions && msg.id !== "__greeting__" && (
          <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
            {/* コピー */}
            <ActionBtn
              icon={isCopied ? CheckCircle : Copy}
              label={isCopied ? "コピー済" : "コピー"}
              onClick={onCopy}
              active={isCopied}
            />
            {/* お気に入り（ユーザーの質問のみ） */}
            {onFavorite && (
              <ActionBtn
                icon={Star}
                label={isFavorite ? "お気に入り解除" : "お気に入り"}
                onClick={onFavorite}
                active={isFavorite}
              />
            )}
            {/* 再送信（ユーザーのメッセージのみ） */}
            {onResend && (
              <ActionBtn icon={RotateCcw} label="再送信" onClick={onResend} />
            )}
          </div>
        )}
      </div>

      <style>{`
        @keyframes aiAppear {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

// ── AI アイコン（アニメーション付き） ───────────────────────
function BotIcon() {
  return (
    <div style={{ animation: "botPulse 2.5s ease-in-out infinite" }}>
      <Bot size={14} color={T.gold} />
      <style>{`
        @keyframes botPulse {
          0%, 100% { transform: scale(1);    opacity: 1;   }
          50%       { transform: scale(1.15); opacity: 0.8; }
        }
      `}</style>
    </div>
  );
}

// ── アクションボタン ─────────────────────────────────────────
function ActionBtn({ icon: Icon, label, onClick, active }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      style={{
        display: "flex", alignItems: "center", gap: 4,
        padding: "4px 8px", borderRadius: 8,
        background: active ? `${T.gold}20` : T.bgElevated,
        border: `1px solid ${active ? T.gold : T.cardBorder}`,
        color: active ? T.gold : T.whiteFaint,
        fontSize: 11, cursor: "pointer",
        WebkitTapHighlightColor: "transparent",
      }}
    >
      <Icon size={11} />
      {label}
    </button>
  );
}

// ── typing インジケーター ─────────────────────────────────────
function TypingIndicator() {
  return (
    <div style={{
      display: "flex", alignItems: "flex-end", gap: 8, marginBottom: 12,
    }}>
      <div style={{
        width: 30, height: 30, borderRadius: 15,
        background: T.bgElevated, border: `1px solid ${T.cardBorder}`,
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <BotIcon />
      </div>
      <div style={{
        background: T.card, border: `1px solid ${T.cardBorder}`,
        borderRadius: "16px 16px 16px 4px",
        padding: "12px 16px",
        display: "flex", gap: 4, alignItems: "center",
      }}>
        {[0, 1, 2].map((i) => (
          <span key={i} style={{
            width: 6, height: 6, borderRadius: 3,
            background: T.gold, display: "block",
            animation: `gstock-typing 1.2s ease-in-out ${i * 0.2}s infinite`,
          }} />
        ))}
      </div>
      <style>{`
        @keyframes gstock-typing {
          0%, 100% { opacity: 0.3; transform: translateY(0);    }
          50%       { opacity: 1;   transform: translateY(-4px); }
        }
      `}</style>
    </div>
  );
}

// ── Suggestions ボタン行 ─────────────────────────────────────
function SuggestionsRow({ suggestions, onSelect }) {
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", gap: 8,
      padding: "4px 0 12px",
    }}>
      {suggestions.map((s, i) => (
        <button
          key={i}
          onClick={() => onSelect(s)}
          style={{
            padding: "8px 14px",
            background: `${T.gold}15`,
            border: `1px solid ${T.gold}50`,
            borderRadius: 20,
            color: T.goldBright,
            fontSize: 12, fontWeight: 600,
            cursor: "pointer",
            WebkitTapHighlightColor: "transparent",
            display: "flex", alignItems: "center", gap: 4,
          }}
        >
          {s}
          <ChevronRight size={11} color={T.goldDim} />
        </button>
      ))}
    </div>
  );
}

// ── エラー行 + リトライ ──────────────────────────────────────
function ErrorRow({ message, onRetry }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      background: `${T.danger}18`,
      border: `1px solid ${T.danger}50`,
      borderRadius: 12, padding: "10px 14px", marginBottom: 12,
    }}>
      <div style={{ color: T.red, fontSize: 13, flex: 1, lineHeight: 1.5 }}>
        {message}
      </div>
      <button
        onClick={onRetry}
        style={{
          background: `${T.gold}20`,
          border: `1px solid ${T.gold}50`,
          borderRadius: 10, padding: "6px 12px",
          color: T.gold, fontSize: 12, fontWeight: 700,
          cursor: "pointer",
          WebkitTapHighlightColor: "transparent",
          whiteSpace: "nowrap", flexShrink: 0,
        }}
      >
        再試行
      </button>
    </div>
  );
}

// ── 今日の現場カード ─────────────────────────────────────────
function TodaySiteCard({ schedule, site, productCount }) {
  const displayName = site?.name ?? schedule?.siteName ?? null;

  if (!displayName) {
    return (
      <div style={{
        background: T.card, border: `1px solid ${T.cardBorder}`,
        borderRadius: 16, padding: "14px 16px",
        display: "flex", alignItems: "center", gap: 10,
      }}>
        <MapPin size={16} color={T.whiteFaint} />
        <span style={{ color: T.whiteFaint, fontSize: 13 }}>
          今日の現場は登録されていません
        </span>
      </div>
    );
  }

  return (
    <div style={{
      background: T.card,
      border: `1px solid ${T.gold}50`,
      borderRadius: 16, padding: "16px 16px",
      boxShadow: `0 4px 16px rgba(201,169,97,0.08)`,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 10 }}>
        <MapPin size={12} color={T.gold} />
        <span style={{ fontSize: 11, fontWeight: 700, color: T.gold, letterSpacing: 0.5 }}>
          今日の現場
        </span>
      </div>
      <div style={{ fontSize: 17, fontWeight: 800, color: T.white, marginBottom: 12 }}>
        {displayName}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {schedule?.contractor && <SiteChip icon={Users}   label="担当"    value={schedule.contractor} />}
        {schedule?.startDate  && <SiteChip icon={Clock}   label="開始日"  value={schedule.startDate} />}
        {schedule?.endDate    && <SiteChip icon={Clock}   label="終了予定" value={schedule.endDate} />}
        <SiteChip icon={Package} label="材料数" value={`${productCount} 品目`} />
      </div>
      {site?.address && (
        <div style={{ marginTop: 10, fontSize: 11, color: T.whiteFaint }}>
          📍 {site.address}
        </div>
      )}
    </div>
  );
}

function SiteChip({ icon: Icon, label, value }) {
  return (
    <div style={{ background: T.bgElevated, borderRadius: 10, padding: "8px 10px" }}>
      <div style={{ fontSize: 10, color: T.whiteFaint, marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 13, fontWeight: 700, color: T.white, display: "flex", alignItems: "center", gap: 4 }}>
        <Icon size={11} color={T.whiteDim} />
        {value}
      </div>
    </div>
  );
}

// ── 不足材料カード ───────────────────────────────────────────
function LowStockCard({ product }) {
  const stock   = product.arrival - product.used;
  const isEmpty = stock <= 0;
  return (
    <div style={{
      background:   isEmpty ? `${T.danger}18` : `${T.gold}10`,
      border:       `1px solid ${isEmpty ? T.danger : T.gold}50`,
      borderRadius: 14, padding: "12px 14px",
      display: "flex", alignItems: "center", gap: 12,
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: isEmpty ? `${T.danger}25` : `${T.gold}20`,
        display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
      }}>
        {isEmpty
          ? <AlertTriangle size={18} color={T.red} />
          : <Package       size={18} color={T.gold} />
        }
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ color: T.white, fontSize: 14, fontWeight: 700 }}>{product.name}</div>
        <div style={{ fontSize: 12, fontWeight: 700, color: isEmpty ? T.red : T.gold, marginTop: 2 }}>
          残り {stock} {product.unit}{isEmpty && "　⚠ 在庫なし"}
        </div>
      </div>
    </div>
  );
}

// ── 在庫 OK カード ───────────────────────────────────────────
function AllOkCard() {
  return (
    <div style={{
      background: `${T.green}12`, border: `1px solid ${T.green}40`,
      borderRadius: 16, padding: "20px 16px",
      textAlign: "center", marginBottom: 16,
    }}>
      <CheckCircle size={28} color={T.green} style={{ marginBottom: 8 }} />
      <div style={{ color: T.white, fontSize: 15, fontWeight: 700, marginBottom: 4 }}>
        材料は問題ありません
      </div>
      <div style={{ color: T.whiteFaint, fontSize: 12 }}>
        不足している材料は現在ありません
      </div>
    </div>
  );
}

// ── AI 提案カード ────────────────────────────────────────────
function SuggestionCard({ type, text }) {
  const cfg = {
    warn: { color: T.gold,  bg: `${T.gold}10`,  border: `${T.gold}40`,  Icon: AlertTriangle },
    info: { color: T.blue,  bg: `${T.blue}10`,  border: `${T.blue}40`,  Icon: Lightbulb     },
    ok:   { color: T.green, bg: `${T.green}10`, border: `${T.green}40`, Icon: CheckCircle   },
  }[type] ?? { color: T.gold, bg: `${T.gold}10`, border: `${T.gold}40`, Icon: Lightbulb };
  const { color, bg, border, Icon } = cfg;

  return (
    <div style={{
      background: bg, border: `1px solid ${border}`,
      borderRadius: 14, padding: "12px 14px",
      display: "flex", alignItems: "flex-start", gap: 10,
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 10,
        background: color + "20",
        display: "flex", alignItems: "center", justifyContent: "center",
        flexShrink: 0, marginTop: 1,
      }}>
        <Icon size={16} color={color} />
      </div>
      <div style={{ color: T.white, fontSize: 13, lineHeight: 1.65, flex: 1 }}>{text}</div>
    </div>
  );
}

// ── よく使う質問ボタン ───────────────────────────────────────
function QuickBtn({ label, onClick, gold }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "9px 14px",
        background: gold ? `${T.gold}15` : T.card,
        border: `1px solid ${gold ? T.gold : T.cardBorder}`,
        borderRadius: 20,
        color: gold ? T.goldBright : T.whiteDim,
        fontSize: 13, fontWeight: 600,
        cursor: "pointer",
        WebkitTapHighlightColor: "transparent",
        display: "flex", alignItems: "center", gap: 4,
        whiteSpace: "nowrap",
      }}
    >
      {label}
      <ChevronRight size={12} color={gold ? T.goldDim : T.whiteFaint} />
    </button>
  );
}

// ── タブボタン ───────────────────────────────────────────────
function TabBtn({ active, onClick, label, warn }) {
  return (
    <button
      onClick={onClick}
      style={{
        flex: 1, padding: "10px 0", borderRadius: 12,
        border: `1px solid ${active ? (warn ? T.red : T.gold) : T.cardBorder}`,
        background: active ? (warn ? `${T.danger}15` : `${T.gold}1A`) : "transparent",
        color: active ? (warn ? T.red : T.goldBright) : T.whiteDim,
        fontSize: 13, fontWeight: 700,
        cursor: "pointer",
        WebkitTapHighlightColor: "transparent",
        transition: "all 0.15s",
      }}
    >
      {label}
    </button>
  );
}

// ── セクションラベル ─────────────────────────────────────────
function SectionLabel({ icon: Icon, label, color }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 5,
      marginBottom: 8, marginTop: 4,
    }}>
      {Icon && <Icon size={13} color={color ?? T.whiteFaint} />}
      <span style={{
        fontSize: 11, fontWeight: 700,
        color: color ?? T.whiteFaint,
        letterSpacing: 0.5,
      }}>
        {label}
      </span>
    </div>
  );
}
