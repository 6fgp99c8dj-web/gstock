// src/pages/sub/ScheduleScreen.jsx
import React, { useState, useMemo, useCallback } from "react";
import { Calendar, Trash2 } from "lucide-react";
import { T, iconBtnStyle } from "../../components/tokens.js";
import TopBar     from "../../components/TopBar.jsx";
import SearchBar  from "../../components/SearchBar.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import Modal      from "../../components/Modal.jsx";
import {
  CatChip,
  ProcessBadge,
  GhostButton,
  ConfirmDeleteModal,
} from "../../components/Card.jsx";
import { useSchedules }     from "../../hooks/useLocalDB.js";
import { useSearch }        from "../../hooks/useLocalDB.js";
import { todayStr }         from "../../utils/storage.js";

// 期間フィルタ定義
const PERIOD_FILTERS = [
  { key: "today",     label: "今日"  },
  { key: "tomorrow",  label: "明日"  },
  { key: "thisweek",  label: "今週"  },
  { key: "nextweek",  label: "来週"  },
  { key: "thismonth", label: "今月"  },
  { key: "all",       label: "全て"  },
];

function getRange(key) {
  const today = todayStr();
  const d     = new Date();

  switch (key) {
    case "today":
      return { start: today, end: today };

    case "tomorrow": {
      const tm = new Date(d);
      tm.setDate(tm.getDate() + 1);
      const s = tm.toISOString().slice(0, 10);
      return { start: s, end: s };
    }

    case "thisweek": {
      const dow   = (d.getDay() + 6) % 7;
      const mon   = new Date(d);
      mon.setDate(d.getDate() - dow);
      const sun   = new Date(mon);
      sun.setDate(mon.getDate() + 6);
      return {
        start: mon.toISOString().slice(0, 10),
        end:   sun.toISOString().slice(0, 10),
      };
    }

    case "nextweek": {
      const dow   = (d.getDay() + 6) % 7;
      const mon   = new Date(d);
      mon.setDate(d.getDate() - dow + 7);
      const sun   = new Date(mon);
      sun.setDate(mon.getDate() + 6);
      return {
        start: mon.toISOString().slice(0, 10),
        end:   sun.toISOString().slice(0, 10),
      };
    }

    case "thismonth": {
      const y = d.getFullYear();
      const m = d.getMonth();
      return {
        start: new Date(y, m,     1).toISOString().slice(0, 10),
        end:   new Date(y, m + 1, 0).toISOString().slice(0, 10),
      };
    }

    default:
      return { start: "0000-01-01", end: "9999-12-31" };
  }
}

/**
 * スケジュール（工程カレンダー）一覧画面
 * @param {Function} navigate
 * @param {Function} onBack
 */
export default function ScheduleScreen({ navigate, onBack }) {
  const { schedules, deleteSchedule } = useSchedules();

  const { query, setQuery, filtered } = useSearch(schedules, [
    "siteName", "processName", "floor",
  ]);

  const [periodFilter,   setPeriodFilter]   = useState("today");
  const [processFilter,  setProcessFilter]  = useState("all");
  const [detailTarget,   setDetailTarget]   = useState(null);
  const [deleteTarget,   setDeleteTarget]   = useState(null);

  const today = todayStr();

  // 期間 + 工程種別 + 検索フィルタ
  const displayList = useMemo(() => {
    const range = getRange(periodFilter);
    let list = filtered.filter(
      (s) => s.startDate <= range.end && s.endDate >= range.start
    );
    if (processFilter !== "all") {
      list = list.filter((s) => s.processType === processFilter);
    }
    return [...list].sort((a, b) => a.startDate.localeCompare(b.startDate));
  }, [filtered, periodFilter, processFilter]);

  // 工程種別チップ（重複なし）
  const processTypes = useMemo(() => {
    const set = new Set(schedules.map((s) => s.processType).filter(Boolean));
    return ["all", ...set];
  }, [schedules]);

  const handleDelete = useCallback(() => {
    deleteSchedule(deleteTarget.id);
    setDeleteTarget(null);
  }, [deleteTarget, deleteSchedule]);

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="スケジュール" onBack={onBack} />
      <SearchBar value={query} onChange={setQuery} placeholder="現場名・工程名で検索" />

      {/* 期間フィルタ */}
      <div
        style={{
          display:    "flex",
          gap:        6,
          overflowX:  "auto",
          padding:    "0 16px 8px",
          WebkitOverflowScrolling: "touch",
        }}
      >
        {PERIOD_FILTERS.map((f) => (
          <CatChip
            key={f.key}
            active={periodFilter === f.key}
            onClick={() => setPeriodFilter(f.key)}
            label={f.label}
          />
        ))}
      </div>

      {/* 工程種別フィルタ */}
      <div
        style={{
          display:    "flex",
          gap:        6,
          overflowX:  "auto",
          padding:    "0 16px 10px",
          WebkitOverflowScrolling: "touch",
        }}
      >
        {processTypes.map((pt) => (
          <CatChip
            key={pt}
            active={processFilter === pt}
            onClick={() => setProcessFilter(pt)}
            label={pt === "all" ? "全種別" : pt}
          />
        ))}
      </div>

      {/* スケジュール一覧 */}
      {displayList.length === 0 ? (
        <EmptyState
          icon={Calendar}
          text="スケジュールがありません"
          sub="工程表 OCR から登録してください"
        />
      ) : (
        <div
          style={{
            padding:       "0 16px",
            display:       "flex",
            flexDirection: "column",
            gap:           10,
          }}
        >
          {displayList.map((s) => {
            const isToday =
              s.startDate <= today && s.endDate >= today;
            const isPast  = s.endDate < today;
            const days    =
              Math.round(
                (new Date(s.endDate) - new Date(s.startDate)) / 86400000
              ) + 1;

            return (
              <div
                key={s.id}
                style={{
                  background:   T.card,
                  border:       `1px solid ${isToday ? T.gold : T.cardBorder}`,
                  borderRadius: 16,
                  padding:      "14px 14px",
                  opacity:      isPast ? 0.6 : 1,
                }}
              >
                <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                  <div
                    style={{ flex: 1, minWidth: 0 }}
                    onClick={() => setDetailTarget(s)}
                  >
                    {/* バッジ行 */}
                    <div
                      style={{
                        display:      "flex",
                        gap:          6,
                        marginBottom: 6,
                        flexWrap:     "wrap",
                        alignItems:   "center",
                      }}
                    >
                      <ProcessBadge type={s.processType} />
                      {isToday && (
                        <span
                          style={{
                            fontSize:     10,
                            fontWeight:   800,
                            color:        T.goldBright,
                            background:   `${T.gold}25`,
                            borderRadius: 6,
                            padding:      "2px 6px",
                          }}
                        >
                          今日
                        </span>
                      )}
                      {isPast && (
                        <span style={{ fontSize: 10, color: T.whiteFaint }}>
                          完了
                        </span>
                      )}
                    </div>

                    {/* 現場名 */}
                    <div style={{ color: T.white, fontSize: 15, fontWeight: 700 }}>
                      {[s.siteName, s.buildingName, s.wingName, s.floor, s.room]
                        .filter(Boolean)
                        .join(" ")}
                    </div>
                    <div style={{ color: T.whiteDim, fontSize: 13, marginTop: 2 }}>
                      {s.processName}
                    </div>
                    <div style={{ color: T.whiteFaint, fontSize: 12, marginTop: 4 }}>
                      {s.startDate} 〜 {s.endDate}
                      <span style={{ marginLeft: 8 }}>{days}日間</span>
                      {s.contractor && (
                        <span style={{ marginLeft: 8 }}>| {s.contractor}</span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => setDeleteTarget(s)}
                    style={iconBtnStyle}
                  >
                    <Trash2 size={16} color={T.danger} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 詳細モーダル */}
      <Modal
        open={!!detailTarget}
        onClose={() => setDetailTarget(null)}
        title="工程詳細"
      >
        {detailTarget && <ScheduleDetail s={detailTarget} />}
      </Modal>

      {/* 削除確認 */}
      <ConfirmDeleteModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        itemName={detailTarget?.siteName ?? deleteTarget?.siteName}
      />
    </div>
  );
}

// ── 詳細コンテンツ ────────────────────────────────────────────
function ScheduleDetail({ s }) {
  const rows = [
    ["工事名",   s.projectName],
    ["現場名",   s.siteName],
    ["建物",     s.buildingName],
    ["棟",       s.wingName],
    ["階数",     s.floor],
    ["部屋",     s.room],
    ["工程名",   s.processName],
    ["工程種別", s.processType],
    ["開始日",   s.startDate],
    ["終了日",   s.endDate],
    ["担当",     s.contractor],
    ["備考",     s.note],
  ].filter(([, v]) => v);

  return (
    <div>
      {rows.map(([k, v]) => (
        <div
          key={k}
          style={{
            display:      "flex",
            padding:      "8px 0",
            borderBottom: `1px solid ${T.cardBorder}`,
          }}
        >
          <div style={{ width: 70, color: T.whiteFaint, fontSize: 12, flexShrink: 0 }}>
            {k}
          </div>
          <div style={{ color: T.white, fontSize: 14, flex: 1 }}>{v}</div>
        </div>
      ))}
    </div>
  );
}
