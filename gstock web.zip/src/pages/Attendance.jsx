// src/pages/Attendance.jsx
import React, { useState, useMemo, useCallback } from "react";
import { Users, Trash2 } from "lucide-react";
import { T, iconBtnStyle } from "../components/tokens.js";
import TopBar  from "../components/TopBar.jsx";
import EmptyState from "../components/EmptyState.jsx";
import {
  TabButton,
  TextField,
  TextArea,
  PrimaryButton,
  GhostButton,
} from "../components/Card.jsx";
import {
  useAttendance,
  useSites,
  periodKeyFor,
  periodLabel,
} from "../hooks/useLocalDB.js";
import { todayStr } from "../utils/storage.js";

/**
 * 出面管理画面（21日〜20日締め）
 * @param {Function} navigate
 */
export default function Attendance({ navigate }) {
  const { attendance, addEntry, deleteEntry } = useAttendance();
  const { sites } = useSites();

  const today         = todayStr();
  const [date,   setDate]   = useState(today);
  const [siteId, setSiteId] = useState(sites[0]?.id ?? "");
  const [value,  setValue]  = useState("1");
  const [memo,   setMemo]   = useState("");
  const [tab,    setTab]    = useState("input"); // "input" | "list"

  // 現在の期間キー（date に連動）
  const currentPeriod = useMemo(() => periodKeyFor(date), [date]);

  // 当期間の出面エントリ（新しい順）
  const periodEntries = useMemo(
    () =>
      attendance
        .filter((a) => a.periodKey === currentPeriod)
        .sort((a, b) => b.date.localeCompare(a.date)),
    [attendance, currentPeriod]
  );

  // 合計
  const total = useMemo(
    () => periodEntries.reduce((sum, a) => sum + (a.value ?? 0), 0),
    [periodEntries]
  );

  // 現場別集計
  const bySite = useMemo(() => {
    const map = {};
    periodEntries.forEach((a) => {
      map[a.siteId] = (map[a.siteId] ?? 0) + (a.value ?? 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [periodEntries]);

  const siteName = useCallback(
    (id) => sites.find((s) => s.id === id)?.name ?? "現場未設定",
    [sites]
  );

  const handleSave = useCallback(() => {
    if (!siteId) return;
    addEntry({
      periodKey: currentPeriod,
      date,
      siteId,
      value: Number(value) || 0,
      memo:  memo.trim(),
    });
    setMemo("");
    setTab("list");
  }, [siteId, currentPeriod, date, value, memo, addEntry]);

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="出面" />

      {/* 期間表示 */}
      <div style={{ padding: "6px 16px 4px" }}>
        <div style={{ color: T.gold, fontSize: 13, fontWeight: 700 }}>
          {periodLabel(currentPeriod)}
        </div>
      </div>

      {/* タブ切り替え */}
      <div style={{ display: "flex", padding: "10px 16px", gap: 8 }}>
        <TabButton
          active={tab === "input"}
          onClick={() => setTab("input")}
          label="入力"
        />
        <TabButton
          active={tab === "list"}
          onClick={() => setTab("list")}
          label="一覧・集計"
        />
      </div>

      {/* 入力タブ */}
      {tab === "input" && (
        <div style={{ padding: "0 16px" }}>
          <TextField
            label="日付"
            type="date"
            value={date}
            onChange={setDate}
          />

          {/* 現場セレクト */}
          <div style={{ marginBottom: 14 }}>
            <div
              style={{
                fontSize:     12,
                color:        T.whiteFaint,
                marginBottom: 6,
                fontWeight:   600,
              }}
            >
              現場
            </div>
            {sites.length === 0 ? (
              <div style={{ color: T.whiteFaint, fontSize: 13 }}>
                先に現場を登録してください
              </div>
            ) : (
              <select
                value={siteId}
                onChange={(e) => setSiteId(e.target.value)}
                style={{
                  width:        "100%",
                  boxSizing:    "border-box",
                  background:   T.card,
                  border:       `1px solid ${T.cardBorder}`,
                  borderRadius: 12,
                  padding:      "13px 14px",
                  color:        T.white,
                  fontSize:     16,
                  outline:      "none",
                }}
              >
                {sites.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            )}
          </div>

          <TextField
            label="出面（人工）"
            type="number"
            value={value}
            onChange={setValue}
          />
          <TextArea
            label="メモ"
            value={memo}
            onChange={setMemo}
            placeholder="任意"
            rows={2}
          />

          <PrimaryButton onClick={handleSave} disabled={!siteId}>
            保存
          </PrimaryButton>
        </div>
      )}

      {/* 一覧・集計タブ */}
      {tab === "list" && (
        <div style={{ padding: "0 16px" }}>
          {/* サマリーカード */}
          <div
            style={{
              background:   T.card,
              border:       `1px solid ${T.cardBorder}`,
              borderRadius: 16,
              padding:      16,
              marginBottom: 14,
            }}
          >
            <div
              style={{
                display:        "flex",
                justifyContent: "space-between",
                alignItems:     "baseline",
              }}
            >
              <span style={{ color: T.whiteDim, fontSize: 13 }}>合計出面</span>
              <span
                style={{
                  color:      T.goldBright,
                  fontSize:   26,
                  fontWeight: 800,
                }}
              >
                {total} 人工
              </span>
            </div>

            {/* 現場別内訳 */}
            {bySite.length > 0 && (
              <div
                style={{
                  marginTop:  12,
                  borderTop:  `1px solid ${T.cardBorder}`,
                  paddingTop: 10,
                }}
              >
                {bySite.map(([sid, v]) => (
                  <div
                    key={sid}
                    style={{
                      display:        "flex",
                      justifyContent: "space-between",
                      padding:        "4px 0",
                    }}
                  >
                    <span style={{ color: T.whiteDim, fontSize: 13 }}>
                      {siteName(sid)}
                    </span>
                    <span
                      style={{
                        color:      T.white,
                        fontSize:   13,
                        fontWeight: 700,
                      }}
                    >
                      {v} 人工
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* エントリ一覧 */}
          {periodEntries.length === 0 ? (
            <EmptyState
              icon={Users}
              text="この期間の出面はまだありません"
            />
          ) : (
            <div
              style={{
                display:       "flex",
                flexDirection: "column",
                gap:           8,
              }}
            >
              {periodEntries.map((a) => (
                <div
                  key={a.id}
                  style={{
                    background:   T.card,
                    border:       `1px solid ${T.cardBorder}`,
                    borderRadius: 14,
                    padding:      "12px 14px",
                    display:      "flex",
                    alignItems:   "center",
                    gap:          10,
                  }}
                >
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        color:      T.white,
                        fontSize:   14,
                        fontWeight: 700,
                      }}
                    >
                      {a.date}　{siteName(a.siteId)}
                    </div>
                    {a.memo && (
                      <div
                        style={{
                          color:     T.whiteFaint,
                          fontSize:  12,
                          marginTop: 2,
                        }}
                      >
                        {a.memo}
                      </div>
                    )}
                  </div>
                  <div
                    style={{
                      color:      T.goldBright,
                      fontSize:   15,
                      fontWeight: 800,
                      flexShrink: 0,
                    }}
                  >
                    {a.value}
                  </div>
                  <button
                    onClick={() => deleteEntry(a.id)}
                    style={iconBtnStyle}
                  >
                    <Trash2 size={16} color={T.danger} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* LINE 送信ボタン */}
          <div style={{ marginTop: 16 }}>
            <PrimaryButton
              onClick={() => navigate("line", { periodKey: currentPeriod })}
            >
              LINE送信用データを作成
            </PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
}
