// src/pages/Inventory.jsx
import React, { useState, useMemo, useCallback } from "react";
import { Package, Edit2 } from "lucide-react";
import { T, iconBtnStyle } from "../components/tokens.js";
import TopBar         from "../components/TopBar.jsx";
import SearchBar      from "../components/SearchBar.jsx";
import FloatingButton from "../components/FloatingButton.jsx";
import EmptyState     from "../components/EmptyState.jsx";
import NumericPad     from "../components/NumericPad.jsx";
import {
  CatChip,
  PrimaryButton,
  GhostButton,
  TextField,
} from "../components/Card.jsx";
import { useInventory, useSearch, useLongPress } from "../hooks/useLocalDB.js";
import { stockLevelColor } from "../utils/qr.js";
import { Minus, Plus } from "lucide-react";

/**
 * 在庫一覧画面
 * @param {Function} navigate
 */
export default function Inventory({ navigate }) {
  const {
    categories,
    products,
    adjustStock,
    setStockDirect,
  } = useInventory();

  const { query, setQuery, filtered } = useSearch(products, ["name"]);
  const [activeCat,    setActiveCat]    = useState("all");
  const [numpadTarget, setNumpadTarget] = useState(null);

  // カテゴリ + 検索フィルタ + お気に入り優先ソート
  const displayList = useMemo(() => {
    let list = filtered;
    if (activeCat !== "all") {
      list = list.filter((p) => p.categoryId === activeCat);
    }
    return [...list].sort(
      (a, b) =>
        (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0) ||
        b.createdAt - a.createdAt
    );
  }, [filtered, activeCat]);

  const catName = useCallback(
    (id) => categories.find((c) => c.id === id)?.name ?? "未分類",
    [categories]
  );

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar
        title="在庫"
        right={
          <button
            onClick={() => navigate("categories")}
            style={iconBtnStyle}
            aria-label="カテゴリ管理"
          >
            <Edit2 size={18} color={T.gold} />
          </button>
        }
      />

      <SearchBar value={query} onChange={setQuery} placeholder="商品を検索" />

      {/* カテゴリチップ */}
      <div
        style={{
          display:    "flex",
          gap:        8,
          overflowX:  "auto",
          padding:    "0 16px 10px",
          WebkitOverflowScrolling: "touch",
        }}
      >
        <CatChip
          active={activeCat === "all"}
          onClick={() => setActiveCat("all")}
          label="すべて"
        />
        {categories.map((c) => (
          <CatChip
            key={c.id}
            active={activeCat === c.id}
            onClick={() => setActiveCat(c.id)}
            label={c.name}
          />
        ))}
      </div>

      {/* 商品リスト */}
      {displayList.length === 0 ? (
        <EmptyState
          icon={Package}
          text="商品がありません"
          sub="カテゴリ画面から商品を追加してください"
        />
      ) : (
        <div
          style={{
            padding:       "4px 16px",
            display:       "flex",
            flexDirection: "column",
            gap:           10,
          }}
        >
          {displayList.map((p) => (
            <ProductRow
              key={p.id}
              product={p}
              catName={catName(p.categoryId)}
              onAdjust={(delta) => adjustStock(p, delta)}
              onNumpad={() => setNumpadTarget(p)}
            />
          ))}
        </div>
      )}

      <FloatingButton onClick={() => navigate("categories")} />

      <NumericPad
        target={numpadTarget}
        onSave={setStockDirect}
        onClose={() => setNumpadTarget(null)}
      />
    </div>
  );
}

// ── 商品行コンポーネント ─────────────────────────────────────
function ProductRow({ product: p, catName, onAdjust, onNumpad }) {
  const stock = p.arrival - p.used;
  const color = stockLevelColor(stock, T);

  const decHandlers = useLongPress(useCallback(() => onAdjust(-1), [onAdjust]));
  const incHandlers = useLongPress(useCallback(() => onAdjust(+1), [onAdjust]));

  return (
    <div
      style={{
        background:   T.card,
        border:       `1px solid ${T.cardBorder}`,
        borderRadius: 16,
        padding:      "14px 16px",
      }}
    >
      {/* 上段：サムネイル / 名前 / 在庫数 */}
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        {/* サムネイル */}
        <div
          style={{
            width:          44,
            height:         44,
            borderRadius:   11,
            background:     T.bgElevated,
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            flexShrink:     0,
            overflow:       "hidden",
          }}
        >
          {p.photo ? (
            <img
              src={p.photo}
              alt=""
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            <Package size={18} color={T.whiteFaint} />
          )}
        </div>

        {/* 名前 / カテゴリ */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: T.white, fontSize: 15, fontWeight: 700 }}>
            {p.name}
          </div>
          <div style={{ color: T.whiteFaint, fontSize: 11, marginTop: 1 }}>
            {catName}
          </div>
        </div>

        {/* 在庫数（タップでテンキー） */}
        <button
          onClick={onNumpad}
          style={{
            background:              "none",
            border:                  "none",
            cursor:                  "pointer",
            WebkitTapHighlightColor: "transparent",
            flexShrink:              0,
          }}
        >
          <span style={{ color, fontSize: 22, fontWeight: 800 }}>{stock}</span>
          <span style={{ color: T.whiteFaint, fontSize: 12, marginLeft: 3 }}>
            {p.unit}
          </span>
        </button>
      </div>

      {/* 下段：+/- ボタン */}
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <StepButton icon={Minus} handlers={decHandlers} />
        <div style={{ flex: 1 }} />
        <StepButton icon={Plus} handlers={incHandlers} gold />
      </div>
    </div>
  );
}

// ── 長押し対応ステップボタン ─────────────────────────────────
function StepButton({ icon: Icon, handlers, gold }) {
  return (
    <button
      {...handlers}
      style={{
        width:                   52,
        height:                  44,
        borderRadius:            12,
        border:                  gold ? "none" : `1px solid ${T.cardBorder}`,
        background:              gold
          ? `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`
          : T.bgElevated,
        display:                 "flex",
        alignItems:              "center",
        justifyContent:          "center",
        cursor:                  "pointer",
        WebkitTapHighlightColor: "transparent",
        touchAction:             "manipulation",
      }}
    >
      <Icon
        size={20}
        color={gold ? "#15120C" : T.white}
        strokeWidth={2.6}
      />
    </button>
  );
}
