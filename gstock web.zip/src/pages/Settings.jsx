// src/pages/Settings.jsx
// ============================================================
// 設定画面 — Phase 8-B 完成版
//
// 追加セクション:
//   ① AI Provider 切替（setProvider / getProvider）
//   ② 通知設定 ON/OFF（db.settings へ永続化）
//   ③ カレンダー連携設定
//   ④ アプリ情報
//
// 既存セクションはそのまま維持:
//   - 業者名 / OCRフィルタ
//   - データ管理（CSV / JSON）
//   - AI 学習データ
//   - 詳細プロフィール設定
// ============================================================
import React, { useState, useRef, useCallback } from "react";
import { T, iconBtnStyle } from "../components/tokens.js";
import TopBar from "../components/TopBar.jsx";
import {
  TextField,
  PrimaryButton,
  GhostButton,
} from "../components/Card.jsx";
import { useDB }            from "../context/DBContext.jsx";
import {
  exportInventoryCSV,
  exportJSON,
  importJSON,
}                           from "../utils/storage.js";
import {
  getProvider,
  setProvider,
  listProviders,
  AI_PROVIDER,
}                           from "../services/aiService.js";

// AI Provider の表示ラベル
const PROVIDER_LABELS = {
  [AI_PROVIDER.MOCK]:   "Mock（テスト用）",
  [AI_PROVIDER.OPENAI]: "OpenAI (GPT-4o)",
  [AI_PROVIDER.GEMINI]: "Google Gemini",
  [AI_PROVIDER.CLAUDE]: "Anthropic Claude",
};

// 通知設定のデフォルト値
const DEFAULT_SETTINGS = {
  notifyEnabled:        false,
  notifyDayBefore:      true,
  notifyMorning:        true,
  notifyLowStock:       true,
  notifyScheduleChange: true,
  syncGoogleCalendar:   false,
  syncAppleCalendar:    false,
};

/**
 * 設定画面
 * @param {Function} navigate
 */
export default function Settings({ navigate }) {
  const { db, update, setDB } = useDB();

  // ── 業者名フォーム状態 ──────────────────────────────────────
  const [companyName,   setCompanyName]   = useState(db.userProfile?.companyName ?? "");
  const [aliases,       setAliases]       = useState(
    (db.userProfile?.contractorAliases ?? []).join("、")
  );
  const [profileSaved,  setProfileSaved]  = useState(false);

  // ── インポート状態 ──────────────────────────────────────────
  const [importError,   setImportError]   = useState("");
  const [importSuccess, setImportSuccess] = useState(false);
  const importRef = useRef(null);

  // ── AI Provider 状態
  // 起動時: db.settings.aiProvider → setProvider() で復元してから表示
  const [currentProvider, setCurrentProvider] = useState(() => {
    const saved = db.settings?.aiProvider;
    if (saved && saved !== getProvider()) {
      try { setProvider(saved); } catch { /* 無効なキーは無視 */ }
    }
    return getProvider();
  });

  // ── 通知 / カレンダー設定（db.settings から取得） ──────────
  const settings = { ...DEFAULT_SETTINGS, ...(db.settings ?? {}) };

  // ================================================================
  // ハンドラ
  // ================================================================

  /** 業者名を保存する */
  const handleSaveProfile = useCallback(() => {
    const aliasList = aliases
      .split(/[、,，\s]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    update((prev) => ({
      userProfile: {
        ...prev.userProfile,
        companyName:       companyName.trim(),
        contractorAliases: aliasList,
      },
    }));
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 1800);
  }, [companyName, aliases, update]);

  /** JSON インポート */
  const handleImport = useCallback(async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError("");
    setImportSuccess(false);
    try {
      const newDB = await importJSON(file);
      setDB(newDB);
      setImportSuccess(true);
    } catch (err) {
      setImportError(err.message);
    }
    e.target.value = "";
  }, [setDB]);

  /** AI 学習データリセット */
  const handleResetLearning = useCallback(() => {
    if (!window.confirm("AI学習データをリセットしますか？")) return;
    update({ ocrLearning: [] });
  }, [update]);

  /** AI Provider を切り替えて localStorage にも保存する */
  const handleProviderChange = useCallback((key) => {
    try {
      setProvider(key);
      setCurrentProvider(key);
      // 設定を db.settings に永続化
      update((prev) => ({
        settings: { ...(prev.settings ?? {}), aiProvider: key },
      }));
    } catch (err) {
      console.error("[Settings] Provider 切替エラー:", err);
    }
  }, [update]);

  /** 通知 / カレンダー設定のトグル */
  const handleToggleSetting = useCallback((key) => {
    update((prev) => ({
      settings: {
        ...DEFAULT_SETTINGS,
        ...(prev.settings ?? {}),
        [key]: !(prev.settings?.[key] ?? DEFAULT_SETTINGS[key]),
      },
    }));
  }, [update]);

  const learningCount = (db.ocrLearning ?? []).length;

  // ================================================================
  // レンダリング
  // ================================================================
  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="設定" />

      <div style={{ padding: "16px 16px 0" }}>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ① 業者名 / OCRフィルタ（既存）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle>業者名 / OCRフィルタ</SectionTitle>

        <InfoBanner>
          <BannerTitle>業者名フィルタについて</BannerTitle>
          会社名・業者名を登録すると、工程表OCRで自分の担当工程のみを自動抽出します。
        </InfoBanner>

        <TextField
          label="会社名 / 業者名"
          value={companyName}
          onChange={setCompanyName}
          placeholder="例：松尾シーリング"
        />
        <TextField
          label="略称・別名（複数は「、」区切り）"
          value={aliases}
          onChange={setAliases}
          placeholder="例：松尾、マツオ"
        />
        <PrimaryButton onClick={handleSaveProfile} disabled={!companyName.trim()}>
          {profileSaved ? "保存しました ✓" : "業者名を保存"}
        </PrimaryButton>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ② AI 設定（新規）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle style={{ marginTop: 28 }}>AI 設定</SectionTitle>

        {/* 現在の Provider 表示 */}
        <div style={{
          background: T.card, border: `1px solid ${T.cardBorder}`,
          borderRadius: 14, padding: "12px 16px", marginBottom: 12,
        }}>
          <div style={{ fontSize: 11, color: T.whiteFaint, marginBottom: 4 }}>
            現在の AI Provider
          </div>
          <div style={{ color: T.goldBright, fontSize: 15, fontWeight: 700 }}>
            {PROVIDER_LABELS[currentProvider] ?? currentProvider}
          </div>
        </div>

        {/* Provider 選択ボタン */}
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 4 }}>
          {listProviders().map((key) => {
            const isActive = currentProvider === key;
            return (
              <button
                key={key}
                onClick={() => handleProviderChange(key)}
                style={{
                  display:        "flex",
                  alignItems:     "center",
                  justifyContent: "space-between",
                  background:     isActive ? `${T.gold}18` : T.card,
                  border:         `1px solid ${isActive ? T.gold : T.cardBorder}`,
                  borderRadius:   12,
                  padding:        "13px 16px",
                  cursor:         "pointer",
                  WebkitTapHighlightColor: "transparent",
                  width:          "100%",
                  textAlign:      "left",
                }}
              >
                <div>
                  <div style={{ color: isActive ? T.goldBright : T.white, fontSize: 14, fontWeight: 700 }}>
                    {PROVIDER_LABELS[key] ?? key}
                  </div>
                  {key !== AI_PROVIDER.MOCK && (
                    <div style={{ color: T.whiteFaint, fontSize: 11, marginTop: 2 }}>
                      .env に API キーが必要です
                    </div>
                  )}
                </div>
                {/* 選択インジケーター */}
                <div style={{
                  width: 18, height: 18, borderRadius: 9,
                  border:     `2px solid ${isActive ? T.gold : T.cardBorder}`,
                  background: isActive ? T.gold : "transparent",
                  flexShrink: 0,
                  display:    "flex", alignItems: "center", justifyContent: "center",
                }}>
                  {isActive && (
                    <div style={{ width: 8, height: 8, borderRadius: 4, background: "#15120C" }} />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ③ 通知設定（新規）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle style={{ marginTop: 28 }}>通知設定</SectionTitle>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <ToggleRow
            label="通知を有効にする"
            sub="すべての通知のマスタースイッチ"
            value={settings.notifyEnabled}
            onToggle={() => handleToggleSetting("notifyEnabled")}
            highlight
          />

          {/* 通知が有効な場合のみ詳細を表示 */}
          {settings.notifyEnabled && (
            <>
              <ToggleRow
                label="前日通知（18:00）"
                sub="「明日は○○現場です」"
                value={settings.notifyDayBefore}
                onToggle={() => handleToggleSetting("notifyDayBefore")}
              />
              <ToggleRow
                label="当日通知（7:00）"
                sub="「本日の現場は○○です」"
                value={settings.notifyMorning}
                onToggle={() => handleToggleSetting("notifyMorning")}
              />
              <ToggleRow
                label="在庫不足通知"
                sub="在庫が0になったとき通知"
                value={settings.notifyLowStock}
                onToggle={() => handleToggleSetting("notifyLowStock")}
              />
              <ToggleRow
                label="工程変更通知"
                sub="工程に変更があったとき通知"
                value={settings.notifyScheduleChange}
                onToggle={() => handleToggleSetting("notifyScheduleChange")}
              />
            </>
          )}
        </div>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ④ カレンダー設定（新規）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle style={{ marginTop: 28 }}>カレンダー連携</SectionTitle>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <ToggleRow
            label="Google カレンダー同期"
            sub="工程表を Google Calendar へ書き出す"
            value={settings.syncGoogleCalendar}
            onToggle={() => handleToggleSetting("syncGoogleCalendar")}
          />
          <ToggleRow
            label="Apple カレンダー同期"
            sub="iPhone カレンダーへ .ics で書き出す"
            value={settings.syncAppleCalendar}
            onToggle={() => handleToggleSetting("syncAppleCalendar")}
          />
        </div>

        <div style={{
          background: `${T.gold}0A`, border: `1px solid ${T.gold}20`,
          borderRadius: 12, padding: "10px 14px", marginTop: 10,
        }}>
          <div style={{ color: T.whiteFaint, fontSize: 12, lineHeight: 1.65 }}>
            カレンダー画面の「書き出し」ボタンから手動でエクスポートできます。
            iPhone は受け取った .ics ファイルをタップするだけで登録できます。
          </div>
        </div>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ⑤ データ管理（既存）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle style={{ marginTop: 28 }}>データ管理</SectionTitle>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <SettingRow
            label="在庫 CSV エクスポート"
            sub="現在の在庫一覧をCSVでダウンロード"
            onClick={() => exportInventoryCSV(db.products, db.categories)}
          />
          <SettingRow
            label="JSON バックアップ"
            sub="すべてのデータをJSONでダウンロード"
            onClick={() => exportJSON(db)}
          />
          <SettingRow
            label="JSON からリストア"
            sub="バックアップファイルからデータを復元"
            onClick={() => importRef.current?.click()}
          />
          <input
            ref={importRef}
            type="file"
            accept=".json"
            onChange={handleImport}
            style={{ display: "none" }}
          />
          {importError && (
            <div style={{
              color: T.red, fontSize: 13,
              padding: "8px 12px",
              background: `${T.danger}15`, borderRadius: 10,
            }}>
              {importError}
            </div>
          )}
          {importSuccess && (
            <div style={{
              color: T.green, fontSize: 13,
              padding: "8px 12px",
              background: `${T.green}15`, borderRadius: 10,
            }}>
              インポートが完了しました
            </div>
          )}
        </div>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ⑥ AI 学習データ（既存）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle style={{ marginTop: 28 }}>AI学習データ</SectionTitle>

        <div style={{
          background: T.card, border: `1px solid ${T.cardBorder}`,
          borderRadius: 14, padding: "14px 16px", marginBottom: 12,
        }}>
          <div style={{ color: T.white, fontSize: 14, fontWeight: 700 }}>
            学習済み修正件数：{learningCount} 件
          </div>
          <div style={{ color: T.whiteFaint, fontSize: 12, marginTop: 4 }}>
            工程表OCRで修正した内容がAIの次回解析に活用されます
          </div>
        </div>

        {learningCount > 0 && (
          <button
            onClick={handleResetLearning}
            style={{
              background: "none", border: "none",
              color: T.danger, fontSize: 13,
              cursor: "pointer", padding: "8px 0",
            }}
          >
            学習データをリセット
          </button>
        )}

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ⑦ 詳細プロフィール（既存）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <div style={{ marginTop: 28 }}>
          <GhostButton onClick={() => navigate("profile")}>
            詳細プロフィール設定
          </GhostButton>
        </div>

        {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            ⑧ アプリ情報（新規）
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
        <SectionTitle style={{ marginTop: 28 }}>アプリ情報</SectionTitle>

        <div style={{
          background: T.card, border: `1px solid ${T.cardBorder}`,
          borderRadius: 14, padding: "14px 16px",
        }}>
          {[
            ["アプリ名",      "G Stock"],
            ["バージョン",    "V2 Phase 8-B"],
            ["対象",         "シーリング・防水職人向け"],
            ["AI Provider",  PROVIDER_LABELS[currentProvider] ?? currentProvider],
            ["データ保存先", "端末内（localStorage）"],
          ].map(([label, value]) => (
            <div
              key={label}
              style={{
                display:      "flex",
                justifyContent: "space-between",
                padding:      "6px 0",
                borderBottom: `1px solid ${T.cardBorder}`,
              }}
            >
              <span style={{ color: T.whiteFaint, fontSize: 12 }}>{label}</span>
              <span style={{ color: T.white, fontSize: 12, fontWeight: 600 }}>{value}</span>
            </div>
          ))}
        </div>

        <div style={{ height: 20 }} />
      </div>
    </div>
  );
}

// ================================================================
// 内部コンポーネント
// ================================================================

/** セクションタイトル */
function SectionTitle({ children, style }) {
  return (
    <div style={{
      fontSize: 12, color: T.whiteFaint, fontWeight: 700,
      marginBottom: 10, letterSpacing: 0.5,
      ...style,
    }}>
      {children}
    </div>
  );
}

/** 情報バナー */
function InfoBanner({ children }) {
  return (
    <div style={{
      background: `${T.gold}12`, border: `1px solid ${T.gold}30`,
      borderRadius: 14, padding: "12px 14px", marginBottom: 16,
    }}>
      {children}
    </div>
  );
}

/** バナータイトル */
function BannerTitle({ children }) {
  return (
    <div style={{ color: T.gold, fontSize: 13, fontWeight: 700, marginBottom: 4 }}>
      {children}
    </div>
  );
}

/** タップで画面遷移するリスト行 */
function SettingRow({ label, sub, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background:              T.card,
        border:                  `1px solid ${T.cardBorder}`,
        borderRadius:            14,
        padding:                 "14px 16px",
        display:                 "flex",
        flexDirection:           "column",
        alignItems:              "flex-start",
        gap:                     3,
        cursor:                  "pointer",
        WebkitTapHighlightColor: "transparent",
        width:                   "100%",
        textAlign:               "left",
      }}
    >
      <div style={{ color: T.white, fontSize: 15, fontWeight: 600 }}>{label}</div>
      {sub && <div style={{ color: T.whiteFaint, fontSize: 12 }}>{sub}</div>}
    </button>
  );
}

/**
 * ON/OFF トグル行
 * @param {{ label, sub, value, onToggle, highlight }} props
 */
function ToggleRow({ label, sub, value, onToggle, highlight }) {
  return (
    <div
      style={{
        display:        "flex",
        alignItems:     "center",
        justifyContent: "space-between",
        background:     highlight && value ? `${T.gold}12` : T.card,
        border:         `1px solid ${highlight && value ? T.gold + "50" : T.cardBorder}`,
        borderRadius:   14,
        padding:        "14px 16px",
        gap:            12,
      }}
    >
      {/* ラベル */}
      <div style={{ flex: 1 }}>
        <div style={{ color: T.white, fontSize: 14, fontWeight: 600 }}>{label}</div>
        {sub && (
          <div style={{ color: T.whiteFaint, fontSize: 12, marginTop: 2 }}>{sub}</div>
        )}
      </div>

      {/* トグルスイッチ */}
      <button
        onClick={onToggle}
        aria-label={value ? "オフにする" : "オンにする"}
        style={{
          width:                   48,
          height:                  28,
          borderRadius:            14,
          border:                  "none",
          background:              value
            ? `linear-gradient(145deg, ${T.goldBright}, ${T.gold})`
            : T.cardBorder,
          position:                "relative",
          cursor:                  "pointer",
          flexShrink:              0,
          transition:              "background 0.2s",
          WebkitTapHighlightColor: "transparent",
        }}
      >
        <div style={{
          position:   "absolute",
          top:        3,
          left:       value ? 23 : 3,
          width:      22,
          height:     22,
          borderRadius: 11,
          background: T.white,
          boxShadow:  "0 1px 3px rgba(0,0,0,0.3)",
          transition: "left 0.2s",
        }} />
      </button>
    </div>
  );
}
