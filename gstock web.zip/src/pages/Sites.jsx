// src/pages/Sites.jsx
import React, { useState, useMemo, useCallback } from "react";
import { MapPin, Edit2, Trash2 } from "lucide-react";
import { T, iconBtnStyle } from "../components/tokens.js";
import TopBar           from "../components/TopBar.jsx";
import SearchBar        from "../components/SearchBar.jsx";
import FloatingButton   from "../components/FloatingButton.jsx";
import EmptyState       from "../components/EmptyState.jsx";
import Modal            from "../components/Modal.jsx";
import {
  TextField,
  TextArea,
  PrimaryButton,
  GhostButton,
  ConfirmDeleteModal,
} from "../components/Card.jsx";
import { useSites, useSearch } from "../hooks/useLocalDB.js";
import { useDB } from "../context/DBContext.jsx";

/**
 * 現場管理画面
 * @param {Function} navigate
 */
export default function Sites({ navigate }) {
  const { sites, addSite, editSite, deleteSite } = useSites();
  const { db } = useDB();

  const { query, setQuery, filtered } = useSearch(sites, ["name", "address"]);
  const sorted = useMemo(
    () => [...filtered].sort((a, b) => b.createdAt - a.createdAt),
    [filtered]
  );

  const [modalOpen,    setModalOpen]    = useState(false);
  const [editing,      setEditing]      = useState(null);
  const [detailTarget, setDetailTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: "", address: "", memo: "" });

  const openNew = useCallback(() => {
    setEditing(null);
    setForm({ name: "", address: "", memo: "" });
    setModalOpen(true);
  }, []);

  const openEdit = useCallback((s) => {
    setEditing(s);
    setForm({ name: s.name, address: s.address ?? "", memo: s.memo ?? "" });
    setModalOpen(true);
  }, []);

  const handleSave = useCallback(() => {
    if (!form.name.trim()) return;
    if (editing) {
      editSite(editing.id, { name: form.name.trim(), address: form.address.trim(), memo: form.memo.trim() });
    } else {
      addSite({ name: form.name.trim(), address: form.address.trim(), memo: form.memo.trim() });
    }
    setModalOpen(false);
  }, [form, editing, editSite, addSite]);

  const handleDelete = useCallback(() => {
    deleteSite(deleteTarget.id);
    setDeleteTarget(null);
  }, [deleteTarget, deleteSite]);

  // 現場の出面履歴
  const siteAttendance = useCallback(
    (siteId) =>
      (db.attendance ?? [])
        .filter((a) => a.siteId === siteId)
        .sort((a, b) => b.date.localeCompare(a.date)),
    [db.attendance]
  );

  // 現場の写真
  const sitePhotos = useCallback(
    (siteId) => (db.photos ?? []).filter((p) => p.siteId === siteId),
    [db.photos]
  );

  return (
    <div style={{ paddingBottom: 100 }}>
      <TopBar title="現場" />
      <SearchBar value={query} onChange={setQuery} placeholder="現場を検索" />

      {sorted.length === 0 ? (
        <EmptyState
          icon={MapPin}
          text="現場がありません"
          sub="右下の＋から追加してください"
        />
      ) : (
        <div
          style={{
            padding:       "4px 16px",
            display:       "flex",
            flexDirection: "column",
            gap:           10,
          }}
        >
          {sorted.map((s) => (
            <div
              key={s.id}
              style={{
                background:   T.card,
                border:       `1px solid ${T.cardBorder}`,
                borderRadius: 16,
                padding:      "14px 16px",
                display:      "flex",
                alignItems:   "center",
                gap:          12,
              }}
            >
              {/* 現場名（タップで詳細） */}
              <button
                onClick={() => setDetailTarget(s)}
                style={{
                  flex:                    1,
                  background:              "none",
                  border:                  "none",
                  textAlign:               "left",
                  cursor:                  "pointer",
                  WebkitTapHighlightColor: "transparent",
                  minWidth:                0,
                }}
              >
                <div style={{ color: T.white, fontSize: 16, fontWeight: 700 }}>
                  {s.name}
                </div>
                {s.address && (
                  <div
                    style={{
                      color:     T.whiteFaint,
                      fontSize:  12,
                      marginTop: 3,
                    }}
                  >
                    {s.address}
                  </div>
                )}
              </button>

              {/* 編集 / 削除ボタン */}
              <button onClick={() => openEdit(s)} style={iconBtnStyle}>
                <Edit2 size={18} color={T.whiteDim} />
              </button>
              <button onClick={() => setDeleteTarget(s)} style={iconBtnStyle}>
                <Trash2 size={18} color={T.danger} />
              </button>
            </div>
          ))}
        </div>
      )}

      <FloatingButton onClick={openNew} />

      {/* 追加 / 編集モーダル */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? "現場編集" : "現場追加"}
      >
        <TextField
          label="現場名"
          value={form.name}
          onChange={(v) => setForm((f) => ({ ...f, name: v }))}
          placeholder="例：○○マンション改修"
          autoFocus
        />
        <TextField
          label="住所"
          value={form.address}
          onChange={(v) => setForm((f) => ({ ...f, address: v }))}
          placeholder="任意"
        />
        <TextArea
          label="メモ"
          value={form.memo}
          onChange={(v) => setForm((f) => ({ ...f, memo: v }))}
          placeholder="任意"
          rows={2}
        />
        <PrimaryButton onClick={handleSave} disabled={!form.name.trim()}>
          保存
        </PrimaryButton>
      </Modal>

      {/* 現場詳細モーダル */}
      <Modal
        open={!!detailTarget}
        onClose={() => setDetailTarget(null)}
        title={detailTarget?.name ?? ""}
      >
        {detailTarget && (
          <SiteDetail
            site={detailTarget}
            attendance={siteAttendance(detailTarget.id)}
            photos={sitePhotos(detailTarget.id)}
          />
        )}
      </Modal>

      {/* 削除確認 */}
      <ConfirmDeleteModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        itemName={deleteTarget?.name}
      />
    </div>
  );
}

// ── 現場詳細コンテンツ ────────────────────────────────────────
function SiteDetail({ site, attendance, photos }) {
  return (
    <div>
      {site.address && (
        <div style={{ color: T.whiteDim, fontSize: 13, marginBottom: 4 }}>
          {site.address}
        </div>
      )}
      {site.memo && (
        <div style={{ color: T.whiteFaint, fontSize: 13, marginBottom: 14 }}>
          {site.memo}
        </div>
      )}

      {/* 出面履歴 */}
      <div
        style={{
          fontSize:   13,
          fontWeight: 700,
          color:      T.gold,
          margin:     "14px 0 8px",
        }}
      >
        出面履歴
      </div>
      {attendance.length === 0 ? (
        <div style={{ color: T.whiteFaint, fontSize: 13 }}>履歴なし</div>
      ) : (
        attendance.slice(0, 10).map((a) => (
          <div
            key={a.id}
            style={{
              display:        "flex",
              justifyContent: "space-between",
              padding:        "8px 0",
              borderBottom:   `1px solid ${T.cardBorder}`,
            }}
          >
            <span style={{ color: T.whiteDim, fontSize: 13 }}>{a.date}</span>
            <span style={{ color: T.white, fontSize: 13, fontWeight: 700 }}>
              {a.value} 人工
            </span>
          </div>
        ))
      )}

      {/* 写真サムネイル */}
      <div
        style={{
          fontSize:   13,
          fontWeight: 700,
          color:      T.gold,
          margin:     "16px 0 8px",
        }}
      >
        写真 ({photos.length})
      </div>
      {photos.length > 0 && (
        <div
          style={{
            display:             "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap:                 6,
          }}
        >
          {photos.slice(0, 8).map((ph) => (
            <img
              key={ph.id}
              src={ph.dataUrl}
              alt=""
              style={{
                width:        "100%",
                aspectRatio:  "1",
                objectFit:    "cover",
                borderRadius: 8,
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
